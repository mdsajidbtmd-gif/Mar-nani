const STARTER_ITEMS = [
  ['Battle Uniform',800,false],['Half Sleeve Shirt',250,false],['Full Sleeve Shirt',250,false],['Uniform Pant',200,false],
  ['Summer Ceremonial',1500,false],['Winter Ceremonial',1000,false],['Half Bush',1000,false],['Civil Shirt',500,false],
  ['Civil Pant',600,true],['Punjabi',500,false],['Paijama',400,false],['Jubba',800,true],['Safari',2000,false],
  ['Blazer',4000,false],['Suit',5000,false],['Meskit',2200,false],['Meskit Shirt',400,false],['APPULATE (MESKIT',700,true],
  ['keti',2000,false],['maintainnce coverall',1000,false],['MESKIT PANT',200,true],['DUST COAT',400,false],
  ['MISSON GANJI',1000,false],['FOTUA',400,false],['HALF BUSH UPOR PART',800,true],
  ['summer ceremonial upor part',1300,true],['sleeping dress',600,true]
].map(([name,price,needsPriceCheck],i)=>({id:`seed-${i+1}`,name,price,needsPriceCheck}));

const RIBBON_DEFAULTS = [0,3,4,6];
const STORAGE_KEY = 'tailor-shop-manager-v3';
const DRAFTS_STORAGE_KEY = 'tailor-shop-drafts-v4';
const AUTOSAVE_KEY = 'tailor_order_autosave_v4';
const MEASUREMENT_FIELDS = {
  shirt: ['Length','Chest','Belly','Hip','Shoulder','Sleeve','Collar','Front','Back','Hand Written Notes','Extra Notes'],
  pant: ['Length','Waist','Hip','High','Thai','Leg Open','Hand Written Notes','Extra Notes']
};

const isFirebaseConfigured = (() => {
  const c = window.TAILOR_FIREBASE_CONFIG || {};
  return !!(c.apiKey && !c.apiKey.includes('PASTE_') && c.projectId && c.projectId !== 'YOUR_PROJECT_ID' && c.appId && !c.appId.includes('PASTE_'));
})();

const deepClone = (v) => JSON.parse(JSON.stringify(v));
const defaultSettings = () => ({
  items: deepClone(STARTER_ITEMS),
  defaultDiscountType: 'percentage',
  ribbonValues: [...RIBBON_DEFAULTS],
  upcomingDeliveryDays: 3,
  shopName: 'Darzi Tailor Shop',
  shopLogo: '',
  terms: '1. Please bring this invoice for garment collection.\n2. Delivery within shop working hours.\n3. Alterations accepted within 7 days of delivery.',
  invoicePaperSize: 'A4',
  cuttingSlipPaperSize: 'A4'
});

const blankMeasurements = () => ({
  shirt: Object.fromEntries(MEASUREMENT_FIELDS.shirt.map(x=>[x,''])),
  pant: Object.fromEntries(MEASUREMENT_FIELDS.pant.map(x=>[x,'']))
});

const todayISO = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
};

const addDaysISO = (baseDateStr, days) => {
  const d = baseDateStr ? new Date(baseDateStr) : new Date();
  d.setDate(d.getDate() + Number(days || 0));
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
};

const uid = () => (globalThis.crypto?.randomUUID?.() || `id-${Date.now()}-${Math.random().toString(36).slice(2,9)}`);
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const normBD = (v) => String(v ?? '').trim().toUpperCase();
const formatMoney = (n) => `৳${Number(n || 0).toLocaleString('en-BD',{maximumFractionDigits:2,minimumFractionDigits:Number(n||0)%1 ? 2 : 0})}`;
const formatAmount = (n) => formatMoney(n).replace(/^৳/, '');
const dateLabel = (v) => {
  if (!v) return '—';
  try {
    const parts = String(v).split('-');
    if (parts.length === 3) {
      const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      const mIdx = Number(parts[1]) - 1;
      if (mIdx >= 0 && mIdx < 12) return `${months[mIdx]} ${Number(parts[2])}`;
    }
    return String(v);
  } catch {
    return String(v);
  }
};

const DEFAULT_STATE = () => ({
  screen: 'orders', // 'orders' | 'drafts' | 'delivery' | 'settings' | 'form' | 'details' | 'print-slip' | 'print-invoice' | 'customers' | 'customer-history' | 'person-history'
  printOrderId: null,
  printReturnScreen: 'orders',
  activeTab: 'All', // 'All' | 'Pending' | 'Cutting Slip – Done' | 'Delivered'
  cardFilter: null, // null | 'upcoming' | 'dueAfterDelivery'
  orders: [],
  drafts: [],
  activeDraftId: null,
  localAutosaved: false,
  customers: [],
  customerSearch: '',
  customerSort: 'newest', // 'newest' | 'name' | 'due'
  customerHistorySearch: '',
  personHistoryBD: null,
  personHistoryReturnScreen: 'customer-history',
  detailsReturnScreen: 'orders',
  customerSuggestionsOpen: false,
  customerSuggestionField: null,
  settings: defaultSettings(),
  loaded: false,
  remoteError: '',
  search: '',
  deliverySearch: '',
  sort: 'newest',
  mobileSearchOpen: false,
  form: null,
  editingId: null,
  detailId: null,
  dirty: false,
  itemSearch: '',
  selectedItemId: '',
  itemPickerOpen: false,
  quantity: 1,
  mobileFormTab: 'items',
  totalEditOpen: false,
  modal: null,
  settingsItemModal: null,
  settingsQuickAdd: { name: '', price: '' },
  mobileMenuOpen: false,
  toast: null,
  bootReady: false,
  backendReady: false,
});

let state = DEFAULT_STATE();
let firebase = null;
let toastTimer = null;
let localSequence = 532;

// Payment and financial calculation helpers
function getOrderPayments(order) {
  return Array.isArray(order?.payments) ? order.payments : [];
}

function getLaterPaymentsTotal(order) {
  return getOrderPayments(order).reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
}

function getTotalReceived(order) {
  return (Number(order?.advance) || 0) + getLaterPaymentsTotal(order);
}

function getOrderDue(order) {
  if (!order) return 0;
  const total = Number(order.total) || 0;
  const disc = Number(order.discountAmount) || 0;
  const received = getTotalReceived(order);
  return Math.max(0, Math.round((total - disc - received) * 100) / 100);
}

function isOrderUpcoming(order) {
  if (!order || (order.status || 'Pending') === 'Delivered') return false;
  if (!order.deliveryDate || order.deliveryDate.length !== 10) return false;
  const today = todayISO();
  const days = Number(state.settings.upcomingDeliveryDays) || 3;
  const maxDateISO = addDaysISO(today, days);
  return order.deliveryDate >= today && order.deliveryDate <= maxDateISO;
}

function isDueAfterDelivery(order) {
  if (!order) return false;
  return (order.status || 'Pending') === 'Delivered' && getOrderDue(order) > 0;
}

// Loop 5 Customer helpers: Orders count, Spent and Due are calculated dynamically from orders each time
function getCustomerStats(bdNumber) {
  const norm = normBD(bdNumber);
  const matchingOrders = (state.orders || []).filter(o => normBD(o.customerBDNumber) === norm);
  const ordersCount = matchingOrders.length;
  const spent = matchingOrders.reduce((sum, o) => {
    const total = Number(o.total) || 0;
    const disc = Number(o.discountAmount) || 0;
    return sum + Math.max(0, Math.round((total - disc) * 100) / 100);
  }, 0);
  const due = matchingOrders.reduce((sum, o) => sum + getOrderDue(o), 0);
  return { ordersCount, spent, due, matchingOrders };
}

function syncCustomersFromOrders() {
  const existingMap = new Map();
  (state.customers || []).forEach(c => {
    if (c.bdNumber) existingMap.set(normBD(c.bdNumber), c);
  });
  (state.orders || []).forEach(o => {
    if (o.customerBDNumber) {
      const key = normBD(o.customerBDNumber);
      if (!existingMap.has(key)) {
        const newCust = {
          id: encodeURIComponent(key),
          category: 'Officer',
          bdNumber: o.customerBDNumber,
          name: o.customerName || 'Unnamed customer',
          phone: o.phone || '',
          createdAt: o.createdAt || Date.now()
        };
        state.customers.push(newCust);
        existingMap.set(key, newCust);
      }
    }
  });
}

function buildInitialSeedOrders() {
  const today = todayISO();
  return [
    {
      id: 'seed-order-531',
      category: 'Officer',
      orderNumber: 531,
      customerName: 'F/L Tanvir Ahmed',
      customerBDNumber: 'BD/12408',
      phone: '01711-234567',
      orderDate: addDaysISO(today, -3),
      deliveryDate: addDaysISO(today, 4),
      deliveredDate: '',
      status: 'Pending',
      total: 2000,
      advance: 800,
      due: 1200,
      payments: [],
      discountType: 'percentage',
      discountValue: 0,
      discountAmount: 0,
      ribbon: 3,
      measurements: {
        shirt: { Length: '29.5', Chest: '38', Belly: '35', Hip: '39', Shoulder: '17.5', Sleeve: '24', Collar: '15.5', Front: '15', Back: '16', 'Hand Written Notes': 'Left cuff watch space', 'Extra Notes': '' },
        pant: { Length: '40', Waist: '33', Hip: '38', High: '11', Thai: '23', 'Leg Open': '15.5', 'Hand Written Notes': '', 'Extra Notes': '' }
      },
      items: [
        { id: uid(), name: 'Battle Uniform', quantity: 1, price: 800 },
        { id: uid(), name: 'Civil Pant', quantity: 2, price: 600 }
      ],
      createdAt: Date.now() - 3 * 86400000,
      updatedAt: Date.now()
    },
    {
      id: 'seed-order-530',
      category: 'Officer',
      orderNumber: 530,
      customerName: 'S/L Rashedul Karim',
      customerBDNumber: 'BD/9163',
      phone: '01819-345678',
      orderDate: addDaysISO(today, -4),
      deliveryDate: addDaysISO(today, 1),
      deliveredDate: '',
      status: 'Cutting Slip – Done',
      total: 3500,
      advance: 1500,
      due: 2000,
      payments: [],
      discountType: 'percentage',
      discountValue: 0,
      discountAmount: 0,
      ribbon: 4,
      measurements: {
        shirt: { Length: '30', Chest: '40', Belly: '37', Hip: '41', Shoulder: '18', Sleeve: '24.5', Collar: '16', Front: '15.5', Back: '16.5', 'Hand Written Notes': '', 'Extra Notes': '' },
        pant: { Length: '41', Waist: '34', Hip: '40', High: '11.5', Thai: '24', 'Leg Open': '16', 'Hand Written Notes': 'Slight flare', 'Extra Notes': '' }
      },
      items: [
        { id: uid(), name: 'Meskit', quantity: 1, price: 2200 },
        { id: uid(), name: 'summer ceremonial upor part', quantity: 1, price: 1300 }
      ],
      createdAt: Date.now() - 4 * 86400000,
      updatedAt: Date.now()
    },
    {
      id: 'seed-order-529',
      category: 'Officer',
      orderNumber: 529,
      customerName: 'W/C Mahbub Alam',
      customerBDNumber: 'BD/6027',
      phone: '01912-456789',
      orderDate: addDaysISO(today, -5),
      deliveryDate: addDaysISO(today, -3),
      deliveredDate: addDaysISO(today, -3),
      status: 'Delivered',
      total: 9000,
      advance: 3900,
      due: 5100,
      payments: [],
      discountType: 'percentage',
      discountValue: 0,
      discountAmount: 0,
      ribbon: 6,
      measurements: blankMeasurements(),
      items: [
        { id: uid(), name: 'Suit', quantity: 1, price: 5000 },
        { id: uid(), name: 'Blazer', quantity: 1, price: 4000 }
      ],
      createdAt: Date.now() - 5 * 86400000,
      updatedAt: Date.now()
    },
    {
      id: 'seed-order-528',
      category: 'Officer',
      orderNumber: 528,
      customerName: 'F/O Saiful Islam',
      customerBDNumber: 'BD/14290',
      phone: '01610-567890',
      orderDate: addDaysISO(today, -6),
      deliveryDate: '',
      deliveredDate: addDaysISO(today, -5),
      status: 'Delivered',
      total: 1250,
      advance: 1250,
      due: 0,
      payments: [],
      discountType: 'percentage',
      discountValue: 0,
      discountAmount: 0,
      ribbon: 0,
      measurements: blankMeasurements(),
      items: [
        { id: uid(), name: 'Battle Uniform', quantity: 1, price: 800 },
        { id: uid(), name: 'Uniform Pant', quantity: 2, price: 200 },
        { id: uid(), name: 'Half Sleeve Shirt', quantity: 1, price: 250 }
      ],
      createdAt: Date.now() - 6 * 86400000,
      updatedAt: Date.now()
    },
    {
      id: 'seed-order-527',
      category: 'Officer',
      orderNumber: 527,
      customerName: 'Gp Capt Imran Hossain',
      customerBDNumber: 'BD/3511',
      phone: '01715-678901',
      orderDate: addDaysISO(today, -8),
      deliveryDate: addDaysISO(today, 2),
      deliveredDate: '',
      status: 'Pending',
      total: 2900,
      advance: 1000,
      due: 1900,
      payments: [],
      discountType: 'percentage',
      discountValue: 0,
      discountAmount: 0,
      ribbon: 3,
      measurements: blankMeasurements(),
      items: [
        { id: uid(), name: 'Safari', quantity: 1, price: 2000 },
        { id: uid(), name: 'Civil Shirt', quantity: 1, price: 500 },
        { id: uid(), name: 'Paijama', quantity: 1, price: 400 }
      ],
      createdAt: Date.now() - 8 * 86400000,
      updatedAt: Date.now()
    },
    {
      id: 'seed-order-526',
      category: 'Officer',
      orderNumber: 526,
      customerName: 'F/L Nazmul Haque Sarker',
      customerBDNumber: 'BD/11776',
      phone: '01811-789012',
      orderDate: addDaysISO(today, -9),
      deliveryDate: addDaysISO(today, -1),
      deliveredDate: addDaysISO(today, -1),
      status: 'Delivered',
      total: 1850,
      advance: 1350,
      due: 500,
      payments: [],
      discountType: 'percentage',
      discountValue: 0,
      discountAmount: 0,
      ribbon: 4,
      measurements: blankMeasurements(),
      items: [
        { id: uid(), name: 'Winter Ceremonial', quantity: 1, price: 1000 },
        { id: uid(), name: 'Civil Shirt', quantity: 1, price: 500 },
        { id: uid(), name: 'Uniform Pant', quantity: 1, price: 200 },
        { id: uid(), name: 'Half Sleeve Shirt', quantity: 1, price: 250 }
      ],
      createdAt: Date.now() - 9 * 86400000,
      updatedAt: Date.now()
    }
  ];
}

function loadDraftsLocal() {
  try {
    const raw = localStorage.getItem(DRAFTS_STORAGE_KEY);
    if (raw) {
      const data = JSON.parse(raw);
      state.drafts = Array.isArray(data) ? data : [];
    } else {
      state.drafts = [];
    }
  } catch (e) {
    console.warn('Could not read local drafts.', e);
    state.drafts = [];
  }
}

function saveDraftsLocal() {
  try {
    localStorage.setItem(DRAFTS_STORAGE_KEY, JSON.stringify(state.drafts || []));
  } catch (e) {
    console.warn('Could not save local drafts.', e);
  }
}

function loadLocalState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY) || localStorage.getItem('tailor-shop-manager-v2') || localStorage.getItem('tailor-shop-manager-v1');
    if (raw) {
      const data = JSON.parse(raw);
      state.orders = Array.isArray(data.orders) ? data.orders : [];
      state.customers = Array.isArray(data.customers) ? data.customers : [];
      syncCustomersFromOrders();
      state.settings = {
        ...defaultSettings(),
        ...(data.settings || {}),
        items: Array.isArray(data.settings?.items) ? data.settings.items : deepClone(STARTER_ITEMS),
        ribbonValues: Array.isArray(data.settings?.ribbonValues) ? data.settings.ribbonValues : [...RIBBON_DEFAULTS],
        upcomingDeliveryDays: Number(data.settings?.upcomingDeliveryDays) || 3,
        shopName: data.settings?.shopName || 'Darzi Tailor Shop',
        shopLogo: data.settings?.shopLogo || '',
        terms: data.settings?.terms || defaultSettings().terms,
        invoicePaperSize: data.settings?.invoicePaperSize || 'A4',
        cuttingSlipPaperSize: data.settings?.cuttingSlipPaperSize || 'A4'
      };
      localSequence = Math.max(532, Number(data.nextOrderNumber) || (state.orders.length ? Math.max(...state.orders.map(o=>Number(o.orderNumber)||0)) + 1 : 532));
    }
    
    if (!state.orders.length) {
      state.orders = buildInitialSeedOrders();
      state.customers = state.orders.map(o => ({
        id: encodeURIComponent(normBD(o.customerBDNumber)),
        category: 'Officer',
        bdNumber: o.customerBDNumber,
        name: o.customerName,
        phone: o.phone,
        createdAt: o.createdAt
      }));
      localSequence = 532;
      saveLocalState();
    }
    loadDraftsLocal();
  } catch (e) {
    console.warn('Could not read local preview data.', e);
  }
}

function saveLocalState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      orders: state.orders,
      customers: state.customers,
      settings: state.settings,
      nextOrderNumber: localSequence
    }));
    saveDraftsLocal();
  } catch (e) {
    console.warn('Could not save local preview data.', e);
  }
}

function notify(message, type = 'success') {
  state.toast = { message, type };
  if (toastTimer) clearTimeout(toastTimer);
  render();
  toastTimer = setTimeout(() => {
    state.toast = null;
    render();
  }, 2800);
}

function knownCustomer(bd) {
  const key = normBD(bd);
  return state.customers.find(c => normBD(c.bdNumber) === key) || null;
}

function activeOrder() {
  return state.orders.find(o => o.id === state.detailId) || null;
}

function orderById(id) {
  return state.orders.find(o => o.id === id) || null;
}

function discountCalculation(raw, total, baseType) {
  const text = String(raw ?? '').trim();
  if (!text) return { amount: 0, value: 0, type: baseType || state.settings.defaultDiscountType || 'percentage' };
  const hasPercent = /%\s*$/.test(text);
  const numeric = Number(text.replace(/%\s*$/, '').replace(/,/g, ''));
  if (!Number.isFinite(numeric) || numeric < 0) return { amount: 0, value: 0, type: hasPercent ? 'percentage' : (baseType || state.settings.defaultDiscountType || 'percentage') };
  const type = hasPercent ? 'percentage' : (baseType || state.settings.defaultDiscountType || 'percentage');
  const amount = type === 'percentage' ? Math.round((Number(total || 0) * numeric / 100) * 100) / 100 : numeric;
  return { amount, value: numeric, type };
}

function formSubtotal() {
  return (state.form?.items || []).reduce((sum, item) => sum + (Number(item.price) || 0) * (Number(item.quantity) || 0), 0);
}

function currentTotal() {
  if (!state.form) return 0;
  const sum = formSubtotal();
  if (state.form.totalOverride !== null && state.form.totalOverride !== undefined && state.form.totalOverride !== '') {
    return Math.max(0, Number(state.form.totalOverride) || 0);
  }
  return sum;
}

function currentDiscount() {
  return discountCalculation(state.form?.discountInput, currentTotal(), state.form?.discountType || state.settings.defaultDiscountType);
}

function currentDue() {
  const total = currentTotal();
  const disc = currentDiscount().amount;
  const adv = Number(state.form?.advance) || 0;
  let laterReceived = 0;
  if (state.editingId) {
    const o = orderById(state.editingId);
    if (o) laterReceived = getLaterPaymentsTotal(o);
  }
  return Math.max(0, Math.round((total - disc - adv - laterReceived) * 100) / 100);
}

function newForm() {
  return {
    items: [],
    shirt: {},
    pant: {},
    bdNumber: '',
    customerName: '',
    phone: '',
    orderDate: todayISO(),
    deliveryDate: '',
    ribbon: String(state.settings.ribbonValues?.[0] ?? 0),
    discountInput: '',
    discountType: state.settings.defaultDiscountType || 'percentage',
    advance: 0,
    totalOverride: null
  };
}

function formFromOrder(order) {
  const form = {
    items: (order.items || []).map(i => ({ ...i, id: i.id || uid() })),
    shirt: { ...blankMeasurements().shirt, ...(order.measurements?.shirt || {}) },
    pant: { ...blankMeasurements().pant, ...(order.measurements?.pant || {}) },
    bdNumber: order.customerBDNumber || '',
    customerName: order.customerName || '',
    phone: order.phone || '',
    orderDate: order.orderDate || todayISO(),
    deliveryDate: order.deliveryDate || '',
    ribbon: String(order.ribbon ?? ''),
    discountInput: '',
    discountType: order.discountType || state.settings.defaultDiscountType || 'percentage',
    advance: Number(order.advance) || 0,
    totalOverride: null
  };
  form.discountInput = Number(order.discountValue || 0) ? (order.discountType === 'percentage' ? `${order.discountValue}%` : String(order.discountValue)) : '';
  const lineSum = form.items.reduce((s, i) => s + (Number(i.price) || 0) * (Number(i.quantity) || 0), 0);
  if (Math.abs(Number(order.total || 0) - lineSum) > 0.009) {
    form.totalOverride = Number(order.total) || 0;
  }
  return form;
}

function icon(name) {
  const paths = {
    plus: 'M12 5v14M5 12h14',
    search: 'm20 20-4.5-4.5M10.8 17a6.2 6.2 0 1 0 0-12.4 6.2 6.2 0 0 0 0 12.4Z',
    edit: 'M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L8 18l-4 1 1-4Z',
    trash: 'M3 6h18M8 6V4h8v2m-11 0 1 15h12l1-15M10 11v6M14 11v6',
    chevron: 'm9 18 6-6-6-6',
    back: 'm15 18-6-6 6-6',
    menu: 'M4 7h16M4 12h16M4 17h16',
    settings: 'M12 8.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7ZM19 13.6l1.2.9-1.4 2.4-1.4-.6a7 7 0 0 1-1.6.9l-.2 1.5h-2.8l-.3-1.5a7 7 0 0 1-1.6-.9l-1.4.6-1.4-2.4 1.2-.9a7 7 0 0 1 0-1.8l-1.2-.9 1.4-2.4 1.4.6a7 7 0 0 1 1.6-.9l.3-1.5h2.8l.2 1.5a7 7 0 0 1 1.6.9l1.4-.6 1.4 2.4-1.2.9a7 7 0 0 1 0 1.8Z',
    orders: 'M5 4h14v16H5zM8 8h8M8 12h8M8 16h5',
    calendar: 'M4 6h16v14H4zM8 3v6M16 3v6M4 10h16',
    check: 'm5 12 4 4L19 6',
    close: 'M6 6l12 12M18 6 6 18',
    shirt: 'M6 5 9 3h6l3 2 3 2-3 4-2-1v11H8V10l-2 1-3-4Z',
    money: 'M12 2v20M17 6H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6',
    alert: 'M12 9v4m0 4h.01M10.3 3.8 2.7 17a2 2 0 0 0 1.7 3h15.2a2 2 0 0 0 1.7-3l-7.6-13.2a2 2 0 0 0-3.4 0Z',
    right: 'M5 12h14m-6-6 6 6-6 6',
    tag: 'M20 13 11 22l-9-9V2h11zM7 7h.01',
    truck: 'M1 3h15v13H1zM16 8h4l3 3v5h-7V8zM5.5 19a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5zM18.5 19a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z',
    slip: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z M14 2v6h6 M16 13H8 M16 17H8 M10 9H8',
    draft: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z M14 2v6h6 M16 13H8 M16 17H8 M10 9H8',
    invoice: 'M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1-2-1-2 1z M8 7h8 M8 11h8 M8 15h5',
    print: 'M6 9V2h12v7 M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2 M6 14h12v8H6z',
    users: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M9 7a4 4 0 1 0 0-8 4 4 0 0 0 0 8 M22 21v-2a4 4 0 0 0-3-3.87 M16 3.13a4 4 0 0 1 0 7.75',
    history: 'M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8 M3 3v5h5 M12 7v5l4 2',
    phone: 'M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z'
  };
  const d = paths[name] || 'M12 5v14M5 12h14';
  return `<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="${d}"></path></svg>`;
}

function getScreenLabel() {
  const o = state.editingId ? orderById(state.editingId) : (state.printOrderId ? orderById(state.printOrderId) : activeOrder());
  const person = state.personHistoryBD ? knownCustomer(state.personHistoryBD) : null;
  return state.screen === 'orders' ? 'Orders' :
         state.screen === 'drafts' ? 'Drafts' :
         state.screen === 'delivery' ? 'Delivery' :
         state.screen === 'customers' ? 'Customers' :
         state.screen === 'customer-history' ? 'Customer History' :
         state.screen === 'person-history' ? (person?.name || 'Customer History') :
         state.screen === 'settings' ? 'Settings' :
         state.screen === 'print-slip' ? `Cutting Slip #${o?.orderNumber ?? ''}` :
         state.screen === 'print-invoice' ? `Invoice #${o?.orderNumber ?? ''}` :
         state.screen === 'form' ? (state.editingId ? `Edit order #${o?.orderNumber ?? ''}` : (state.activeDraftId ? 'Draft order' : 'New order')) :
         `Order #${activeOrder()?.orderNumber ?? ''}`;
}

function renderHeader() {
  const isPrint = ['print-slip', 'print-invoice'].includes(state.screen);
  if (isPrint) return ''; // Let print preview toolbar control navigation

  const orderActive = ['orders', 'details', 'delivery'].includes(state.screen) || (state.screen === 'form' && !state.activeDraftId);
  const draftActive = state.screen === 'drafts' || (state.screen === 'form' && state.activeDraftId);
  const customersActive = state.screen === 'customers';
  const historyActive = ['customer-history', 'person-history'].includes(state.screen);
  const mobileLeft = state.screen === 'form'
    ? `<button class="mobile-cancel-link" data-action="cancel-form">Cancel</button>`
    : state.screen === 'person-history'
    ? `<button class="ic gl" data-action="back-from-person-history" aria-label="Back to Customer History">${icon('back')}</button>`
    : ['details', 'delivery'].includes(state.screen)
    ? `<button class="ic gl" data-action="back-to-orders" aria-label="Back">${icon('back')}</button>`
    : `<button class="ic gl" data-action="toggle-mobile-menu" aria-label="Open menu" aria-expanded="${!!state.mobileMenuOpen}">${icon('menu')}</button>`;

  return `
    <div class="page top-shell">
      <header class="top">
        <div class="cap" aria-label="Darzi Tailor Shop Manager">
          <span class="av">D</span>
          <span><b>${esc(state.settings.shopName || 'Darzi')}</b><small>Tailor Shop Manager</small></span>
        </div>
        <nav class="nav" aria-label="Main navigation">
          <a href="#" class="${orderActive ? 'on' : ''}" data-action="navigate" data-screen="orders">Orders</a>
          <a href="#" class="${draftActive ? 'on' : ''}" data-action="navigate" data-screen="drafts">Drafts${(state.drafts?.length || 0) > 0 ? `<span class="nav-count-badge">${state.drafts.length}</span>` : ''}</a>
          <a href="#" class="${customersActive ? 'on' : ''}" data-action="navigate" data-screen="customers">Customers</a>
          <a href="#" class="${historyActive ? 'on' : ''}" data-action="navigate" data-screen="customer-history">Customer History</a>
          <a href="#" class="${state.screen === 'settings' ? 'on' : ''}" data-action="navigate" data-screen="settings">Settings</a>
        </nav>
        <div class="r" style="gap:10px">
          <button type="button" class="btn delivery-btn" data-action="go-delivery">Delivery</button>
          <button type="button" class="btn" data-action="new-order">${icon('plus')}New order</button>
        </div>
      </header>
    </div>
    <header class="mobile-head tb">
      ${mobileLeft}
      <b class="ttl">${esc(getScreenLabel())}</b>
      ${state.screen === 'orders' ? `<button class="ic gl" data-action="go-delivery" aria-label="Go to delivery">${icon('truck')}</button>` : `<i style="width:44px" aria-hidden="true"></i>`}
    </header>
  `;
}

function renderMobileMenu() {
  if (!state.mobileMenuOpen || ['print-slip', 'print-invoice'].includes(state.screen)) return '';
  return `
    <div class="mobile-menu-layer">
      <button class="scr" data-action="toggle-mobile-menu" aria-label="Close menu"></button>
      <aside class="dr" role="dialog" aria-modal="true" aria-label="Darzi navigation">
        <div class="r" style="margin-bottom:22px">
          <div class="cap" style="background:#fff">
            <span class="av">D</span>
            <span><b>${esc(state.settings.shopName || 'Darzi')}</b><small>Tailor Shop Manager</small></span>
          </div>
          <button class="ic sp" data-action="toggle-mobile-menu" aria-label="Close menu">${icon('close')}</button>
        </div>
        <button class="nvi ${state.screen === 'orders' ? 'on' : ''}" data-action="navigate" data-screen="orders">
          ${icon('orders')}<span>Orders</span>
        </button>
        <button class="nvi ${state.screen === 'drafts' ? 'on' : ''}" style="margin-top:4px" data-action="navigate" data-screen="drafts">
          ${icon('draft')}<span>Drafts</span>
          ${(state.drafts?.length || 0) > 0 ? `<span class="nvi-badge">${state.drafts.length}</span>` : ''}
        </button>
        <button class="nvi ${state.screen === 'delivery' ? 'on' : ''}" style="margin-top:4px" data-action="go-delivery">
          ${icon('truck')}<span>Delivery</span>
        </button>
        <button class="nvi ${state.screen === 'customers' ? 'on' : ''}" style="margin-top:4px" data-action="navigate" data-screen="customers">
          ${icon('users')}<span>Customers</span>
        </button>
        <button class="nvi ${['customer-history', 'person-history'].includes(state.screen) ? 'on' : ''}" style="margin-top:4px" data-action="navigate" data-screen="customer-history">
          ${icon('history')}<span>Customer History</span>
        </button>
        <button class="nvi ${state.screen === 'settings' ? 'on' : ''}" style="margin-top:4px" data-action="navigate" data-screen="settings">
          ${icon('settings')}<span>Settings</span>
        </button>
        <div class="sp" style="width:100%;text-align:center;margin-top:28px">
          <img src="assets/order-mobile-illustration.svg" alt="" style="width:180px;max-width:100%">
          <div class="xs sub" style="margin-top:8px">Officer orders lifecycle</div>
        </div>
      </aside>
    </div>
  `;
}


function renderNotice() {
  if (state.remoteError) {
    return `<div class="bn form-notice" role="alert"><i class="dot" style="background:var(--neg)"></i><div><b>Firebase connection problem.</b><div class="sub sm">${esc(state.remoteError)} Check your configuration before saving changes.</div></div></div>`;
  }
  return '';
}

function filteredAndSortedOrders() {
  let list = [...state.orders];

  if (state.activeTab && state.activeTab !== 'All') {
    list = list.filter(o => (o.status || 'Pending') === state.activeTab);
  }

  if (state.cardFilter === 'upcoming') {
    list = list.filter(isOrderUpcoming);
  } else if (state.cardFilter === 'dueAfterDelivery') {
    list = list.filter(isDueAfterDelivery);
  }

  const q = state.search.trim().toLowerCase();
  if (q) {
    list = list.filter(o =>
      [o.customerName, o.customerBDNumber, o.phone, String(o.orderNumber || '')].some(v =>
        String(v || '').toLowerCase().includes(q)
      )
    );
  }

  list.sort((a, b) =>
    state.sort === 'newest'
      ? Number(b.orderNumber || 0) - Number(a.orderNumber || 0)
      : Number(a.orderNumber || 0) - Number(b.orderNumber || 0)
  );

  return list;
}

function getTabCounts() {
  const all = state.orders.length;
  const pending = state.orders.filter(o => (o.status || 'Pending') === 'Pending').length;
  const cutting = state.orders.filter(o => o.status === 'Cutting Slip – Done').length;
  const delivered = state.orders.filter(o => o.status === 'Delivered').length;
  return { all, pending, cutting, delivered };
}

function renderStatusSelect(order) {
  const s = order.status || 'Pending';
  const dotClass = s === 'Delivered' ? 'status-dot-delivered' : s === 'Cutting Slip – Done' ? 'status-dot-cutting' : 'status-dot-pending';
  return `
    <div class="status-select-badge" onclick="event.stopPropagation()">
      <i class="dot ${dotClass}"></i>
      <select data-action="change-order-status" data-id="${esc(order.id)}" aria-label="Change status for order #${esc(order.orderNumber)}">
        <option value="Pending" ${s === 'Pending' ? 'selected' : ''}>Pending</option>
        <option value="Cutting Slip – Done" ${s === 'Cutting Slip – Done' ? 'selected' : ''}>Cutting Slip – Done</option>
        <option value="Delivered" ${s === 'Delivered' ? 'selected' : ''}>Delivered</option>
      </select>
      <span class="chevron-down"><svg width="10" height="6" viewBox="0 0 10 6" fill="none"><path d="M1 1L5 5L9 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
    </div>
  `;
}

function renderSummaryCards() {
  const days = Number(state.settings.upcomingDeliveryDays) || 3;
  const upcomingOrders = state.orders.filter(isOrderUpcoming);
  const dueOrders = state.orders.filter(isDueAfterDelivery);
  const totalDue = dueOrders.reduce((sum, o) => sum + getOrderDue(o), 0);

  const isUpcomingActive = state.cardFilter === 'upcoming';
  const isDueActive = state.cardFilter === 'dueAfterDelivery';

  const upcomingPreviews = upcomingOrders.slice(0, 2).map(o => `
    <div class="summary-preview-row">
      <div>
        <b>${esc(o.customerName || 'Unnamed customer')}</b>
        <div class="xs sub">#${esc(o.orderNumber)} · ${esc(o.status || 'Pending')}</div>
      </div>
      <div class="summary-preview-badge">${esc(dateLabel(o.deliveryDate))}</div>
    </div>
  `).join('');

  const duePreviews = dueOrders.slice(0, 2).map(o => {
    const due = getOrderDue(o);
    return `
      <div class="summary-preview-row">
        <div>
          <b>${esc(o.customerName || 'Unnamed customer')}</b>
          <div class="xs sub" style="color:rgba(255,255,255,0.7)">#${esc(o.orderNumber)} · ${formatMoney(due)} due</div>
        </div>
        <button type="button" class="btn-pay-small" data-action="prompt-pay" data-id="${esc(o.id)}" onclick="event.stopPropagation()">Pay ${formatMoney(due)}</button>
      </div>
    `;
  }).join('');

  return `
    <div class="summary-cards-grid">
      <div class="summary-card summary-card-upcoming ${isUpcomingActive ? 'active-filter' : ''}" data-action="toggle-card-filter" data-filter="upcoming" role="button" tabindex="0" aria-pressed="${isUpcomingActive}" aria-label="Filter by upcoming deliveries">
        <div class="summary-card-title">Upcoming to deliver</div>
        <div class="summary-card-stat">
          <span class="stat-num">${upcomingOrders.length}</span>
          <span class="stat-sub">orders · next ${days} days</span>
        </div>
        <div class="summary-preview-list">
          ${upcomingPreviews || `<div class="summary-empty-msg">No deliveries due in the next ${days} days.</div>`}
        </div>
      </div>

      <div class="summary-card summary-card-due ${isDueActive ? 'active-filter' : ''}" data-action="toggle-card-filter" data-filter="dueAfterDelivery" role="button" tabindex="0" aria-pressed="${isDueActive}" aria-label="Filter by due after delivery">
        <div class="summary-card-title">Due after delivery</div>
        <div class="summary-card-stat">
          <span class="stat-num">${formatMoney(totalDue)}</span>
          <span class="stat-sub">${dueOrders.length} ${dueOrders.length === 1 ? 'order' : 'orders'}</span>
        </div>
        <div class="summary-preview-list">
          ${duePreviews || `<div class="summary-empty-msg" style="color:rgba(255,255,255,0.6)">All delivered orders are fully paid.</div>`}
        </div>
      </div>
    </div>
  `;
}

function renderTabsAndToolbar() {
  const counts = getTabCounts();
  const tabs = [
    { key: 'All', label: 'All', count: counts.all },
    { key: 'Pending', label: 'Pending', count: counts.pending },
    { key: 'Cutting Slip – Done', label: 'Cutting Slip – Done', count: counts.cutting },
    { key: 'Delivered', label: 'Delivered', count: counts.delivered }
  ];

  const tabsHtml = tabs.map(t => `
    <button type="button" class="order-filter-pill ${state.activeTab === t.key ? 'active' : ''}" data-action="set-tab" data-tab="${esc(t.key)}">
      <span>${esc(t.label)}</span>
      <span class="order-filter-count">${esc(t.count)}</span>
    </button>
  `).join('');

  const searchInput = `
    <label class="f search-field ${state.mobileSearchOpen || state.search ? '' : 'mobile-search-collapsed'}" style="flex:1;min-width:240px">
      <div class="in">
        ${icon('search')}
        <input class="orders-search-input" data-focus="orders-search" value="${esc(state.search)}" placeholder="Search name, phone, BD number or order number" aria-label="Search orders" autocomplete="off">
      </div>
    </label>
  `;

  const sortSelect = `
    <label class="sort-control">
      <span>Sort</span>
      <select data-change="sort" aria-label="Sort orders">
        <option value="newest" ${state.sort === 'newest' ? 'selected' : ''}>Newest first</option>
        <option value="oldest" ${state.sort === 'oldest' ? 'selected' : ''}>Oldest first</option>
      </select>
      ${icon('chevron')}
    </label>
  `;

  let chipHtml = '';
  if (state.cardFilter === 'upcoming') {
    chipHtml = `<button type="button" class="active-filter-chip" data-action="clear-card-filter"><span>Filter: Upcoming</span>${icon('close')}</button>`;
  } else if (state.cardFilter === 'dueAfterDelivery') {
    chipHtml = `<button type="button" class="active-filter-chip due-chip" data-action="clear-card-filter"><span>Filter: Due after delivery</span>${icon('close')}</button>`;
  }

  return `
    <div class="orders-filter-container">
      <div class="orders-tabs-group" role="tablist" aria-label="Filter orders by status">
        ${tabsHtml}
      </div>
      <div class="r" style="gap:10px;flex:1;max-width:540px;justify-content:flex-end">
        ${searchInput}
        ${sortSelect}
      </div>
    </div>
    ${chipHtml}
  `;
}

function renderOrderCard(o, index) {
  const total = Number(o.total) || 0;
  const advance = Number(o.advance) || 0;
  const due = getOrderDue(o);
  const received = getTotalReceived(o);
  const pct = total > 0 ? Math.max(0, Math.min(100, Math.round((received / total) * 100))) : 0;
  const isDelivered = (o.status || 'Pending') === 'Delivered';
  const showPay = isDelivered && due > 0;

  // Extended column layout to house Cutting Slip & Invoice icons
  const rowStyle = 'grid-template-columns: minmax(180px, 1.4fr) 130px 84px 84px 80px 80px 84px 80px 140px';

  return `
    <div class="rw order-row" style="${rowStyle};animation-delay:${Math.min(index,8)*0.025}s" data-action="open-details" data-id="${esc(o.id)}" role="button" tabindex="0" aria-label="Open order ${esc(o.orderNumber)} for ${esc(o.customerName)}">
      <div class="order-person-cell">
        <span class="no">#${esc(o.orderNumber)}</span>
        <span class="order-person-copy">
          <strong>${esc(o.customerName || 'Unnamed customer')}</strong>
          <small>Officer · ${esc(o.customerBDNumber || '—')}</small>
        </span>
      </div>
      <div class="order-status-cell">
        ${renderStatusSelect(o)}
      </div>
      <div class="order-date-cell">${esc(dateLabel(o.orderDate))}</div>
      <div class="order-date-cell">${esc(dateLabel(o.deliveryDate))}</div>
      <div class="order-money-cell">${formatMoney(o.total)}</div>
      <div class="order-money-cell">${formatMoney(o.advance)}</div>
      <div class="order-money-cell ${due > 0 ? 'neg' : 'pos'}">${due === 0 ? '<span class="pos">৳0</span>' : formatMoney(due)}</div>
      <div class="order-paid-cell">
        <div class="paid-bar-track">
          <i class="paid-bar-fill ${due === 0 ? 'fully-paid' : ''}" style="width:${pct}%"></i>
        </div>
        <span class="xs sub ${due === 0 ? 'pos' : ''}">${due === 0 ? 'Fully paid' : `${pct}% paid`}</span>
      </div>
      <div class="order-row-actions">
        ${showPay ? `<button type="button" class="btn-pay-table" data-action="prompt-pay" data-id="${esc(o.id)}" onclick="event.stopPropagation()">Pay ${formatMoney(due)}</button>` : ''}
        <button type="button" class="ic" title="Cutting Slip" aria-label="Cutting Slip" data-action="print-slip" data-id="${esc(o.id)}" onclick="event.stopPropagation()">${icon('slip')}</button>
        <button type="button" class="ic" title="Invoice" aria-label="Invoice" data-action="print-invoice" data-id="${esc(o.id)}" onclick="event.stopPropagation()">${icon('invoice')}</button>
        <button type="button" class="ic" title="Edit order" aria-label="Edit order" data-action="edit-order" data-id="${esc(o.id)}" onclick="event.stopPropagation()">${icon('edit')}</button>
        <button type="button" class="ic delete-icon" title="Delete order" aria-label="Delete order" data-action="delete-first" data-id="${esc(o.id)}" onclick="event.stopPropagation()">${icon('trash')}</button>
      </div>
    </div>
  `;
}

function renderOrderMobileRow(o) {
  const total = Number(o.total) || 0;
  const due = getOrderDue(o);
  const status = o.status || 'Pending';
  const showPay = status === 'Delivered' && due > 0;
  const dotColor = status === 'Delivered' ? '#2f9e55' : status === 'Cutting Slip – Done' ? '#5e5ce6' : '#f0561f';

  return `
    <div class="mr order-mobile-row" data-action="open-details" data-id="${esc(o.id)}" role="button" tabindex="0" aria-label="Open order ${esc(o.orderNumber)} for ${esc(o.customerName)}">
      <span class="sq">
        ${icon('shirt')}
        <i class="sb" style="background:${dotColor}"></i>
      </span>
      <span class="order-mobile-copy" style="flex:1;min-width:0">
        <b>${esc(o.customerName || 'Unnamed customer')}</b>
        <span class="xs sub">#${esc(o.orderNumber)} · ${esc(o.customerBDNumber || '—')}</span>
        <span class="xs sub">Delivery ${esc(dateLabel(o.deliveryDate))} · Total ${formatMoney(total)}</span>
        <div class="mobile-action-pill-group" onclick="event.stopPropagation()">
          <button type="button" class="mobile-action-pill" data-action="print-slip" data-id="${esc(o.id)}">${icon('slip')}Slip</button>
          <button type="button" class="mobile-action-pill" data-action="print-invoice" data-id="${esc(o.id)}">${icon('invoice')}Invoice</button>
        </div>
      </span>
      <span class="order-mobile-meta" style="text-align:right">
        <b class="${due > 0 ? 'neg' : 'pos'}">${due === 0 ? '৳0 Fully paid' : formatMoney(due)}</b>
        <div style="margin-top:4px" onclick="event.stopPropagation()">${renderStatusSelect(o)}</div>
        ${showPay ? `<button type="button" class="btn-pay-small" style="margin-top:6px;width:100%" data-action="prompt-pay" data-id="${esc(o.id)}" onclick="event.stopPropagation()">Pay ${formatMoney(due)}</button>` : ''}
      </span>
    </div>
  `;
}

function renderOrders() {
  const list = filteredAndSortedOrders();
  const summaryCards = renderSummaryCards();
  const toolbar = renderTabsAndToolbar();

  const tableHead = `
    <div class="rw h order-table-head" style="grid-template-columns: minmax(180px, 1.4fr) 130px 84px 84px 80px 80px 84px 80px 140px">
      <span>Order</span>
      <span>Status</span>
      <span>Ordered</span>
      <span>Delivery</span>
      <span class="rt">Total</span>
      <span class="rt">Advance</span>
      <span class="rt">Due</span>
      <span>Paid</span>
      <span class="rt">Actions</span>
    </div>
  `;

  const empty = `
    <section class="pnl empty-order-state">
      <div class="tray empty-art-tray"><img src="assets/empty-order-illustration.svg" alt="" aria-hidden="true"></div>
      <h2>${state.search || state.cardFilter || state.activeTab !== 'All' ? 'No matching orders' : 'No orders yet'}</h2>
      <p>${state.search ? 'Try a different name, phone, BD number or order number.' : state.cardFilter ? 'No orders fit this summary filter.' : state.activeTab !== 'All' ? `No orders currently in ${state.activeTab}.` : 'Tap New Order to add the first one.'}</p>
      ${state.search || state.cardFilter || state.activeTab !== 'All' ? `<button class="btn tr" data-action="reset-filters">Reset filters</button>` : `<button class="btn" data-action="new-order">${icon('plus')}New Order</button>`}
    </section>
  `;

  const loading = `
    <section class="pnl order-loading-panel">
      ${[1, 2, 3].map(() => `
        <div class="r loading-row">
          <div class="sk" style="width:44px;height:44px;border-radius:14px"></div>
          <div style="flex:1">
            <div class="sk" style="height:14px;width:58%"></div>
            <div class="sk" style="height:10px;width:36%;margin-top:8px"></div>
          </div>
          <div class="sk" style="height:16px;width:68px"></div>
        </div>
      `).join('')}
    </section>
  `;

  return `
    <main class="page orders-page">
      ${renderNotice()}
      <div class="hd">
        <div>
          <h1>Orders</h1>
          <div class="sub page-sub" style="font-size:17px;margin-top:6px">Every Officer order, from first fitting to final due.</div>
        </div>
        <div class="r" style="gap:10px">
          <button type="button" class="btn delivery-btn" data-action="go-delivery">Delivery</button>
          <button type="button" class="btn" data-action="new-order">${icon('plus')}New order</button>
        </div>
      </div>
      ${summaryCards}
      ${toolbar}
      <div class="r orders-results-row">
        <span class="sub sm">Showing ${list.length} of ${state.orders.length} orders</span>
        <span class="sp sub xs">Tap a row for details</span>
      </div>
      ${!state.loaded ? loading : list.length ? `
        <section class="pnl orders-list-panel">
          <div class="r" style="justify-content:space-between;margin-bottom:12px">
            <h2>All orders</h2>
            <span class="sub sm">Showing ${list.length} of ${state.orders.length}</span>
          </div>
          ${tableHead}
          <div class="order-list-desktop">${list.map(renderOrderCard).join('')}</div>
          <div class="lc order-list-mobile">${list.map(renderOrderMobileRow).join('')}</div>
        </section>
      ` : empty}
    </main>
  `;
}

function calculateDraftTotal(d) {
  if (!d) return 0;
  if (d.totalOverride !== null && d.totalOverride !== undefined && d.totalOverride !== '') {
    return Number(d.totalOverride) || 0;
  }
  const items = d.items || [];
  const sum = items.reduce((acc, it) => acc + (Number(it.price) || 0) * (Number(it.quantity) || 1), 0);
  let discAmount = 0;
  const rawDisc = String(d.discountInput || '').trim();
  if (rawDisc.endsWith('%')) {
    const p = Math.max(0, Math.min(100, Number(rawDisc.slice(0, -1)) || 0));
    discAmount = Math.round((sum * p) / 100);
  } else if (rawDisc) {
    discAmount = Math.max(0, Math.min(sum, Number(rawDisc) || 0));
  }
  return Math.max(0, sum - discAmount);
}

function formatRelativeTime(ts) {
  if (!ts) return 'just now';
  const diffSec = Math.max(0, Math.floor((Date.now() - Number(ts)) / 1000));
  if (diffSec < 60) return 'just now';
  const mins = Math.floor(diffSec / 60);
  if (mins < 60) return `${mins} minute${mins === 1 ? '' : 's'} ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} hour${hours === 1 ? '' : 's'} ago`;
  const days = Math.floor(hours / 24);
  if (days === 1) return 'yesterday';
  return `${days} days ago`;
}

function hasFormContent(f) {
  if (!f) return false;
  if (String(f.bdNumber || '').trim()) return true;
  if (String(f.customerName || '').trim()) return true;
  if (String(f.phone || '').trim()) return true;
  if (Array.isArray(f.items) && f.items.length > 0) return true;
  if (f.deliveryDate && f.deliveryDate !== '') return true;
  if (f.discountInput && String(f.discountInput).trim() !== '') return true;
  if (f.advance !== 0 && f.advance !== '' && f.advance !== null && f.advance !== undefined) return true;
  if (f.totalOverride !== null && f.totalOverride !== undefined && f.totalOverride !== '') return true;
  for (const part of ['shirt', 'pant']) {
    const obj = f[part];
    if (obj && typeof obj === 'object') {
      for (const k in obj) {
        if (String(obj[k] || '').trim()) return true;
      }
    }
  }
  return false;
}

function canSaveAsDraft(f) {
  if (!f) return false;
  const bd = String(f.bdNumber || '').trim();
  const hasItems = Array.isArray(f.items) && f.items.length >= 1;
  return Boolean(bd.length > 0 && hasItems);
}

let autosaveTimer = null;
function triggerLocalAutosave() {
  if (state.screen !== 'form' || state.editingId) return;
  if (!hasFormContent(state.form)) return;

  clearTimeout(autosaveTimer);
  autosaveTimer = setTimeout(() => {
    if (state.screen === 'form' && !state.editingId && hasFormContent(state.form)) {
      try {
        localStorage.setItem(AUTOSAVE_KEY, JSON.stringify({
          form: state.form,
          activeDraftId: state.activeDraftId,
          savedAt: Date.now()
        }));
        state.localAutosaved = true;
        const ind = document.getElementById('autosave-indicator');
        if (ind) ind.style.display = 'inline-flex';
        const mInd = document.getElementById('mobile-autosave-indicator');
        if (mInd) mInd.style.display = 'inline-flex';
      } catch (e) {
        console.warn('Could not write local autosave', e);
      }
    }
  }, 400);
}

function clearLocalAutosave() {
  clearTimeout(autosaveTimer);
  try {
    localStorage.removeItem(AUTOSAVE_KEY);
  } catch {}
  state.localAutosaved = false;
}

function openDraft(id) {
  const d = state.drafts.find(x => x.id === id);
  if (!d) {
    notify('Draft not found.', 'error');
    return;
  }
  state.screen = 'form';
  state.editingId = null;
  state.activeDraftId = id;
  state.form = {
    items: (d.items || []).map(i => ({ ...i, id: i.id || uid() })),
    shirt: { ...blankMeasurements().shirt, ...(d.measurements?.shirt || {}) },
    pant: { ...blankMeasurements().pant, ...(d.measurements?.pant || {}) },
    bdNumber: d.bdNumber || '',
    customerName: d.customerName || '',
    phone: d.phone || '',
    orderDate: d.orderDate || todayISO(),
    deliveryDate: d.deliveryDate || '',
    ribbon: String(d.ribbon ?? ''),
    discountInput: d.discountInput || '',
    discountType: d.discountType || state.settings.defaultDiscountType || 'percentage',
    advance: d.advance !== '' && d.advance !== null && d.advance !== undefined ? Number(d.advance) : '',
    totalOverride: d.totalOverride !== null && d.totalOverride !== undefined && d.totalOverride !== '' ? Number(d.totalOverride) : null
  };
  state.dirty = false;
  state.localAutosaved = false;
  state.formError = '';
  state.mobileFormTab = 'items';
  state.modal = null;
  render();
  window.scrollTo({ top: 0, behavior: 'instant' });
}

async function saveAsDraft() {
  if (!canSaveAsDraft(state.form)) {
    notify('A draft needs a BD number and at least one item.', 'error');
    state.formError = 'A draft needs a BD number and at least one item.';
    render();
    return;
  }

  const lookup = knownCustomer(state.form.bdNumber);
  const name = lookup?.name || String(state.form.customerName || '').trim();

  const draftData = {
    id: uid(),
    category: 'Officer',
    bdNumber: String(state.form.bdNumber || '').trim(),
    customerName: name,
    phone: String(state.form.phone || '').trim(),
    orderDate: state.form.orderDate || todayISO(),
    deliveryDate: state.form.deliveryDate || '',
    ribbon: state.form.ribbon !== undefined ? state.form.ribbon : '',
    items: deepClone(state.form.items || []),
    measurements: {
      shirt: deepClone(state.form.shirt || {}),
      pant: deepClone(state.form.pant || {})
    },
    advance: state.form.advance !== '' && state.form.advance !== null && state.form.advance !== undefined ? Number(state.form.advance) : '',
    discountInput: state.form.discountInput || '',
    discountType: state.form.discountType || state.settings.defaultDiscountType || 'percentage',
    totalOverride: state.form.totalOverride !== null && state.form.totalOverride !== undefined && state.form.totalOverride !== '' ? Number(state.form.totalOverride) : null,
    total: currentTotal(),
    createdAt: Date.now(),
    updatedAt: Date.now()
  };

  try {
    if (isFirebaseConfigured && state.backendReady) {
      const fs = firebase, db = firebase.db;
      await fs.setDoc(fs.doc(db, 'officerDrafts', draftData.id), draftData);
    } else {
      state.drafts = [draftData, ...(state.drafts || [])];
      saveDraftsLocal();
    }
    clearLocalAutosave();
    state.form = null;
    state.activeDraftId = null;
    state.editingId = null;
    state.dirty = false;
    state.modal = null;
    state.screen = 'drafts';
    notify('Draft saved');
    render();
  } catch (e) {
    console.error(e);
    notify('Could not save draft.', 'error');
  }
}

async function updateDraft() {
  if (!state.activeDraftId) return saveAsDraft();

  if (!canSaveAsDraft(state.form)) {
    notify('A draft needs a BD number and at least one item.', 'error');
    state.formError = 'A draft needs a BD number and at least one item.';
    render();
    return;
  }

  const lookup = knownCustomer(state.form.bdNumber);
  const name = lookup?.name || String(state.form.customerName || '').trim();

  const existingDraft = state.drafts.find(d => d.id === state.activeDraftId);
  const updatedData = {
    ...(existingDraft || {}),
    id: state.activeDraftId,
    category: 'Officer',
    bdNumber: String(state.form.bdNumber || '').trim(),
    customerName: name,
    phone: String(state.form.phone || '').trim(),
    orderDate: state.form.orderDate || todayISO(),
    deliveryDate: state.form.deliveryDate || '',
    ribbon: state.form.ribbon !== undefined ? state.form.ribbon : '',
    items: deepClone(state.form.items || []),
    measurements: {
      shirt: deepClone(state.form.shirt || {}),
      pant: deepClone(state.form.pant || {})
    },
    advance: state.form.advance !== '' && state.form.advance !== null && state.form.advance !== undefined ? Number(state.form.advance) : '',
    discountInput: state.form.discountInput || '',
    discountType: state.form.discountType || state.settings.defaultDiscountType || 'percentage',
    totalOverride: state.form.totalOverride !== null && state.form.totalOverride !== undefined && state.form.totalOverride !== '' ? Number(state.form.totalOverride) : null,
    total: currentTotal(),
    updatedAt: Date.now()
  };

  try {
    if (isFirebaseConfigured && state.backendReady) {
      const fs = firebase, db = firebase.db;
      await fs.setDoc(fs.doc(db, 'officerDrafts', state.activeDraftId), updatedData, { merge: true });
    } else {
      const idx = state.drafts.findIndex(d => d.id === state.activeDraftId);
      if (idx >= 0) state.drafts[idx] = updatedData;
      else state.drafts.unshift(updatedData);
      saveDraftsLocal();
    }
    clearLocalAutosave();
    state.dirty = false;
    state.modal = null;
    notify('Draft updated');
    state.screen = 'drafts';
    render();
  } catch (e) {
    console.error(e);
    notify('Could not update draft.', 'error');
  }
}

async function deleteDraft(id) {
  try {
    if (isFirebaseConfigured && state.backendReady) {
      const fs = firebase, db = firebase.db;
      await fs.deleteDoc(fs.doc(db, 'officerDrafts', id));
    } else {
      state.drafts = state.drafts.filter(d => d.id !== id);
      saveDraftsLocal();
    }
    if (state.activeDraftId === id) {
      clearLocalAutosave();
      state.activeDraftId = null;
      state.form = null;
      state.screen = 'drafts';
    }
    state.modal = null;
    notify('Draft deleted.');
    render();
  } catch (e) {
    console.error(e);
    notify('Could not delete draft.', 'error');
  }
}

function renderDraftsScreen() {
  const drafts = [...(state.drafts || [])].sort((a, b) => (Number(b.updatedAt || b.createdAt || 0) - Number(a.updatedAt || a.createdAt || 0)));
  const count = drafts.length;

  const cardsHtml = drafts.map(d => {
    const total = calculateDraftTotal(d);
    const timeLabel = formatRelativeTime(d.updatedAt || d.createdAt);
    const itemsSummary = Array.isArray(d.items) && d.items.length
      ? d.items.map(it => `${esc(it.name)} ×${it.quantity}`).join(', ')
      : 'No items selected';
    const customerTitle = d.customerName ? esc(d.customerName) : (d.bdNumber ? esc(d.bdNumber) : 'Unnamed draft');

    return `
      <div class="draft-card" data-action="open-draft" data-id="${esc(d.id)}" role="button" tabindex="0" aria-label="Open draft for ${esc(customerTitle)}">
        <div class="draft-card-head">
          <div class="draft-card-title-group">
            <span class="draft-avatar">${icon('draft')}</span>
            <div style="min-width:0">
              <div class="draft-card-customer">${customerTitle}</div>
              <div class="draft-card-bd">Officer · ${esc(d.bdNumber || '—')}</div>
            </div>
          </div>
          <span class="badge draft-badge">Draft</span>
          <button type="button" class="ic delete-icon" title="Delete draft" aria-label="Delete draft" data-action="prompt-delete-draft" data-id="${esc(d.id)}" onclick="event.stopPropagation()">
            ${icon('trash')}
          </button>
        </div>
        <div class="draft-card-items">
          ${itemsSummary}
        </div>
        <div class="draft-card-meta">
          <span class="draft-total">${formatMoney(total)}</span>
          <span class="draft-saved-time">Saved ${timeLabel}</span>
        </div>
      </div>
    `;
  }).join('');

  return `
    <main class="page drafts-page">
      <div class="hd">
        <div>
          <h1>Drafts</h1>
          <div class="sub page-sub">${count} unfinished Officer order${count === 1 ? '' : 's'} saved across devices.</div>
        </div>
        <button type="button" class="btn" data-action="new-order">${icon('plus')}New order</button>
      </div>

      ${count > 0 ? `
        <div class="drafts-grid">
          ${cardsHtml}
        </div>
      ` : `
        <div class="empty-drafts-card">
          <div class="empty-drafts-icon">${icon('draft')}</div>
          <div class="empty-drafts-title">No drafts. Unfinished orders you save will appear here.</div>
          <div class="empty-drafts-sub">Tap Save as Draft on any new order to pause and resume whenever you are ready.</div>
          <button type="button" class="btn" data-action="new-order">${icon('plus')}Start a new order</button>
        </div>
      `}
    </main>
  `;
}

function renderDeliveryScreen() {
  const undelivered = state.orders.filter(o => (o.status || 'Pending') !== 'Delivered');
  const q = state.deliverySearch.trim().toLowerCase();
  const list = q
    ? undelivered.filter(o =>
        [o.customerName, o.customerBDNumber, o.phone, String(o.orderNumber || '')].some(v =>
          String(v || '').toLowerCase().includes(q)
        )
      )
    : undelivered;

  list.sort((a, b) => {
    if (!a.deliveryDate) return 1;
    if (!b.deliveryDate) return -1;
    return a.deliveryDate.localeCompare(b.deliveryDate);
  });

  const searchBar = `
    <div class="orders-toolbar" style="margin:20px 0">
      <label class="f search-field" style="flex:1">
        <div class="in">
          ${icon('search')}
          <input class="orders-search-input" data-focus="delivery-search" value="${esc(state.deliverySearch)}" placeholder="Search name, phone, BD number or order number" aria-label="Search delivery orders" autocomplete="off">
        </div>
      </label>
      ${state.deliverySearch ? `<button class="btn tr" data-action="clear-delivery-search">Clear</button>` : ''}
    </div>
  `;

  const tableHead = `
    <div class="rw h" style="grid-template-columns:80px 1.4fr 110px 110px 100px 110px;margin-bottom:8px">
      <span>Order</span>
      <span>Customer</span>
      <span>Status</span>
      <span>Delivery</span>
      <span class="rt">Due</span>
      <span class="rt">Action</span>
    </div>
  `;

  const rows = list.map(o => {
    const due = getOrderDue(o);
    const status = o.status || 'Pending';
    const dotClass = status === 'Cutting Slip – Done' ? 'status-dot-cutting' : 'status-dot-pending';
    return `
      <div class="delivery-row">
        <b>#${esc(o.orderNumber)}</b>
        <div>
          <b>${esc(o.customerName || 'Unnamed customer')}</b>
          <div class="xs sub">Officer · ${esc(o.customerBDNumber || '—')}</div>
        </div>
        <div>
          <span class="un" style="padding:3px 10px;font-size:11px">
            <i class="dot ${dotClass}"></i>${esc(status)}
          </span>
        </div>
        <div class="xs sub">${esc(dateLabel(o.deliveryDate))}</div>
        <b class="rt ${due > 0 ? 'neg' : ''}">${formatMoney(due)}</b>
        <div class="rt">
          <button type="button" class="btn-deliver" data-action="deliver-order" data-id="${esc(o.id)}">Deliver</button>
        </div>
      </div>
    `;
  }).join('');

  const empty = `
    <div class="tray empty-order-state" style="padding:48px 20px;text-align:center;background:#fff;border-radius:24px">
      <div class="tray empty-art-tray" style="margin:0 auto 16px"><img src="assets/empty-order-illustration.svg" alt="" aria-hidden="true"></div>
      <h2>Nothing waiting for delivery.</h2>
      <p class="sub" style="margin:6px 0 18px">${state.deliverySearch ? 'No pending orders match your search.' : 'All orders are currently delivered.'}</p>
      <button type="button" class="btn tr" data-action="back-to-orders">Back to Orders</button>
    </div>
  `;

  return `
    <main class="page delivery-page">
      ${renderNotice()}
      <a href="#" class="r detail-back-link" data-action="back-to-orders" style="margin-bottom:14px">${icon('back')}Orders</a>
      <div class="hd" style="margin-top:12px">
        <div>
          <h1>Delivery</h1>
          <div class="sub page-sub" style="font-size:17px;margin-top:6px">Mark completed garments as delivered upon customer pickup.</div>
        </div>
      </div>
      ${searchBar}
      <section class="delivery-panel">
        <div class="r" style="justify-content:space-between;margin-bottom:16px">
          <span class="sub sm">${list.length} orders waiting for delivery</span>
          <span class="xs sub">Tapping Deliver records today’s delivery date</span>
        </div>
        ${list.length ? `${tableHead}<div class="delivery-list">${rows}</div>` : empty}
      </section>
    </main>
  `;
}

function updatePrintPageStyle(size) {
  let styleEl = document.getElementById('dynamic-print-style');
  if (!styleEl) {
    styleEl = document.createElement('style');
    styleEl.id = 'dynamic-print-style';
    document.head.appendChild(styleEl);
  }
  const paperSize = size === 'A5' ? 'A5' : 'A4';
  styleEl.textContent = `@page { size: ${paperSize}; margin: 12mm 15mm; }`;
}

function renderCuttingSlipPaper(order) {
  const shopName = state.settings.shopName || 'Darzi Tailor Shop';
  const paperSize = state.settings.cuttingSlipPaperSize || 'A4';
  updatePrintPageStyle(paperSize);

  const items = order.items || [];
  const shirt = order.measurements?.shirt || {};
  const pant = order.measurements?.pant || {};

  const shirtFields = ['Length','Chest','Belly','Hip','Shoulder','Sleeve','Collar','Front','Back'];
  const filledShirt = shirtFields.filter(f => String(shirt[f] || '').trim());
  const shirtHwNotes = String(shirt['Hand Written Notes'] || '').trim();
  const shirtExtraNotes = String(shirt['Extra Notes'] || '').trim();

  const pantFields = ['Length','Waist','Hip','High','Thai','Leg Open'];
  const filledPant = pantFields.filter(f => String(pant[f] || '').trim());
  const pantHwNotes = String(pant['Hand Written Notes'] || '').trim();
  const pantExtraNotes = String(pant['Extra Notes'] || '').trim();

  const itemsContent = items.length ? `
    <table class="print-table">
      <thead>
        <tr>
          <th style="width:40px">#</th>
          <th>Item description</th>
          <th class="rt" style="width:90px">Quantity</th>
        </tr>
      </thead>
      <tbody>
        ${items.map((it, idx) => `
          <tr>
            <td>${idx + 1}</td>
            <td><b>${esc(it.name)}</b></td>
            <td class="rt"><b>${esc(it.quantity)}</b></td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  ` : `
    <div style="padding:20px;background:#f9f9fb;border:1px dashed #ccc;text-align:center;color:#666;margin-bottom:20px;border-radius:8px">
      No cutting slip found for this category in the selected order.
    </div>
  `;

  const shirtContent = (filledShirt.length || shirtHwNotes || shirtExtraNotes) ? `
    <div class="print-measure-block avoid-break">
      <div class="print-measure-title">Shirt Measurements</div>
      ${filledShirt.length ? `
        <div class="print-measure-grid">
          ${filledShirt.map(f => `
            <div class="print-measure-cell">
              <div class="print-measure-lbl">${esc(f)}</div>
              <div class="print-measure-num">${esc(shirt[f])}</div>
            </div>
          `).join('')}
        </div>
      ` : ''}
      ${shirtHwNotes ? `<div class="print-note-box"><b>Handwritten Notes:</b> ${esc(shirtHwNotes)}</div>` : ''}
      ${shirtExtraNotes ? `<div class="print-note-box"><b>Extra Notes:</b> ${esc(shirtExtraNotes)}</div>` : ''}
    </div>
  ` : '';

  const pantContent = (filledPant.length || pantHwNotes || pantExtraNotes) ? `
    <div class="print-measure-block avoid-break">
      <div class="print-measure-title">Pant Measurements</div>
      ${filledPant.length ? `
        <div class="print-measure-grid">
          ${filledPant.map(f => `
            <div class="print-measure-cell">
              <div class="print-measure-lbl">${esc(f)}</div>
              <div class="print-measure-num">${esc(pant[f])}</div>
            </div>
          `).join('')}
        </div>
      ` : ''}
      ${pantHwNotes ? `<div class="print-note-box"><b>Handwritten Notes:</b> ${esc(pantHwNotes)}</div>` : ''}
      ${pantExtraNotes ? `<div class="print-note-box"><b>Extra Notes:</b> ${esc(pantExtraNotes)}</div>` : ''}
    </div>
  ` : '';

  return `
    <div class="paper-sheet size-${paperSize.toLowerCase()}">
      <div class="print-paper-header">
        <div class="print-shop-branding">
          <div class="print-logo-monogram">${esc(shopName.slice(0, 1).toUpperCase())}</div>
          <div>
            <div class="print-shop-name">${esc(shopName)}</div>
            <div class="print-shop-sub">Workshop Tailor Ticket</div>
          </div>
        </div>
        <div class="print-doc-meta">
          <div class="print-doc-title">Cutting Slip</div>
          <div class="print-doc-no">Order #${esc(order.orderNumber)}</div>
          <div class="print-doc-date">Delivery: <b>${esc(dateLabel(order.deliveryDate))}</b></div>
        </div>
      </div>

      <div class="print-info-grid">
        <div class="print-info-item">
          <span class="print-info-label">Customer Name</span>
          <span class="print-info-val">${esc(order.customerName || 'Unnamed customer')}</span>
        </div>
        <div class="print-info-item">
          <span class="print-info-label">BD Number</span>
          <span class="print-info-val">Officer · ${esc(order.customerBDNumber || '—')}</span>
        </div>
        <div class="print-info-item">
          <span class="print-info-label">Order Date</span>
          <span class="print-info-val">${esc(dateLabel(order.orderDate))}</span>
        </div>
        <div class="print-info-item">
          <span class="print-info-label">Ribbon</span>
          <span class="print-info-val">${order.ribbon !== undefined && order.ribbon !== '' ? esc(order.ribbon) : 'None'}</span>
        </div>
      </div>

      ${itemsContent}
      ${shirtContent}
      ${pantContent}
    </div>
  `;
}

function renderInvoicePaper(order) {
  const shopName = state.settings.shopName || 'Darzi Tailor Shop';
  const logo = state.settings.shopLogo || '';
  const terms = state.settings.terms || '';
  const paperSize = state.settings.invoicePaperSize || 'A4';
  updatePrintPageStyle(paperSize);

  const items = order.items || [];
  const total = Number(order.total) || 0;
  const disc = Number(order.discountAmount) || 0;
  const advance = Number(order.advance) || 0;
  const laterPayments = getLaterPaymentsTotal(order);
  const due = getOrderDue(order);

  const logoMarkup = logo
    ? `<img src="${esc(logo)}" alt="${esc(shopName)}" class="print-logo-img"/>`
    : `<div class="print-logo-monogram">${esc(shopName.slice(0, 1).toUpperCase())}</div>`;

  return `
    <div class="paper-sheet size-${paperSize.toLowerCase()}">
      <div class="print-paper-header">
        <div class="print-shop-branding">
          ${logoMarkup}
          <div>
            <div class="print-shop-name">${esc(shopName)}</div>
            <div class="print-shop-sub">Customer Billing Statement</div>
          </div>
        </div>
        <div class="print-doc-meta">
          <div class="print-doc-title">Invoice</div>
          <div class="print-doc-no">#${esc(order.orderNumber)}</div>
          <div class="print-doc-date">Date: ${esc(dateLabel(order.orderDate))}</div>
        </div>
      </div>

      <div class="print-info-grid">
        <div class="print-info-item">
          <span class="print-info-label">Customer Name</span>
          <span class="print-info-val">${esc(order.customerName || 'Unnamed customer')}</span>
        </div>
        <div class="print-info-item">
          <span class="print-info-label">BD Number</span>
          <span class="print-info-val">Officer · ${esc(order.customerBDNumber || '—')}</span>
        </div>
        <div class="print-info-item">
          <span class="print-info-label">Phone</span>
          <span class="print-info-val">${esc(order.phone || '—')}</span>
        </div>
        <div class="print-info-item">
          <span class="print-info-label">Delivery Date</span>
          <span class="print-info-val">${esc(dateLabel(order.deliveryDate))}</span>
        </div>
      </div>

      <table class="print-table">
        <thead>
          <tr>
            <th style="width:40px">#</th>
            <th>Item description</th>
            <th class="rt" style="width:60px">Qty</th>
            <th class="rt" style="width:100px">Unit price</th>
            <th class="rt" style="width:110px">Total</th>
          </tr>
        </thead>
        <tbody>
          ${items.map((it, idx) => `
            <tr>
              <td>${idx + 1}</td>
              <td><b>${esc(it.name)}</b></td>
              <td class="rt">${esc(it.quantity)}</td>
              <td class="rt">${formatMoney(it.price)}</td>
              <td class="rt"><b>${formatMoney(Number(it.price) * Number(it.quantity))}</b></td>
            </tr>
          `).join('')}
        </tbody>
      </table>

      <div class="print-money-layout avoid-break">
        <div class="print-money-box">
          <div class="print-money-row">
            <span>Subtotal</span>
            <span>${formatMoney(total)}</span>
          </div>
          ${disc > 0 ? `
            <div class="print-money-row">
              <span>Discount</span>
              <span>− ${formatMoney(disc)}</span>
            </div>
          ` : ''}
          <div class="print-money-row">
            <span>Advance received</span>
            <span>${formatMoney(advance)}</span>
          </div>
          ${laterPayments > 0 ? `
            <div class="print-money-row">
              <span>Received later</span>
              <span class="pos">${formatMoney(laterPayments)}</span>
            </div>
          ` : ''}
          <div class="print-money-row due-row">
            <span>Due Balance</span>
            <span>${formatMoney(due)}</span>
          </div>
        </div>
      </div>

      ${terms ? `
        <div class="print-terms avoid-break">
          <b>Terms &amp; Instructions:</b><br/>
          ${esc(terms)}
        </div>
      ` : ''}
    </div>
  `;
}

function renderPrintPage() {
  const o = orderById(state.printOrderId);
  if (!o) {
    state.screen = 'orders';
    return renderOrders();
  }
  const isSlip = state.screen === 'print-slip';
  const paper = isSlip ? renderCuttingSlipPaper(o) : renderInvoicePaper(o);
  const paperSize = isSlip ? (state.settings.cuttingSlipPaperSize || 'A4') : (state.settings.invoicePaperSize || 'A4');
  const returnLabel = state.printReturnScreen === 'details' ? 'Order Details' : state.printReturnScreen === 'form' ? 'Order Form' : 'Orders';

  return `
    <main class="page print-preview-page">
      <div class="print-preview-toolbar no-print">
        <div class="print-toolbar-group">
          <button type="button" class="btn tr" data-action="back-from-print" style="height:38px;padding:0 14px">
            ${icon('back')}Back to ${returnLabel}
          </button>
          <button type="button" class="btn tr" data-action="switch-print-paper" style="height:38px;padding:0 16px;font-weight:600">
            ${isSlip ? `${icon('invoice')}Switch to Invoice` : `${icon('slip')}Switch to Cutting Slip`}
          </button>
        </div>
        <div class="print-toolbar-group">
          <span class="sub xs" style="margin-right:6px">Paper size: <b>${esc(paperSize)}</b></span>
          <button type="button" class="btn" data-action="trigger-print" style="height:38px;padding:0 20px">
            ${icon('print')}Print ${isSlip ? 'Slip' : 'Invoice'}
          </button>
        </div>
      </div>
      ${paper}
    </main>
  `;
}

function openPrint(type, orderId, returnScreen = null) {
  state.printOrderId = orderId;
  state.printReturnScreen = returnScreen || (['orders', 'details', 'form', 'delivery'].includes(state.screen) ? state.screen : 'orders');
  state.screen = type === 'slip' ? 'print-slip' : 'print-invoice';
  state.mobileMenuOpen = false;
  render();
  window.scrollTo({ top: 0, behavior: 'instant' });
}

function renderSettingsItemModal() {
  const m = state.settingsItemModal;
  if (!m) return '';
  const item = m.item || { name: '', price: '', needsPriceCheck: false };
  return `
    <div class="dialog-overlay" data-action="close-item-modal-bg">
      <section class="dl editor-dialog" role="dialog" aria-modal="true" aria-labelledby="item-modal-title">
        <span class="ic dialog-icon">${icon('edit')}</span>
        <h2 id="item-modal-title">${m.mode === 'edit' ? 'Edit item' : 'Add item'}</h2>
        <div class="sub dialog-sub">Set the catalogue name and current price. Saved orders keep their copied prices.</div>
        <div class="stk dialog-fields">
          <label class="f">Item name<input id="catalogue-name" data-setting-item="name" data-focus="item-modal-name" value="${esc(item.name)}" placeholder="e.g. Officer Shirt"></label>
          <label class="f">Price (৳)<input id="catalogue-price" data-setting-item="price" data-focus="item-modal-price" inputmode="decimal" type="number" min="0" step="0.01" value="${esc(item.price)}" placeholder="0"></label>
        </div>
        <div class="xs sub" style="margin-top:12px">Items marked “check price” keep that tag until the price is changed.</div>
        <div class="r dialog-actions">
          <button class="btn tr" data-action="close-item-modal">Cancel</button>
          <button class="btn" data-action="save-item">Save item</button>
        </div>
      </section>
    </div>
  `;
}

function renderSettings() {
  const items = [...(state.settings.items || [])];
  const quick = state.settingsQuickAdd || { name: '', price: '' };
  const ribbon = state.settings.ribbonValues || [];
  const tape = ribbon.map((v, i) => `<span class="bd" style="position:absolute;left:${ribbon.length < 2 ? 50 : 6 + i * (88 / (ribbon.length - 1))}%;top:26px;transform:translateX(-50%)">${esc(v)}</span>`).join('');
  const rows = items.map(item => `
    <div class="rw setting-item-row" style="grid-template-columns:minmax(0,1fr) 110px 100px 84px">
      <b>${esc(item.name)}</b>
      <span class="rt setting-item-price">${formatMoney(item.price)}</span>
      <span>${item.needsPriceCheck ? '<span class="ck">check price</span>' : ''}</span>
      <span class="r setting-item-actions">
        <button class="ic" data-action="edit-item" data-id="${esc(item.id)}" title="Edit ${esc(item.name)}" aria-label="Edit ${esc(item.name)}">${icon('edit')}</button>
        <button class="ic delete-icon" data-action="remove-item" data-id="${esc(item.id)}" title="Remove ${esc(item.name)}" aria-label="Remove ${esc(item.name)}">${icon('trash')}</button>
      </span>
    </div>
  `).join('');

  const shopName = state.settings.shopName || 'Darzi Tailor Shop';
  const logo = state.settings.shopLogo || '';
  const terms = state.settings.terms || '';

  return `
    <main class="page settings-page">
      ${renderNotice()}
      <div class="hd">
        <div>
          <h1>Settings</h1>
          <div class="sub page-sub" style="font-size:17px;margin-top:6px">Prices, invoice templates, paper sizes and delivery thresholds.</div>
        </div>
      </div>

      <div class="cols settings-cols">
        <div class="stk">
          <!-- Items and Prices -->
          <section class="pnl settings-items-panel">
            <div class="r settings-panel-title">
              <h2>Items &amp; Prices</h2>
              <span class="sp sub sm">${items.length} items</span>
            </div>
            <div class="tray r settings-quick-add">
              <label class="f settings-name-field">Item name<input data-setting-quick="name" data-focus="setting-item-name" value="${esc(quick.name || '')}" placeholder="Safari" aria-label="New item name"></label>
              <label class="f settings-price-field">Price<input data-setting-quick="price" data-focus="setting-item-price" type="number" min="0" step="0.01" value="${esc(quick.price ?? '')}" placeholder="৳" aria-label="New item price"></label>
              <button class="btn settings-add-button" data-action="add-item-inline">${icon('plus')}Add item</button>
            </div>
            <div class="rw h setting-table-head" style="grid-template-columns:minmax(0,1fr) 110px 100px 84px">
              <span>Item</span><span class="rt">Price</span><span></span><span></span>
            </div>
            <div class="settings-item-list">
              ${rows || '<div class="sub sm" style="padding:16px 12px">No items yet. Add the first catalogue item above.</div>'}
            </div>
            <div class="xs sub settings-footnote">Changing or removing an item never changes orders that already exist.</div>
          </section>

          <!-- Invoice Template -->
          <section class="pnl">
            <h2>Invoice template</h2>
            <div class="sub sm" style="margin:6px 0 16px">Customize your shop branding, logo and billing terms on customer invoices.</div>
            <div class="stk" style="gap:14px">
              <label class="f">Shop name
                <input type="text" data-setting-field="shopName" data-focus="setting-shopName" value="${esc(shopName)}" placeholder="e.g. Darzi Tailor Shop" />
              </label>

              <div class="r" style="align-items:flex-start;gap:16px">
                <div style="flex:1">
                  <span style="font-size:12px;font-weight:600;display:block;margin-bottom:6px">Shop logo</span>
                  <input type="file" id="logo-file-input" accept="image/*" style="display:none" data-change="upload-logo" />
                  <div class="r" style="gap:8px">
                    <button type="button" class="btn tr" style="height:36px;font-size:13px" onclick="document.getElementById('logo-file-input').click()">
                      ${logo ? 'Change logo' : 'Upload logo'}
                    </button>
                    ${logo ? `<button type="button" class="btn tr delete-icon" style="height:36px;font-size:13px" data-action="remove-logo">Remove</button>` : ''}
                  </div>
                  <span class="xs sub" style="display:block;margin-top:6px">Appears on printed invoices. Supports PNG, JPG and SVG.</span>
                </div>
                ${logo ? `
                  <div style="width:72px;height:52px;border:1px solid var(--hl);border-radius:10px;padding:4px;display:grid;place-items:center;background:#fff">
                    <img src="${esc(logo)}" alt="Logo preview" style="max-width:100%;max-height:100%;object-fit:contain"/>
                  </div>
                ` : `
                  <div class="print-logo-monogram" style="width:48px;height:48px;font-size:18px">${esc(shopName.slice(0, 1).toUpperCase())}</div>
                `}
              </div>

              <label class="f">Invoice terms and conditions
                <textarea rows="3" data-setting-field="terms" data-focus="setting-terms" placeholder="Terms and notes printed at the bottom of customer invoices">${esc(terms)}</textarea>
              </label>

              <!-- Live Header Preview -->
              <div style="margin-top:6px">
                <span class="xs sub" style="font-weight:600;text-transform:uppercase;letter-spacing:.04em">Live Invoice Header Preview</span>
                <div class="invoice-preview-card">
                  <div class="print-paper-header" style="margin-bottom:0;padding-bottom:12px">
                    <div class="print-shop-branding">
                      ${logo ? `<img src="${esc(logo)}" alt="" class="print-logo-img" style="max-height:38px"/>` : `<div class="print-logo-monogram" style="width:38px;height:38px;font-size:16px">${esc(shopName.slice(0, 1).toUpperCase())}</div>`}
                      <div>
                        <div class="print-shop-name" style="font-size:16px">${esc(shopName)}</div>
                        <div class="print-shop-sub">Customer Billing Statement</div>
                      </div>
                    </div>
                    <div class="print-doc-meta">
                      <div class="print-doc-title" style="font-size:16px">Invoice</div>
                      <div class="print-doc-no" style="font-size:13px">#531</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>

        <div class="stk settings-side">
          <!-- Print Paper Sizes -->
          <section class="pnl">
            <h2>Print paper size</h2>
            <div class="sub sm" style="margin:6px 0 16px">Select paper sizing for printing cutting slips and customer invoices.</div>
            <div class="stk" style="gap:14px">
              <label class="f">Invoice paper size
                <select class="form-select" data-setting-field="invoicePaperSize">
                  <option value="A4" ${state.settings.invoicePaperSize === 'A4' ? 'selected' : ''}>A4 (Standard paper)</option>
                  <option value="A5" ${state.settings.invoicePaperSize === 'A5' ? 'selected' : ''}>A5 (Compact slip)</option>
                </select>
              </label>
              <label class="f">Cutting slip paper size
                <select class="form-select" data-setting-field="cuttingSlipPaperSize">
                  <option value="A4" ${state.settings.cuttingSlipPaperSize === 'A4' ? 'selected' : ''}>A4 (Standard paper)</option>
                  <option value="A5" ${state.settings.cuttingSlipPaperSize === 'A5' ? 'selected' : ''}>A5 (Compact slip)</option>
                </select>
              </label>
            </div>
          </section>

          <!-- Upcoming Delivery Days -->
          <section class="pnl">
            <h2>Upcoming delivery days</h2>
            <div class="sub sm" style="margin:6px 0 16px">The number of days ahead counted in the Upcoming to Deliver card.</div>
            <div class="r" style="gap:12px;align-items:center">
              <label class="f" style="width:130px">
                <input type="number" min="1" max="60" step="1" id="upcoming-days-input" data-setting-field="upcomingDeliveryDays" value="${state.settings.upcomingDeliveryDays || 3}" />
              </label>
              <span class="sub sm">days from today (default: 3)</span>
            </div>
          </section>

          <!-- Default Discount Type -->
          <section class="pnl">
            <h2>Default discount type</h2>
            <div class="sub sm" style="margin:6px 0 16px">The starting choice on every new order.</div>
            <div class="seg discount-segment">
              <button type="button" class="${state.settings.defaultDiscountType === 'percentage' ? 'on' : ''}" data-action="set-discount-type" data-type="percentage" aria-pressed="${state.settings.defaultDiscountType === 'percentage'}">Percentage</button>
              <button type="button" class="${state.settings.defaultDiscountType === 'taka' ? 'on' : ''}" data-action="set-discount-type" data-type="taka" aria-pressed="${state.settings.defaultDiscountType === 'taka'}">Taka</button>
            </div>
          </section>

          <!-- Ribbon values -->
          <section class="pnl ribbon-settings-panel">
            <h2>Ribbon values</h2>
            <div class="sub sm" style="margin:6px 0 16px">The numbers in the Ribbon dropdown.</div>
            <div class="tape ribbon-tape" style="height:58px;margin-bottom:16px">${tape}</div>
            <div class="r ribbon-chip-row" style="flex-wrap:wrap;gap:8px">
              ${ribbon.map(v => `
                <button type="button" class="ch ribbon-choice" data-action="remove-ribbon" data-value="${esc(v)}" title="Remove ribbon ${esc(v)}" aria-label="Remove ribbon ${esc(v)}">
                  <span>${esc(v)}</span>${icon('close')}
                </button>
              `).join('') || '<span class="sub sm">No ribbon values added.</span>'}
            </div>
            <div class="r ribbon-add-row">
              <label class="f">
                <span>New value</span>
                <input id="ribbon-new-value" class="ribbon-number-input" type="number" step="1" data-focus="ribbon-add" placeholder="Number" aria-label="New ribbon number">
              </label>
              <button class="btn tr" data-action="add-ribbon">${icon('plus')}Add value</button>
            </div>
          </section>
        </div>
      </div>
      ${renderSettingsItemModal()}
    </main>
  `;
}

function renderItemSuggestions() {
  if (!state.itemPickerOpen) return '';
  const q = state.itemSearch.trim().toLowerCase();
  const list = (state.settings.items || []).filter(i => !q || i.name.toLowerCase().includes(q)).slice(0, 12);
  if (!list.length) return `<div class="item-suggestions"><div class="sub sm" style="padding:14px">No items match this search.</div></div>`;
  return `
    <div class="item-suggestions" role="listbox" aria-label="Available items">
      ${list.map(i => `
        <button type="button" class="item-suggestion" data-action="choose-item" data-id="${esc(i.id)}" role="option">
          <span><b>${esc(i.name)}</b>${i.needsPriceCheck ? '<small class="ck">check price</small>' : ''}</span>
          <strong>${formatMoney(i.price)}</strong>
        </button>
      `).join('')}
    </div>
  `;
}

function fieldTemplate(label, key, value = '', opts = {}) {
  const wide = opts.wide ? ' style="grid-column:1/-1"' : '';
  const isNote = key.includes('Notes');
  const klass = `f${opts.dense ? ' d' : ''}`;
  const fieldId = opts.id || `f-${key}`;
  return `
    <label class="${klass}"${wide}>
      ${esc(label)}
      ${isNote
        ? `<textarea class="measurement-note-input" id="${esc(fieldId)}" data-form="${esc(key)}" data-focus="form-${esc(key)}" placeholder="${esc(opts.placeholder || '')}" rows="2">${esc(value)}</textarea>`
        : `<input id="${esc(fieldId)}" data-form="${esc(key)}" data-focus="form-${esc(key)}" value="${esc(value)}" placeholder="${esc(opts.placeholder || '')}" ${opts.type ? `type="${opts.type}"` : ''} ${opts.min !== undefined ? `min="${opts.min}"` : ''} ${opts.step ? `step="${opts.step}"` : ''} ${opts.inputmode ? `inputmode="${opts.inputmode}"` : ''}/>`}
      ${opts.helper ? `<small>${esc(opts.helper)}</small>` : ''}
    </label>
  `;
}

function measurementSection(kind, title) {
  const obj = state.form?.[kind] || {};
  const numeric = MEASUREMENT_FIELDS[kind].filter(x => !x.includes('Notes'));
  const notes = MEASUREMENT_FIELDS[kind].filter(x => x.includes('Notes'));
  return `
    <div class="tray measurement-tray">
      <b>${title}</b>
      <div class="g3 measurement-input-grid" style="margin-top:12px;gap:12px">
        ${numeric.map(name => fieldTemplate(name, `${kind}.${name}`, obj[name] || '', { type: 'text', dense: true })).join('')}
      </div>
      <div class="stk measurement-notes" style="margin-top:12px">
        ${notes.map(name => fieldTemplate(name, `${kind}.${name}`, obj[name] || '', { dense: true, placeholder: name === 'Hand Written Notes' ? 'Handwritten measurement notes' : 'Extra details' })).join('')}
      </div>
    </div>
  `;
}

function filteredAndSortedCustomers() {
  let list = [...(state.customers || [])];
  const q = (state.customerSearch || '').trim().toLowerCase();
  if (q) {
    list = list.filter(c =>
      (c.name || '').toLowerCase().includes(q) ||
      (c.phone || '').toLowerCase().includes(q) ||
      (c.bdNumber || '').toLowerCase().includes(q)
    );
  }

  const sort = state.customerSort || 'newest';
  if (sort === 'name') {
    list.sort((a, b) => (a.name || '').localeCompare(b.name || ''));
  } else if (sort === 'due') {
    list.sort((a, b) => {
      const dueA = getCustomerStats(a.bdNumber).due;
      const dueB = getCustomerStats(b.bdNumber).due;
      return dueB - dueA;
    });
  } else {
    list.sort((a, b) => Number(b.createdAt || 0) - Number(a.createdAt || 0));
  }
  return list;
}

function getCustomerSuggestions(field, query) {
  const q = String(query || '').trim().toLowerCase();
  if (!q) return [];
  return (state.customers || []).filter(c => {
    const nameMatch = (c.name || '').toLowerCase().includes(q);
    const bdMatch = (c.bdNumber || '').toLowerCase().includes(q);
    return nameMatch || bdMatch;
  }).slice(0, 5);
}

function renderCustomerFormField(label, key, value = '', opts = {}) {
  const isSuggField = key === 'customerName' || key === 'bdNumber';
  const showSugg = isSuggField && state.customerSuggestionsOpen && state.customerSuggestionField === key;
  const suggestions = showSugg ? getCustomerSuggestions(key, value) : [];
  const fieldId = opts.id || `f-${key}`;

  return `
    <div class="f customer-field-wrap">
      <label for="${esc(fieldId)}">${esc(label)}</label>
      <input id="${esc(fieldId)}" data-form="${esc(key)}" data-focus="form-${esc(key)}" value="${esc(value)}" placeholder="${esc(opts.placeholder || '')}" autocomplete="off" ${opts.inputmode ? `inputmode="${opts.inputmode}"` : ''}/>
      ${showSugg && suggestions.length > 0 ? `
        <div class="customer-suggestions" role="listbox">
          ${suggestions.map(c => `
            <button type="button" class="customer-suggestion-item" data-action="pick-customer-suggestion" data-bd="${esc(c.bdNumber)}" role="option">
              <div>
                <div class="sugg-name">${esc(c.name)}</div>
                <div class="sugg-bd">${esc(c.bdNumber)}${c.phone ? ` · ${esc(c.phone)}` : ''}</div>
              </div>
            </button>
          `).join('')}
        </div>
      ` : ''}
    </div>
  `;
}

function renderForm() {
  const f = state.form || newForm();
  const total = currentTotal(), disc = currentDiscount(), due = currentDue();
  const customer = knownCustomer(f.bdNumber);
  const existingOrder = state.editingId ? orderById(state.editingId) : null;
  const laterPayments = existingOrder ? getLaterPaymentsTotal(existingOrder) : 0;
  const savedCustomer = f.bdNumber ? knownCustomer(f.bdNumber) : null;
  const isDifferentName = savedCustomer && String(f.customerName || '').trim() && normBD(f.customerName) !== normBD(savedCustomer.name);
  const customerSavedNameAlert = isDifferentName ? `
    <div class="customer-saved-name-banner" role="alert">
      <span class="dot" style="background:var(--em);margin-top:4px"></span>
      <div>
        <b>${esc(savedCustomer.bdNumber)} is saved as ${esc(savedCustomer.name)}.</b>
        <div>The saved name will be used. To change a name, edit the customer.</div>
      </div>
    </div>
  ` : '';
  const customerMatchNote = (savedCustomer && !isDifferentName) ? `
    <div class="customer-match-note"><i class="dot" style="background:var(--pos)"></i><span>Filled from the saved customer</span></div>
  ` : '';


  const itemLineRows = f.items.length ? f.items.map(item => `
    <div class="li order-item-line">
      <span>
        <b>${esc(item.name)}</b>
        <div class="xs sub">${formatMoney(item.price)} each${(state.settings.items.find(s => s.name === item.name)?.needsPriceCheck) ? ' · check price' : ''}</div>
      </span>
      <span class="sub order-item-qty">× ${esc(item.quantity)}</span>
      <span class="sub rt">${formatMoney(item.price)}</span>
      <b class="rt">${formatMoney(Number(item.price) * Number(item.quantity))}</b>
      <button type="button" class="ic delete-icon item-remove" data-action="remove-order-item" data-id="${esc(item.id)}" aria-label="Remove ${esc(item.name)}" title="Remove item">${icon('close')}</button>
    </div>
  `).join('') : `
    <div class="tray no-items">
      <div class="sub sm">No items added yet. Search the catalogue above, choose an item, then tap Add item.</div>
    </div>
  `;

  const headingTitle = state.editingId ? 'Edit order' : (state.activeDraftId ? 'Draft order' : 'New order');
  const headingSub = state.editingId
    ? `Officer order #${esc(existingOrder?.orderNumber ?? '')}. Update items, measurements and payments.`
    : (state.activeDraftId
        ? 'Officer draft. Finish the order or update draft details.'
        : 'Officer order. Items, measurements and payment in one place.');

  return `
    <main class="page form-page form-desktop">
      ${renderNotice()}
      <div class="hd form-page-heading">
        <div>
          <h1>${headingTitle}</h1>
          <div class="sub page-sub" style="font-size:17px;margin-top:6px">${headingSub}</div>
          <div class="r form-status-row">
            <span class="bd">Officer</span>
            ${state.activeDraftId ? `<span class="badge draft-badge">Draft</span>` : ''}
            ${state.editingId ? `<span class="un"><i class="dot ${existingOrder?.status === 'Delivered' ? 'status-dot-delivered' : existingOrder?.status === 'Cutting Slip – Done' ? 'status-dot-cutting' : 'status-dot-pending'}"></i>${esc(existingOrder?.status || 'Pending')}</span>` : ''}
            ${state.editingId && state.dirty ? '<span class="un"><i class="dot" style="background:var(--em)"></i>Unsaved changes</span>' : ''}
            ${!state.editingId ? `<span id="autosave-indicator" class="un autosave-indicator" style="${state.localAutosaved ? '' : 'display:none'}">${icon('check')}Draft saved locally</span>` : ''}
          </div>
        </div>
        <button class="btn gh" data-action="cancel-form">Cancel</button>
      </div>

      <form id="order-form" class="cols form-layout" novalidate>
        <div class="stk form-main-column">
          <section class="pnl form-items-panel">
            <h2>Items</h2>
            <div class="r form-item-picker-row" style="align-items:flex-end;margin:16px 0">
              <label class="f item-label">Item
                <div class="picker-wrap">
                  <div class="in item-search-box">${icon('search')}<input id="item-search" data-focus="item-search" value="${esc(state.itemSearch)}" placeholder="Search by name" autocomplete="off" aria-label="Search items" role="combobox" aria-expanded="${state.itemPickerOpen}"/></div>
                  ${renderItemSuggestions()}
                </div>
              </label>
              <label class="f quantity-label">Quantity
                <input id="item-quantity" type="number" min="1" step="1" data-focus="item-quantity" value="${esc(state.quantity)}" aria-label="Quantity"/>
              </label>
              <button type="button" class="btn tr add-item-btn" data-action="add-order-item">${icon('plus')}Add item</button>
            </div>
            <div class="tray order-item-lines">${itemLineRows}</div>
          </section>

          <section class="pnl form-customer-panel">
            <h2>Customer and dates</h2>
            <div class="g3" style="margin-top:16px">
              ${renderCustomerFormField('BD Number', 'bdNumber', f.bdNumber, { placeholder: 'BD/12408' })}
              ${renderCustomerFormField('Customer Name', 'customerName', f.customerName, { placeholder: 'Rank and full name' })}
              ${fieldTemplate('Phone', 'phone', f.phone, { placeholder: 'Not added', inputmode: 'tel' })}
            </div>
            <div class="g3" style="margin-top:14px">
              ${fieldTemplate('Order Date', 'orderDate', f.orderDate, { type: 'date' })}
              ${fieldTemplate('Delivery Date', 'deliveryDate', f.deliveryDate, { type: 'date' })}
              <label class="f">Ribbon
                <select class="form-select" id="f-ribbon" data-form="ribbon" data-focus="form-ribbon">
                  <option value="">Choose ribbon</option>
                  ${(state.settings.ribbonValues || []).map(v => `<option value="${esc(v)}" ${String(f.ribbon) === String(v) ? 'selected' : ''}>${esc(v)}</option>`).join('')}
                </select>
              </label>
            </div>
            ${customerSavedNameAlert}
            ${customerMatchNote}
          </section>

          <section class="pnl form-measurements-panel">
            <h2>Measurements</h2>
            <div class="g2 measurement-groups" style="margin-top:16px;align-items:start">
              ${measurementSection('shirt', 'Shirt')}
              ${measurementSection('pant', 'Pant')}
            </div>
          </section>
          ${state.formError ? `<div class="bn form-error" role="alert"><i class="dot" style="background:var(--neg)"></i><b>${esc(state.formError)}</b></div>` : ''}
        </div>

        <aside class="dark form-money-panel">
          <div class="r">
            <span style="opacity:.76">Total amount</span>
            ${state.editingId && state.totalEditOpen ? `
              <input class="dark-total" id="f-total" data-form="totalOverride" data-focus="form-totalOverride" inputmode="decimal" type="number" min="0" step="0.01" value="${Number(total.toFixed(2))}" aria-label="Total amount"/>
            ` : `
              <button type="button" class="dark-total-value" ${state.editingId ? 'data-action="enable-total-edit"' : ''} aria-label="Total amount${state.editingId ? ' — tap to edit' : ''}">${formatMoney(total)}</button>
            `}
          </div>
          <div class="xs money-helper">${state.editingId ? (state.totalEditOpen ? 'Type the revised total amount.' : 'Tap the total amount to type over it.') : 'Automatic. Price × quantity, added up.'}</div>
          <div class="stk money-fields" style="gap:14px">
            <label class="f dark-field">Discount
              <input id="f-discount" data-form="discountInput" data-focus="form-discountInput" type="text" value="${esc(f.discountInput)}" placeholder="10% or a taka amount" inputmode="decimal"/>
              <small>${f.discountType === 'percentage' ? 'Default: percentage' : 'Default: taka'} · use % for percentage</small>
            </label>
            <label class="f dark-field">Advance
              <input id="f-advance" data-form="advance" data-focus="form-advance" type="number" min="0" step="0.01" value="${esc(f.advance)}" inputmode="decimal"/>
              ${laterPayments > 0 ? `<div class="received-later-line">${icon('check')} Received later: ${formatMoney(laterPayments)}</div>` : ''}
            </label>
          </div>
          <div class="dark-divider"></div>
          <div class="r">
            <span style="opacity:.76">Due</span>
            <span class="sp xs" style="opacity:.65">Total − discount − payments</span>
          </div>
          <div class="nl ${due > 0 ? 'neg' : 'pos'} form-due-number">${formatMoney(due)}</div>
          <div class="pr form-due-progress">
            <i style="width:${total > 0 ? Math.max(0, Math.min(100, ((total - due) / total) * 100)) : 0}%"></i>
          </div>
          <div class="xs money-helper">Discount calculated: − ${formatMoney(disc.amount)}</div>

          <div class="stk" style="gap:10px;margin-top:16px">
            ${state.activeDraftId ? `
              <button type="button" class="btn w form-save-button" data-action="save-order">Save Order</button>
              <button type="button" class="btn gh w" style="height:40px;font-size:13px;border-color:rgba(255,255,255,.4);color:#fff" data-action="update-draft">${icon('draft')}Update Draft</button>
              <div class="r" style="gap:8px">
                <button type="button" class="btn tr delete-icon w" style="height:40px;font-size:13px;border-color:rgba(255,100,100,.5);color:#ffb4b4" data-action="prompt-delete-draft" data-id="${esc(state.activeDraftId)}">${icon('trash')}Delete Draft</button>
                <button type="button" class="btn gh w" style="height:40px;font-size:13px;border-color:rgba(255,255,255,.4);color:#fff" data-action="cancel-form">Cancel</button>
              </div>
            ` : state.editingId ? `
              <button type="button" class="btn w form-save-button" data-action="save-order">Update order</button>
              <div class="r" style="gap:8px">
                <button type="button" class="btn gh w" style="height:40px;font-size:13px;border-color:rgba(255,255,255,.4);color:#fff" data-action="form-print-invoice">${icon('invoice')}Print Invoice</button>
                <button type="button" class="btn gh w" style="height:40px;font-size:13px;border-color:rgba(255,255,255,.4);color:#fff" data-action="form-print-slip">${icon('slip')}Cutting Slip</button>
              </div>
            ` : `
              <button type="button" class="btn w form-save-button" data-action="save-order">Save order</button>
              <button type="button" class="btn gh w" style="height:40px;font-size:13px;border-color:rgba(255,255,255,.4);color:#fff" data-action="save-as-draft">${icon('draft')}Save as Draft</button>
              <div class="r" style="gap:8px">
                <button type="button" class="btn gh w" style="height:40px;font-size:13px;border-color:rgba(255,255,255,.4);color:#fff" data-action="form-print-invoice">${icon('invoice')}Print Invoice</button>
                <button type="button" class="btn gh w" style="height:40px;font-size:13px;border-color:rgba(255,255,255,.4);color:#fff" data-action="form-print-slip">${icon('slip')}Cutting Slip</button>
              </div>
            `}
          </div>
          <div class="xs money-helper form-save-note">${state.activeDraftId ? 'Save Order assigns the next Officer order number.' : 'Needs a customer name, BD number and one item.'}</div>
        </aside>
      </form>
    </main>
    ${renderMobileForm()}
  `;
}

function renderMobileForm() {
  const f = state.form || newForm();
  const total = currentTotal(), disc = currentDiscount(), due = currentDue();
  const customer = knownCustomer(f.bdNumber);
  const customerText = [String(f.customerName || '').trim(), String(f.bdNumber || '').trim()].filter(Boolean).join(' · ') || 'Officer order';
  const pct = total > 0 ? Math.max(0, Math.min(100, Math.round(((total - due) / total) * 100))) : 0;
  const tabs = [['items', 'Items'], ['customer', 'Customer'], ['measure', 'Measure'], ['money', 'Money']];
  const existingOrder = state.editingId ? orderById(state.editingId) : null;
  const laterPayments = existingOrder ? getLaterPaymentsTotal(existingOrder) : 0;
  const savedCustomer = f.bdNumber ? knownCustomer(f.bdNumber) : null;
  const isDifferentName = savedCustomer && String(f.customerName || '').trim() && normBD(f.customerName) !== normBD(savedCustomer.name);
  const customerSavedNameAlert = isDifferentName ? `
    <div class="customer-saved-name-banner" role="alert" style="margin-top:12px">
      <span class="dot" style="background:var(--em);margin-top:4px"></span>
      <div>
        <b>${esc(savedCustomer.bdNumber)} is saved as ${esc(savedCustomer.name)}.</b>
        <div>The saved name will be used. To change a name, edit the customer.</div>
      </div>
    </div>
  ` : '';
  const customerMatchNote = (savedCustomer && !isDifferentName) ? `
    <div class="customer-match-note" style="margin-top:12px"><i class="dot" style="background:var(--pos)"></i><span>Filled from the saved customer</span></div>
  ` : '';

  const itemRows = f.items.length ? f.items.map(item => `
    <div class="mr mobile-order-item">
      <span class="mobile-order-item-copy">
        <b>${esc(item.name)}</b>
        <span class="xs sub">${formatMoney(item.price)} each</span>
      </span>
      <span class="stp">
        <button type="button" data-action="change-item-quantity" data-delta="-1" data-id="${esc(item.id)}" aria-label="Decrease quantity">−</button>
        <b>${esc(item.quantity)}</b>
        <button type="button" data-action="change-item-quantity" data-delta="1" data-id="${esc(item.id)}" aria-label="Increase quantity">${icon('plus')}</button>
      </span>
      <b class="mobile-line-total">${formatMoney(Number(item.quantity) * Number(item.price))}</b>
      <button type="button" class="ic item-remove" data-action="remove-order-item" data-id="${esc(item.id)}" aria-label="Remove item">${icon('close')}</button>
    </div>
  `).join('') : `
    <div class="mobile-no-items">
      <div class="tray empty-art-tray"><img src="assets/empty-order-illustration.svg" alt="" aria-hidden="true"></div>
      <b>No items added yet</b>
      <div class="xs sub">Search the catalogue below, choose an item, then tap Add item.</div>
    </div>
  `;

  const picker = `
    <div class="r mobile-picker-row">
      <label class="f item-label">Search items
        <div class="picker-wrap">
          <div class="in item-search-box">${icon('search')}<input id="mobile-item-search" data-focus="item-search" value="${esc(state.itemSearch)}" placeholder="Search by name" autocomplete="off" aria-label="Search items" role="combobox" aria-expanded="${state.itemPickerOpen}"/></div>
          ${renderItemSuggestions()}
        </div>
      </label>
      <label class="f quantity-label">Qty<input id="mobile-item-quantity" type="number" min="1" step="1" data-focus="item-quantity" value="${esc(state.quantity)}" aria-label="Quantity"/></label>
      <button type="button" class="btn tr mobile-add-item" data-action="add-order-item">${icon('plus')}Add item</button>
    </div>
  `;

  const itemTab = `<section class="lc mobile-form-card"><div class="r mobile-section-heading"><h2>Items</h2><span class="sp sub sm">${f.items.length} added</span></div>${itemRows}${picker}</section>`;
  const customerTab = `
    <section class="lc mobile-form-card">
      <h2>Customer and dates</h2>
      <div class="stk mobile-fields-stack" style="margin-top:16px">
        ${renderCustomerFormField('BD Number', 'bdNumber', f.bdNumber, { placeholder: 'BD/12408', id: 'mobile-bd-number' })}
        ${renderCustomerFormField('Customer Name', 'customerName', f.customerName, { placeholder: 'Rank and full name', id: 'mobile-customer-name' })}
        ${fieldTemplate('Phone', 'phone', f.phone, { placeholder: 'Not added', inputmode: 'tel', id: 'mobile-phone' })}
        <div class="g2 mobile-date-fields">
          ${fieldTemplate('Order Date', 'orderDate', f.orderDate, { type: 'date', id: 'mobile-order-date' })}
          ${fieldTemplate('Delivery Date', 'deliveryDate', f.deliveryDate, { type: 'date', id: 'mobile-delivery-date' })}
        </div>
        <label class="f">Ribbon
          <select class="form-select" id="mobile-ribbon" data-form="ribbon" data-focus="form-ribbon">
            <option value="">Choose ribbon</option>
            ${(state.settings.ribbonValues || []).map(v => `<option value="${esc(v)}" ${String(f.ribbon) === String(v) ? 'selected' : ''}>${esc(v)}</option>`).join('')}
          </select>
        </label>
        ${customerSavedNameAlert}
        ${customerMatchNote}
      </div>
    </section>
  `;

  const measureTab = `
    <div class="stk mobile-measure-stack">
      <section class="lc mobile-measure-card">
        <h2>Shirt</h2>
        <div class="g3 measurement-input-grid" style="margin-top:12px;gap:8px">
          ${MEASUREMENT_FIELDS.shirt.filter(k => !k.includes('Notes')).map(k => fieldTemplate(k, `shirt.${k}`, f.shirt?.[k] || '', { type: 'text', dense: true, id: `mobile-shirt-${k.replace(/ /g, '-')}` })).join('')}
        </div>
        <div class="stk measurement-notes" style="margin-top:12px">
          ${MEASUREMENT_FIELDS.shirt.filter(k => k.includes('Notes')).map(k => fieldTemplate(k, `shirt.${k}`, f.shirt?.[k] || '', { dense: true, id: `mobile-shirt-${k.replace(/ /g, '-')}` })).join('')}
        </div>
      </section>
      <section class="lc mobile-measure-card">
        <h2>Pant</h2>
        <div class="g3 measurement-input-grid" style="margin-top:12px;gap:8px">
          ${MEASUREMENT_FIELDS.pant.filter(k => !k.includes('Notes')).map(k => fieldTemplate(k, `pant.${k}`, f.pant?.[k] || '', { type: 'text', dense: true, id: `mobile-pant-${k.replace(/ /g, '-')}` })).join('')}
        </div>
        <div class="stk measurement-notes" style="margin-top:12px">
          ${MEASUREMENT_FIELDS.pant.filter(k => k.includes('Notes')).map(k => fieldTemplate(k, `pant.${k}`, f.pant?.[k] || '', { dense: true, id: `mobile-pant-${k.replace(/ /g, '-')}` })).join('')}
        </div>
      </section>
    </div>
  `;

  const moneyTab = `
    <section class="lc mobile-form-card mobile-money-card">
      <h2>Money</h2>
      <div class="mobile-money-stat">
        <div class="xs sub">Total Amount</div>
        <div class="hn"><span class="cu">৳</span>${formatAmount(total)}</div>
        ${state.editingId ? (state.totalEditOpen ? `
          <label class="f mobile-total-override">Revised total
            <input id="mobile-total-override" data-form="totalOverride" data-focus="form-totalOverride" type="number" min="0" step="0.01" value="${esc(f.totalOverride === null || f.totalOverride === undefined ? total : f.totalOverride)}" inputmode="decimal"/>
          </label>
        ` : `<div class="xs sub">Tap the total at the top to type over it.</div>`) : `<div class="xs sub">Automatic · price × quantity</div>`}
      </div>
      <div class="stk mobile-fields-stack" style="margin-top:18px">
        <label class="f">Discount
          <input id="mobile-discount" data-form="discountInput" data-focus="form-discountInput" type="text" value="${esc(f.discountInput)}" placeholder="10% or a taka amount" inputmode="decimal"/>
          <small>${f.discountType === 'percentage' ? 'Default: percentage' : 'Default: taka'} · use % for percentage</small>
        </label>
        <label class="f">Advance
          <input id="mobile-advance" data-form="advance" data-focus="form-advance" type="number" min="0" step="0.01" value="${esc(f.advance)}" inputmode="decimal"/>
          ${laterPayments > 0 ? `<div class="mobile-received-later">Received later: ${formatMoney(laterPayments)}</div>` : ''}
        </label>
      </div>
      <div class="mobile-money-due">
        <div class="r"><span class="sub">Due</span><b class="sp ${due > 0 ? 'neg' : 'pos'}">${formatMoney(due)}</b></div>
        <div class="pr" style="margin-top:12px"><i style="width:${pct}%"></i></div>
        <div class="xs sub" style="margin-top:8px">${pct}% of total received</div>
        <div class="r" style="margin-top:18px"><span class="sub">Discount</span><b class="sp">− ${formatMoney(disc.amount)}</b></div>
      </div>
    </section>
  `;

  let activeContent = state.mobileFormTab === 'customer' ? customerTab : state.mobileFormTab === 'measure' ? measureTab : state.mobileFormTab === 'money' ? moneyTab : itemTab;
  const formError = state.formError ? `<div class="bn form-error mobile-form-error" role="alert"><i class="dot" style="background:var(--neg)"></i><b>${esc(state.formError)}</b></div>` : '';

  return `
    <main class="mob mobile-form-screen">
      <div class="mc">
        <div class="mobile-form-identity">
          <span class="cc"><span class="sq">${icon('shirt')}</span><span>${esc(customerText)}</span></span>
        </div>
        <div class="mobile-form-summary">
          ${state.editingId ? `<button type="button" class="hn mobile-total-trigger" data-action="enable-total-edit" aria-label="Edit total amount"><span class="cu">৳</span>${formatAmount(total)}</button>` : `<div class="hn"><span class="cu">৳</span>${formatAmount(total)}</div>`}
          <div class="sub" style="margin:10px 0">Total${state.editingId ? ' · tap to type over it' : ' · automatic'}</div>
          <span class="pl ${due > 0 ? 'n' : ''}">Due ${formatMoney(due)}</span>
          ${state.activeDraftId ? `<span class="badge draft-badge">Draft</span>` : ''}
          <span class="pl e">${state.editingId && state.dirty ? 'Unsaved changes' : state.editingId ? 'Edit order' : state.activeDraftId ? 'Draft order' : 'New order'}</span>
          ${!state.editingId ? `<span id="mobile-autosave-indicator" class="un autosave-indicator" style="margin-left:6px;${state.localAutosaved ? '' : 'display:none'}">${icon('check')}Draft saved locally</span>` : ''}
        </div>
        <div class="tabs mobile-form-tabs" role="tablist" aria-label="Order form sections">
          ${tabs.map(([key, label]) => `<button type="button" class="${state.mobileFormTab === key ? 'on' : ''}" data-action="mobile-form-tab" data-tab="${key}" role="tab" aria-selected="${state.mobileFormTab === key}">${label}</button>`).join('')}
        </div>
        ${formError}
        <div class="mobile-form-tab-content">${activeContent}</div>
      </div>
      ${state.activeDraftId ? `
        <div class="bar gl mobile-save-bar mobile-save-bar-v3">
          <button type="button" class="btn" data-action="save-order">Save Order</button>
          <button type="button" class="btn gh" data-action="update-draft">Update Draft</button>
          <button type="button" class="btn tr delete-icon" data-action="prompt-delete-draft" data-id="${esc(state.activeDraftId)}">Delete</button>
        </div>
      ` : state.editingId ? `
        <div class="bar gl mobile-save-bar mobile-save-bar-v3">
          <button type="button" class="btn" data-action="save-order">Update order</button>
          <button type="button" class="btn gh" data-action="form-print-invoice">${icon('invoice')}Invoice</button>
          <button type="button" class="btn tr" data-action="form-print-slip">${icon('slip')}Slip</button>
        </div>
      ` : `
        <div class="bar gl mobile-save-bar" style="display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:10px 12px">
          <button type="button" class="btn" data-action="save-order">Save order</button>
          <button type="button" class="btn gh" data-action="save-as-draft">${icon('draft')}Save as Draft</button>
          <button type="button" class="btn tr" data-action="form-print-invoice">${icon('invoice')}Invoice</button>
          <button type="button" class="btn tr" data-action="form-print-slip">${icon('slip')}Slip</button>
        </div>
      `}
    </main>
  `;
}

function renderMeasurementDetails(kind, title) {
  const data = state.orderForDetails?.measurements?.[kind] || {};
  const labels = MEASUREMENT_FIELDS[kind];
  const basic = labels.filter(x => !x.includes('Notes') && String(data[x] ?? '').trim());
  const notes = labels.filter(x => x.includes('Notes') && String(data[x] ?? '').trim());
  if (!basic.length && !notes.length) return '';
  return `
    <div class="tray detail-measurement-tray">
      <b>${title}</b>
      ${basic.length ? `
        <div class="g3 detail-measurement-grid" style="margin-top:14px;gap:16px">
          ${basic.map(k => `<div><div class="xs sub">${esc(k)}</div><b class="detail-measure-value">${esc(data[k])}</b></div>`).join('')}
        </div>
      ` : ''}
      ${notes.map(k => `<div class="detail-note-read"><div class="xs sub">${esc(k)}</div><b>${esc(data[k])}</b></div>`).join('')}
    </div>
  `;
}

function renderDetails() {
  const o = activeOrder();
  if (!o) {
    state.screen = 'orders';
    return renderOrders();
  }
  state.orderForDetails = o;
  const total = Number(o.total) || 0;
  const advance = Number(o.advance) || 0;
  const disc = Number(o.discountAmount) || 0;
  const due = getOrderDue(o);
  const totalReceived = getTotalReceived(o);
  const pct = total > 0 ? Math.max(0, Math.min(100, (totalReceived / total) * 100)) : 0;
  const isDelivered = (o.status || 'Pending') === 'Delivered';
  const showPay = isDelivered && due > 0;
  const paymentsList = getOrderPayments(o);

  const itemRows = (o.items || []).map(item => `
    <div class="rw detail-item-row" style="grid-template-columns:minmax(0,1fr) 70px 100px 110px">
      <b>${esc(item.name)}</b>
      <span class="rt">${esc(item.quantity)}</span>
      <span class="rt">${formatMoney(item.price)}</span>
      <b class="rt">${formatMoney((Number(item.quantity) || 0) * (Number(item.price) || 0))}</b>
    </div>
  `).join('');

  const shirt = renderMeasurementDetails('shirt', 'Shirt');
  const pant = renderMeasurementDetails('pant', 'Pant');

  return `
    <main class="page detail-page detail-desktop">
      ${renderNotice()}
      <a href="#" class="r detail-back-link" data-action="back-to-orders">${icon('back')}Orders</a>
      <div class="cols detail-columns" style="margin-top:16px">
        <div class="stk detail-main-column">
          <section class="pnl r detail-hero-panel" style="gap:28px">
            <div class="tray detail-art-tray"><img src="assets/order-details-illustration.svg" alt="" aria-hidden="true"/></div>
            <div class="detail-hero-copy" style="flex:1;min-width:0">
              <div class="sub">Order #${esc(o.orderNumber)}</div>
              <h1 class="detail-customer-heading">${esc(o.customerName || 'Unnamed customer')}</h1>
              <div class="r detail-identity" style="margin-top:8px">
                <span class="bd">Officer</span>
                ${renderStatusSelect(o)}
                <span class="sub sm">${esc(o.customerBDNumber || '—')}</span>
                ${o.deliveredDate ? `<span class="xs sub" style="color:var(--pos)">Delivered on ${esc(dateLabel(o.deliveredDate))}</span>` : ''}
              </div>
              <div class="r detail-hero-actions" style="margin-top:16px;flex-wrap:wrap">
                ${showPay ? `<button type="button" class="btn" data-action="prompt-pay" data-id="${esc(o.id)}">${icon('money')}Pay ${formatMoney(due)}</button>` : ''}
                <button type="button" class="btn gh" data-action="details-print-slip" data-id="${esc(o.id)}">${icon('slip')}Print Slip</button>
                <button type="button" class="btn gh" data-action="details-print-invoice" data-id="${esc(o.id)}">${icon('invoice')}Invoice</button>
                <button type="button" class="btn" data-action="edit-order" data-id="${esc(o.id)}">${icon('edit')}Edit order</button>
                <button type="button" class="ic delete-icon" data-action="delete-first" data-id="${esc(o.id)}" aria-label="Delete order">${icon('trash')}</button>
              </div>
            </div>
          </section>

          <section class="pnl detail-customer-order-panel">
            <div class="g2 detail-customer-order-grid">
              <div class="tray detail-info-tray">
                <b>Customer</b>
                <div class="g2" style="margin-top:14px;gap:16px">
                  <div><div class="xs sub">Name</div><b>${esc(o.customerName || '—')}</b></div>
                  <div><div class="xs sub">Phone</div><b>${esc(o.phone || '—')}</b></div>
                  <div><div class="xs sub">BD Number</div><b>${esc(o.customerBDNumber || '—')}</b></div>
                </div>
              </div>
              <div class="tray detail-info-tray">
                <b>Order</b>
                <div class="g2" style="margin-top:14px;gap:16px">
                  <div><div class="xs sub">Order Date</div><b>${esc(dateLabel(o.orderDate))}</b></div>
                  <div><div class="xs sub">Delivery Date</div><b>${esc(dateLabel(o.deliveryDate))}</b></div>
                  <div><div class="xs sub">Ribbon</div><b>${o.ribbon === undefined || o.ribbon === '' ? '—' : esc(o.ribbon)}</b></div>
                </div>
              </div>
            </div>
          </section>

          <section class="pnl detail-items-panel">
            <h2 style="margin-bottom:14px">Items</h2>
            <div class="rw h detail-item-head" style="grid-template-columns:minmax(0,1fr) 70px 100px 110px">
              <span>Item</span><span class="rt">Qty</span><span class="rt">Price</span><span class="rt">Line total</span>
            </div>
            ${itemRows || '<div class="sub sm" style="padding:14px 12px">No items on this order.</div>'}
          </section>

          <section class="pnl detail-payments-panel">
            <div class="r" style="justify-content:space-between">
              <h2>Payments</h2>
              <span class="sub sm">${paymentsList.length + (advance > 0 ? 1 : 0)} recorded</span>
            </div>
            <div class="detail-payments-list">
              <div class="detail-payment-row">
                <div>
                  <b>Advance Payment</b>
                  <div class="xs sub">Received on order creation · ${esc(dateLabel(o.orderDate))}</div>
                </div>
                <b>${formatMoney(advance)}</b>
              </div>
              ${paymentsList.map((p, idx) => `
                <div class="detail-payment-row">
                  <div>
                    <b>Cash Payment #${idx + 1}</b>
                    <div class="xs sub">Received upon delivery · ${esc(dateLabel(p.date))}</div>
                  </div>
                  <b class="pos">${formatMoney(p.amount)}</b>
                </div>
              `).join('')}
              <div class="detail-payment-total">
                <span>Total Received</span>
                <b class="pos">${formatMoney(totalReceived)}</b>
              </div>
              <div class="detail-payment-row" style="background:#fff;border:1px solid var(--hl);margin-top:4px">
                <span>Remaining Due</span>
                <b class="${due > 0 ? 'neg' : 'pos'}">${due === 0 ? '৳0 (Fully paid)' : formatMoney(due)}</b>
              </div>
            </div>
          </section>

          <section class="pnl detail-measurements-panel">
            <h2>Measurements and notes</h2>
            <div class="g2 detail-measurement-groups" style="margin-top:16px;align-items:start">
              ${shirt || `<div class="tray"><b>Shirt</b><div class="xs sub" style="margin-top:10px">No shirt measurements entered.</div></div>`}
              ${pant || `<div class="tray"><b>Pant</b><div class="xs sub" style="margin-top:10px">No pant measurements entered.</div></div>`}
            </div>
          </section>
        </div>

        <aside class="pnl detail-payment-panel">
          <div class="r">
            <span class="sub">Due</span>
            <span class="sp un"><i class="dot ${isDelivered ? 'status-dot-delivered' : 'status-dot-pending'}"></i>${esc(o.status || 'Pending')}</span>
          </div>
          <div class="nl ${due > 0 ? 'neg' : 'pos'} detail-due-number">${due === 0 ? '৳0' : formatMoney(due)}</div>
          <div class="pr"><i style="width:${pct}%"></i></div>
          <div class="xs sub" style="margin:8px 0 20px">${Math.round(pct)}% of total received</div>

          <div class="tray detail-payment-tray" style="padding:20px">
            <div class="r"><span class="sub">Total</span><b class="sp">${formatMoney(total)}</b></div>
            <div class="r" style="margin:12px 0"><span class="sub">Discount</span><b class="sp">${formatMoney(disc)}</b></div>
            <div class="r"><span class="sub">Advance</span><b class="sp">${formatMoney(advance)}</b></div>
            ${getLaterPaymentsTotal(o) > 0 ? `<div class="r" style="margin-bottom:12px"><span class="sub">Later payments</span><b class="sp pos">${formatMoney(getLaterPaymentsTotal(o))}</b></div>` : ''}
            <div class="r" style="margin-top:12px;padding-top:12px;border-top:1px solid var(--hl)">
              <b>Due</b><b class="sp ${due > 0 ? 'neg' : 'pos'}">${due === 0 ? '৳0' : formatMoney(due)}</b>
            </div>
          </div>

          ${showPay ? `<button type="button" class="btn w" style="margin:16px 0 8px" data-action="prompt-pay" data-id="${esc(o.id)}">${icon('money')}Pay ${formatMoney(due)}</button>` : ''}
          <div class="r" style="gap:8px;margin-top:10px">
            <button type="button" class="btn tr w" data-action="details-print-slip" data-id="${esc(o.id)}">${icon('slip')}Print Slip</button>
            <button type="button" class="btn tr w" data-action="details-print-invoice" data-id="${esc(o.id)}">${icon('invoice')}Invoice</button>
          </div>
          <button class="btn gh w detail-edit-button" style="margin-top:10px" data-action="edit-order" data-id="${esc(o.id)}">${icon('edit')}Edit Order</button>
          <button class="btn tr w detail-delete-button" style="margin-top:8px" data-action="delete-first" data-id="${esc(o.id)}">${icon('trash')}Delete order</button>
        </aside>
      </div>
    </main>
    ${renderMobileDetails()}
  `;
}

function renderMobileDetails() {
  const o = activeOrder();
  if (!o) return '';
  const total = Number(o.total) || 0;
  const advance = Number(o.advance) || 0;
  const disc = Number(o.discountAmount) || 0;
  const due = getOrderDue(o);
  const totalReceived = getTotalReceived(o);
  const pct = total > 0 ? Math.max(0, Math.min(100, Math.round((totalReceived / total) * 100))) : 0;
  const itemRows = (o.items || []).map(item => `
    <div class="mr mobile-detail-item">
      <span style="flex:1;min-width:0">
        <b>${esc(item.name)}</b>
        <div class="xs sub">${esc(item.quantity)} × ${formatMoney(item.price)}</div>
      </span>
      <b>${formatMoney(Number(item.quantity) * Number(item.price))}</b>
    </div>
  `).join('');

  const shirt = renderMeasurementDetails('shirt', 'Shirt');
  const pant = renderMeasurementDetails('pant', 'Pant');
  const isDelivered = (o.status || 'Pending') === 'Delivered';
  const showPay = isDelivered && due > 0;
  const paymentsList = getOrderPayments(o);

  return `
    <main class="mob mobile-details-screen">
      <div class="mc">
        <div class="mobile-detail-summary">
          <div class="sub sm">Due</div>
          <div class="hn ${due > 0 ? 'neg' : 'pos'}" style="margin:4px 0 10px"><span class="cu">৳</span>${formatAmount(due)}</div>
          <span class="pl">${pct}% paid</span>
          <span class="pl e">Delivery ${esc(dateLabel(o.deliveryDate))}</span>
        </div>

        <div class="obj mobile-detail-object">
          <img src="assets/order-details-illustration.svg" alt="" aria-hidden="true">
          <div class="t">
            <span class="mk">${icon('shirt')}</span>
            <span class="gp">${renderStatusSelect(o)}</span>
          </div>
          <div class="b">
            <span>
              <div class="xs" style="opacity:.7">Officer · ${esc(o.customerBDNumber || '—')}</div>
              <div class="mobile-object-name">${esc(o.customerName || 'Unnamed customer')}</div>
            </span>
            <span class="rg" style="--p:${pct}"><i></i><b>${pct}%</b></span>
          </div>
        </div>
      </div>

      <section class="gs mobile-details-sheet">
        <div class="grab" aria-hidden="true"></div>
        <div class="r mobile-sheet-title">
          <h2>Items</h2>
          <span class="sp sub sm">Total ${formatMoney(total)}</span>
        </div>
        <div class="lc mobile-detail-items">
          ${itemRows || '<div class="mr"><span class="sub sm">No items on this order.</span></div>'}
        </div>

        <div class="mobile-details-meta">
          <h2>Customer</h2>
          <div class="g2 mobile-details-meta-grid">
            <div><div class="xs sub">Name</div><b>${esc(o.customerName || '—')}</b></div>
            <div><div class="xs sub">Phone</div><b>${esc(o.phone || '—')}</b></div>
            <div><div class="xs sub">BD Number</div><b>${esc(o.customerBDNumber || '—')}</b></div>
          </div>

          <h2 style="margin-top:20px">Order &amp; Delivery</h2>
          <div class="g2 mobile-details-meta-grid">
            <div><div class="xs sub">Order Date</div><b>${esc(dateLabel(o.orderDate))}</b></div>
            <div><div class="xs sub">Delivery Date</div><b>${esc(dateLabel(o.deliveryDate))}</b></div>
            <div><div class="xs sub">Status</div><b>${esc(o.status || 'Pending')}</b></div>
            <div><div class="xs sub">Delivered Date</div><b>${esc(dateLabel(o.deliveredDate))}</b></div>
          </div>

          <h2 style="margin-top:20px">Payment Breakdown</h2>
          <div class="mobile-payment-rows">
            <div class="r"><span class="sub">Total</span><b class="sp">${formatMoney(total)}</b></div>
            <div class="r"><span class="sub">Discount</span><b class="sp">− ${formatMoney(disc)}</b></div>
            <div class="r"><span class="sub">Advance</span><b class="sp">${formatMoney(advance)}</b></div>
            ${paymentsList.map(p => `
              <div class="r"><span class="sub">Paid (${esc(dateLabel(p.date))})</span><b class="sp pos">${formatMoney(p.amount)}</b></div>
            `).join('')}
            <div class="r" style="border-top:1px solid var(--dv);margin-top:6px;padding-top:10px">
              <b>Due</b><b class="sp ${due > 0 ? 'neg' : 'pos'}">${due === 0 ? '৳0 (Fully paid)' : formatMoney(due)}</b>
            </div>
          </div>

          <h2 style="margin-top:20px">Measurements and notes</h2>
          <div class="stk mobile-detail-measurements">
            ${shirt || '<div class="lc mobile-empty-measure">Shirt · No measurements entered.</div>'}
            ${pant || '<div class="lc mobile-empty-measure">Pant · No measurements entered.</div>'}
          </div>
        </div>
      </section>

      <div class="bar gl mobile-detail-actions" style="gap:6px">
        <button type="button" class="btn tr" data-action="details-print-slip" data-id="${esc(o.id)}" style="flex:1;height:48px;font-size:13px">${icon('slip')}Slip</button>
        <button type="button" class="btn tr" data-action="details-print-invoice" data-id="${esc(o.id)}" style="flex:1;height:48px;font-size:13px">${icon('invoice')}Invoice</button>
        ${showPay ? `<button type="button" class="btn" data-action="prompt-pay" data-id="${esc(o.id)}" style="flex:1;height:48px;font-size:13px">${icon('money')}Pay</button>` : ''}
        <button type="button" class="btn gh" data-action="edit-order" data-id="${esc(o.id)}" style="flex:1;height:48px;font-size:13px">${icon('edit')}Edit</button>
      </div>
    </main>
  `;
}

function renderConfirmationModal() {
  const m = state.modal;
  if (!m) return '';

  if (m.type === 'pay-confirm') {
    const o = orderById(m.orderId);
    if (!o) return '';
    const due = getOrderDue(o);
    return `
      <div class="dialog-overlay" data-action="close-modal-bg">
        <section class="dl confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="pay-dialog-title">
          <span class="ic dialog-icon" style="background:rgba(0,102,204,0.1);color:var(--b)">${icon('money')}</span>
          <h2 id="pay-dialog-title">Receive ${formatMoney(due)} from ${esc(o.customerName)} for order #${esc(o.orderNumber)}?</h2>
          <div class="sub dialog-sub">This marks the remaining due as received in cash. Due will become ৳0.</div>
          <div class="r dialog-actions" style="margin-top:24px">
            <button type="button" class="btn tr" data-action="cancel-modal">Cancel</button>
            <button type="button" class="btn" data-action="confirm-pay" data-id="${esc(o.id)}">Received</button>
          </div>
        </section>
      </div>
    `;
  }

  if (m.type === 'delete-first' || m.type === 'delete-second') {
    const o = orderById(m.id);
    if (!o) return '';
    const second = m.type === 'delete-second';
    return `
      <div class="dialog-overlay" data-action="close-modal-bg">
        <section class="dl confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="confirm-title">
          <span class="ic dialog-icon danger-dialog-icon">${icon('trash')}</span>
          <h2 id="confirm-title">${second ? 'This cannot be undone. Delete permanently?' : `Delete order #${esc(o.orderNumber)} for ${esc(o.customerName)}?`}</h2>
          <div class="sub dialog-sub">${second ? 'The order will be removed permanently. Later Officer order numbers will move down by one and payment records will be removed.' : 'The customer and their other orders stay.'}</div>
          <div class="r dialog-actions">
            <button class="btn tr" data-action="cancel-delete">Cancel</button>
            ${second ? '<button class="btn ng" data-action="confirm-delete">Delete</button>' : '<button class="btn" data-action="continue-delete">Continue</button>'}
          </div>
        </section>
      </div>
    `;
  }

  if (m.type === 'leave-form') {
    return `
      <div class="dialog-overlay" data-action="close-modal-bg">
        <section class="dl confirm-dialog" role="dialog" aria-modal="true">
          <span class="un" style="margin-bottom:8px"><i class="dot" style="background:var(--em)"></i>Unsaved changes</span>
          <h2>Leave without saving?</h2>
          <div class="sub dialog-sub">Your changes to this order will be lost.</div>
          <div class="r dialog-actions">
            <button class="btn tr" data-action="stay-form">Keep editing</button>
            <button class="btn" data-action="leave-form">Leave</button>
          </div>
        </section>
      </div>
    `;
  }

  if (m.type === 'remove-item') {
    const item = state.settings.items.find(i => i.id === m.id);
    if (!item) return '';
    return `
      <div class="dialog-overlay" data-action="close-modal-bg">
        <section class="dl confirm-dialog" role="dialog" aria-modal="true">
          <span class="ic dialog-icon danger-dialog-icon">${icon('trash')}</span>
          <h2>Remove catalogue item?</h2>
          <div class="sub dialog-sub">Remove “${esc(item.name)}” from Items &amp; Prices? Existing orders keep their copied price.</div>
          <div class="r dialog-actions">
            <button class="btn tr" data-action="cancel-delete">Cancel</button>
            <button class="btn ng" data-action="confirm-remove-item">Remove item</button>
          </div>
        </section>
      </div>
    `;
  }

  if (m.type === 'cancel-three-choice') {
    const isDraft = m.isDraft;
    const canSave = canSaveAsDraft(state.form);
    return `
      <div class="dialog-overlay" data-action="close-modal-bg">
        <section class="dl confirm-dialog three-choice-dialog" role="dialog" aria-modal="true" aria-labelledby="three-choice-title">
          <span class="un" style="margin-bottom:8px"><i class="dot" style="background:var(--em)"></i>Unfinished order</span>
          <h2 id="three-choice-title">Unfinished order</h2>
          <div class="sub dialog-sub">Choose what to do with your unfinished work.</div>
          <div class="three-choice-actions">
            ${canSave ? `
              <button type="button" class="btn" data-action="cancel-save-draft">
                ${isDraft ? 'Update Draft' : 'Save as Draft'}
              </button>
            ` : `
              <div>
                <button type="button" class="btn btn-disabled" disabled aria-disabled="true">
                  ${isDraft ? 'Update Draft' : 'Save as Draft'}
                </button>
                <div class="btn-disabled-hint">A draft needs a BD number and at least one item.</div>
              </div>
            `}
            <button type="button" class="btn tr delete-icon" data-action="cancel-discard">Discard</button>
            <button type="button" class="btn gh" data-action="cancel-keep-editing">Keep editing</button>
          </div>
        </section>
      </div>
    `;
  }

  if (m.type === 'delete-draft') {
    return `
      <div class="dialog-overlay" data-action="close-modal-bg">
        <section class="dl confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="delete-draft-title">
          <span class="ic dialog-icon danger-dialog-icon">${icon('trash')}</span>
          <h2 id="delete-draft-title">Delete this draft?</h2>
          <div class="sub dialog-sub">This draft will be permanently removed.</div>
          <div class="r dialog-actions">
            <button type="button" class="btn tr" data-action="cancel-modal">Cancel</button>
            <button type="button" class="btn ng" data-action="confirm-delete-draft" data-id="${esc(m.id)}">Delete draft</button>
          </div>
        </section>
      </div>
    `;
  }

  if (m.type === 'autosave-prompt') {
    return `
      <div class="dialog-overlay" data-action="close-modal-bg">
        <section class="dl confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="autosave-title">
          <span class="ic dialog-icon" style="background:rgba(0,102,204,0.1);color:var(--b)">${icon('draft')}</span>
          <h2 id="autosave-title">Continue where you left off?</h2>
          <div class="sub dialog-sub">You have an unsaved draft on this device from earlier.</div>
          <div class="r dialog-actions">
            <button type="button" class="btn tr" data-action="autosave-start-fresh">Start fresh</button>
            <button type="button" class="btn" data-action="autosave-continue">Continue</button>
          </div>
        </section>
      </div>
    `;
  }

  if (m.type === 'add-customer') {
    return `
      <div class="dialog-overlay" data-action="close-modal-bg">
        <section class="dl editor-dialog" role="dialog" aria-modal="true" aria-labelledby="add-customer-title" style="width:400px">
          <h2 id="add-customer-title">Add Customer</h2>
          <div class="sub dialog-sub">Add a new Officer customer to your shop directory.</div>
          ${m.error ? `<div class="bn form-error" style="margin-bottom:14px" role="alert"><i class="dot" style="background:var(--neg)"></i><b>${esc(m.error)}</b></div>` : ''}
          <div class="dialog-fields stk" style="gap:12px;margin-top:0">
            <label class="f">BD Number
              <input data-modal-field="bdNumber" value="${esc(m.bdNumber)}" placeholder="BD/12408" autocomplete="off"/>
            </label>
            <label class="f">Name
              <input data-modal-field="name" value="${esc(m.name)}" placeholder="Rank and full name" autocomplete="off"/>
            </label>
            <label class="f">Phone
              <input data-modal-field="phone" value="${esc(m.phone)}" placeholder="01711-XXXXXX" inputmode="tel" autocomplete="off"/>
            </label>
          </div>
          <div class="r dialog-actions" style="margin-top:20px">
            <button type="button" class="btn tr" data-action="cancel-modal">Cancel</button>
            <button type="button" class="btn" data-action="save-add-customer">Save</button>
          </div>
        </section>
      </div>
    `;
  }

  if (m.type === 'edit-customer') {
    return `
      <div class="dialog-overlay" data-action="close-modal-bg">
        <section class="dl editor-dialog" role="dialog" aria-modal="true" aria-labelledby="edit-customer-title" style="width:400px">
          <h2 id="edit-customer-title">Edit Customer</h2>
          <div class="sub dialog-sub">The BD number cannot be changed. Updating name and phone updates existing orders.</div>
          ${m.error ? `<div class="bn form-error" style="margin-bottom:14px" role="alert"><i class="dot" style="background:var(--neg)"></i><b>${esc(m.error)}</b></div>` : ''}
          <div class="dialog-fields stk" style="gap:12px;margin-top:0">
            <div class="f">
              <span>BD Number</span>
              <div class="in" style="background:var(--pc);font-weight:600;cursor:not-allowed">${esc(m.bdNumber)}</div>
            </div>
            <label class="f">Name
              <input data-modal-field="name" value="${esc(m.name)}" placeholder="Rank and full name" autocomplete="off"/>
            </label>
            <label class="f">Phone
              <input data-modal-field="phone" value="${esc(m.phone)}" placeholder="01711-XXXXXX" inputmode="tel" autocomplete="off"/>
            </label>
          </div>
          <div class="r dialog-actions" style="margin-top:20px">
            <button type="button" class="btn tr" data-action="cancel-modal">Cancel</button>
            <button type="button" class="btn" data-action="save-edit-customer">Save</button>
          </div>
        </section>
      </div>
    `;
  }

  if (m.type === 'customer-has-orders-alert') {
    return `
      <div class="dialog-overlay" data-action="close-modal-bg">
        <section class="dl confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="cannot-delete-title">
          <span class="ic dialog-icon" style="background:rgba(240,86,31,.12);color:var(--em)">${icon('alert')}</span>
          <h2 id="cannot-delete-title">Cannot delete customer</h2>
          <div class="sub dialog-sub">This customer has ${m.ordersCount} ${m.ordersCount === 1 ? 'order' : 'orders'}. Delete those orders first.</div>
          <div class="r dialog-actions">
            <button type="button" class="btn" data-action="cancel-modal" style="width:100%">OK</button>
          </div>
        </section>
      </div>
    `;
  }

  if (m.type === 'confirm-delete-customer') {
    return `
      <div class="dialog-overlay" data-action="close-modal-bg">
        <section class="dl confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="delete-customer-title">
          <span class="ic dialog-icon danger-dialog-icon">${icon('trash')}</span>
          <h2 id="delete-customer-title">Delete this customer?</h2>
          <div class="sub dialog-sub">Delete “${esc(m.customerName)}” (${esc(m.bdNumber)}) permanently? This customer has no orders.</div>
          <div class="r dialog-actions">
            <button type="button" class="btn tr" data-action="cancel-modal">Cancel</button>
            <button type="button" class="btn ng" data-action="confirm-delete-customer-action" data-bd="${esc(m.bdNumber)}">Delete</button>
          </div>
        </section>
      </div>
    `;
  }

  return '';
}

function renderCustomersScreen() {
  const customers = filteredAndSortedCustomers();
  const q = (state.customerSearch || '').trim();

  const cardsHtml = customers.length ? customers.map(c => {
    const stats = getCustomerStats(c.bdNumber);
    const initial = (c.name || 'C').slice(0, 1).toUpperCase();
    return `
      <div class="customer-card">
        <div class="customer-card-head">
          <div class="customer-avatar">${esc(initial)}</div>
          <div class="customer-card-title-group">
            <div class="customer-card-name">${esc(c.name)}</div>
            <div class="customer-card-bd">${esc(c.bdNumber)}</div>
            ${c.phone ? `<div class="customer-card-phone">${icon('phone')}${esc(c.phone)}</div>` : ''}
          </div>
        </div>

        <div class="customer-stats-bar">
          <div class="customer-stat-item">
            <span class="customer-stat-lbl">Orders</span>
            <span class="customer-stat-val">${stats.ordersCount}</span>
          </div>
          <div class="customer-stat-item">
            <span class="customer-stat-lbl">Spent</span>
            <span class="customer-stat-val">${formatMoney(stats.spent)}</span>
          </div>
          <div class="customer-stat-item">
            <span class="customer-stat-lbl">Due</span>
            <span class="customer-stat-val ${stats.due > 0 ? 'neg' : ''}">${formatMoney(stats.due)}</span>
          </div>
        </div>

        <div class="customer-card-actions">
          <button type="button" class="ic" data-action="open-person-history" data-bd="${esc(c.bdNumber)}" title="History" aria-label="View history for ${esc(c.name)}">
            ${icon('history')}
          </button>
          <button type="button" class="ic" data-action="edit-customer" data-bd="${esc(c.bdNumber)}" title="Edit" aria-label="Edit customer ${esc(c.name)}">
            ${icon('edit')}
          </button>
          <button type="button" class="ic delete-icon" data-action="delete-customer" data-bd="${esc(c.bdNumber)}" title="Delete" aria-label="Delete customer ${esc(c.name)}">
            ${icon('trash')}
          </button>
        </div>
      </div>
    `;
  }).join('') : `
    <div class="empty-customers-card">
      <div class="empty-customers-icon">${icon('users')}</div>
      <div class="empty-customers-title">${q ? 'No matching customers' : 'No customers yet'}</div>
      <div class="empty-customers-sub">${q ? 'Try searching by a different name, phone or BD number.' : 'No customers yet. They are added automatically when you save an order.'}</div>
      ${q ? `<button type="button" class="btn gh" data-action="clear-customer-search">Clear search</button>` : `<button type="button" class="btn" data-action="add-customer">${icon('plus')}Add Customer</button>`}
    </div>
  `;

  return `
    <main class="page customers-page">
      ${renderNotice()}
      <div class="hd">
        <div>
          <h1>Customers</h1>
          <div class="sub page-sub" style="font-size:17px;margin-top:6px">Officer customer directory, lifetime spend and balances.</div>
        </div>
        <button type="button" class="btn" data-action="add-customer">${icon('plus')}Add Customer</button>
      </div>

      <div class="orders-filter-container" style="margin-top:14px">
        <div class="orders-tabs-group" role="tablist">
          <button type="button" class="order-filter-pill active" role="tab" aria-selected="true">
            Officer <span class="order-filter-count">(${state.customers.length})</span>
          </button>
        </div>
      </div>

      <div class="customers-toolbar">
        <label class="f search-field">
          <div class="in">
            ${icon('search')}
            <input class="orders-search-input" data-focus="customer-search" value="${esc(state.customerSearch)}" placeholder="Search by name, phone or BD number" autocomplete="off" aria-label="Search customers"/>
            ${state.customerSearch ? `<button type="button" class="ic" style="width:26px;height:26px;background:transparent" data-action="clear-customer-search" aria-label="Clear search">${icon('close')}</button>` : ''}
          </div>
        </label>
        <div class="sort-control">
          <span>Sort:</span>
          <select data-action="change-customer-sort" aria-label="Sort customers">
            <option value="newest" ${state.customerSort === 'newest' ? 'selected' : ''}>Newest first</option>
            <option value="name" ${state.customerSort === 'name' ? 'selected' : ''}>Name A–Z</option>
            <option value="due" ${state.customerSort === 'due' ? 'selected' : ''}>Most due first</option>
          </select>
          <span style="display:flex;align-items:center">${icon('chevron')}</span>
        </div>
      </div>

      <div class="customers-grid">
        ${cardsHtml}
      </div>
    </main>
  `;
}

function renderCustomerHistoryScreen() {
  const q = (state.customerHistorySearch || '').trim().toLowerCase();
  let list = [...(state.customers || [])];
  if (q) {
    list = list.filter(c =>
      (c.name || '').toLowerCase().includes(q) ||
      (c.phone || '').toLowerCase().includes(q) ||
      (c.bdNumber || '').toLowerCase().includes(q)
    );
  }
  list.sort((a, b) => (a.name || '').localeCompare(b.name || ''));

  const rowsHtml = list.length ? list.map(c => {
    const stats = getCustomerStats(c.bdNumber);
    const initial = (c.name || 'C').slice(0, 1).toUpperCase();
    return `
      <div class="customer-history-row" data-action="open-person-history" data-bd="${esc(c.bdNumber)}" role="button" tabindex="0" aria-label="View history for ${esc(c.name)}">
        <div class="customer-history-info">
          <div class="customer-avatar" style="width:40px;height:40px;font-size:15px">${esc(initial)}</div>
          <div class="customer-history-copy">
            <div class="customer-history-name">${esc(c.name)}</div>
            <div class="customer-history-sub">
              ${esc(c.bdNumber)}${c.phone ? ` · ${esc(c.phone)}` : ''}
            </div>
          </div>
        </div>

        <div class="customer-history-stats">
          <div class="customer-history-stat-badge">
            <span class="stat-lbl">Orders</span>
            <span class="stat-val">${stats.ordersCount}</span>
          </div>
          <div class="customer-history-stat-badge">
            <span class="stat-lbl">Spent</span>
            <span class="stat-val">${formatMoney(stats.spent)}</span>
          </div>
          <div class="customer-history-stat-badge">
            <span class="stat-lbl">Due</span>
            <span class="stat-val ${stats.due > 0 ? 'neg' : ''}">${formatMoney(stats.due)}</span>
          </div>
          <div class="customer-history-chevron">${icon('chevron')}</div>
        </div>
      </div>
    `;
  }).join('') : `
    <div class="empty-customers-card">
      <div class="empty-customers-icon">${icon('history')}</div>
      <div class="empty-customers-title">${q ? 'No matching customers' : 'No customers yet'}</div>
      <div class="empty-customers-sub">${q ? 'Try searching by another name, phone or BD number.' : 'Customer histories appear here once customers or orders are added.'}</div>
    </div>
  `;

  return `
    <main class="page customer-history-page">
      ${renderNotice()}
      <div class="hd">
        <div>
          <h1>Customer History</h1>
          <div class="sub page-sub" style="font-size:17px;margin-top:6px">Tap any customer to inspect full order history, payments and due balances.</div>
        </div>
      </div>

      <div class="customers-toolbar" style="margin-top:16px">
        <label class="f search-field">
          <div class="in">
            ${icon('search')}
            <input class="orders-search-input" data-focus="customer-history-search" value="${esc(state.customerHistorySearch)}" placeholder="Search by name, phone or BD number" autocomplete="off" aria-label="Search customer history"/>
            ${state.customerHistorySearch ? `<button type="button" class="ic" style="width:26px;height:26px;background:transparent" data-action="clear-customer-history-search" aria-label="Clear search">${icon('close')}</button>` : ''}
          </div>
        </label>
      </div>

      <div class="customer-history-list">
        ${rowsHtml}
      </div>
    </main>
  `;
}

function renderPersonHistoryScreen() {
  const bd = state.personHistoryBD;
  const c = knownCustomer(bd);
  if (!c) {
    state.screen = 'customer-history';
    return renderCustomerHistoryScreen();
  }

  const stats = getCustomerStats(bd);
  const initial = (c.name || 'C').slice(0, 1).toUpperCase();
  const returnLabel = state.personHistoryReturnScreen === 'customers' ? 'Customers' : 'Customer History';

  const sortedOrders = [...stats.matchingOrders].sort((a, b) => Number(b.orderNumber || 0) - Number(a.orderNumber || 0));

  const orderRowsDesktop = sortedOrders.length ? sortedOrders.map(o => {
    const due = getOrderDue(o);
    const s = o.status || 'Pending';
    const dotClass = s === 'Delivered' ? 'status-dot-delivered' : s === 'Cutting Slip – Done' ? 'status-dot-cutting' : 'status-dot-pending';
    return `
      <div class="rw order-row" data-action="open-details" data-id="${esc(o.id)}" role="button" tabindex="0" aria-label="Order #${esc(o.orderNumber)}" style="grid-template-columns:1.5fr 110px 100px 100px 100px 100px 60px">
        <div class="order-person-cell">
          <div class="no">${esc(o.orderNumber)}</div>
          <div class="order-person-copy">
            <strong>${esc(o.customerName || 'Unnamed customer')}</strong>
            <small>${esc(o.customerBDNumber || '—')}${o.phone ? ` · ${esc(o.phone)}` : ''}</small>
          </div>
        </div>
        <div class="order-status-cell">
          <span class="status-read"><i class="dot ${dotClass}"></i><b>${esc(s)}</b></span>
        </div>
        <div class="order-date-cell">${esc(dateLabel(o.orderDate))}</div>
        <div class="order-date-cell">${esc(dateLabel(o.deliveryDate))}</div>
        <div class="order-money-cell"><b>${formatMoney(o.total)}</b></div>
        <div class="order-money-cell ${due > 0 ? 'neg' : 'pos'}"><b>${formatMoney(due)}</b></div>
        <div class="order-row-actions" onclick="event.stopPropagation()">
          <button type="button" class="ic" data-action="open-details" data-id="${esc(o.id)}" title="View details" aria-label="View details for order #${esc(o.orderNumber)}">
            ${icon('chevron')}
          </button>
        </div>
      </div>
    `;
  }).join('') : `
    <div class="empty-order-state">
      <div class="empty-art-tray"><img src="assets/orders-empty.png" alt="" aria-hidden="true"/></div>
      <h2>No orders yet</h2>
      <p>This customer does not have any orders recorded.</p>
      <button type="button" class="btn" data-action="new-order-for-customer" data-bd="${esc(c.bdNumber)}">${icon('plus')}New Order for ${esc(c.name)}</button>
    </div>
  `;

  const orderRowsMobile = sortedOrders.length ? sortedOrders.map(o => {
    const due = getOrderDue(o);
    const s = o.status || 'Pending';
    return `
      <div class="mr order-mobile-row" data-action="open-details" data-id="${esc(o.id)}" role="button" tabindex="0">
        <div class="sq">${icon('shirt')}</div>
        <div class="order-mobile-copy">
          <b>#${esc(o.orderNumber)} · ${esc(o.customerName || 'Unnamed customer')}</b>
          <div class="xs sub">${esc(dateLabel(o.orderDate))} · ${esc(s)}</div>
          <div class="xs ${due > 0 ? 'neg' : 'pos'}">Due: ${formatMoney(due)} (Total: ${formatMoney(o.total)})</div>
        </div>
        <div class="customer-history-chevron">${icon('chevron')}</div>
      </div>
    `;
  }).join('') : `
    <div class="empty-order-state">
      <h2>No orders yet</h2>
      <p>This customer does not have any orders recorded.</p>
    </div>
  `;

  return `
    <main class="page person-history-page">
      ${renderNotice()}
      <button type="button" class="btn tr detail-back-link" data-action="back-from-person-history" style="margin-top:16px">
        ${icon('back')}Back to ${returnLabel}
      </button>

      <section class="person-hero-card">
        <div class="person-hero-top">
          <div class="person-profile-group">
            <div class="person-avatar-lg">${esc(initial)}</div>
            <div>
              <h1 class="person-hero-name">${esc(c.name)}</h1>
              <div class="person-hero-meta">
                <span class="bd">Officer</span>
                <b>${esc(c.bdNumber)}</b>
                ${c.phone ? `<span>${icon('phone')} ${esc(c.phone)}</span>` : ''}
              </div>
            </div>
          </div>
          <div class="r" style="gap:8px">
            <button type="button" class="btn gh" data-action="edit-customer" data-bd="${esc(c.bdNumber)}">${icon('edit')}Edit Customer</button>
            <button type="button" class="btn" data-action="new-order-for-customer" data-bd="${esc(c.bdNumber)}">${icon('plus')}New Order</button>
          </div>
        </div>

        <div class="person-hero-stats">
          <div class="person-hero-stat-item">
            <span class="stat-lbl">Total Orders</span>
            <span class="stat-val">${stats.ordersCount}</span>
          </div>
          <div class="person-hero-stat-item">
            <span class="stat-lbl">Lifetime Spent</span>
            <span class="stat-val">${formatMoney(stats.spent)}</span>
          </div>
          <div class="person-hero-stat-item">
            <span class="stat-lbl">Current Due</span>
            <span class="stat-val ${stats.due > 0 ? 'neg' : ''}">${formatMoney(stats.due)}</span>
          </div>
        </div>
      </section>

      <div class="orders-results-row r">
        <h2>Order History (${sortedOrders.length})</h2>
      </div>

      <section class="pnl orders-list-panel">
        <div class="rw h order-table-head" style="grid-template-columns:1.5fr 110px 100px 100px 100px 100px 60px">
          <span>Customer &amp; BD Number</span>
          <span>Status</span>
          <span>Order Date</span>
          <span>Delivery Date</span>
          <span class="rt">Total</span>
          <span class="rt">Due</span>
          <span></span>
        </div>
        <div class="order-list-desktop" style="display:flex;flex-direction:column;gap:4px">
          ${orderRowsDesktop}
        </div>
        <div class="order-list-mobile">
          ${orderRowsMobile}
        </div>
      </section>
    </main>
  `;
}

function render() {
  const root = document.getElementById('app');
  const active = document.activeElement;
  const focusId = active?.dataset?.focus;
  const settingField = active?.dataset?.settingField;
  const formKey = active?.dataset?.form;
  const activeId = active?.id;
  let selectionStart = null, selectionEnd = null;
  try {
    selectionStart = active?.selectionStart;
    selectionEnd = active?.selectionEnd;
  } catch {}

  const scrollY = window.scrollY;
  const page = state.screen === 'orders' ? renderOrders() :
               state.screen === 'drafts' ? renderDraftsScreen() :
               state.screen === 'delivery' ? renderDeliveryScreen() :
               state.screen === 'customers' ? renderCustomersScreen() :
               state.screen === 'customer-history' ? renderCustomerHistoryScreen() :
               state.screen === 'person-history' ? renderPersonHistoryScreen() :
               state.screen === 'settings' ? renderSettings() :
               ['print-slip', 'print-invoice'].includes(state.screen) ? renderPrintPage() :
               state.screen === 'form' ? renderForm() :
               renderDetails();

  root.innerHTML = `
    <div class="app-shell">
      ${renderHeader()}
      ${page}
      ${renderMobileMenu()}
      ${state.toast ? `
        <div class="toast ${state.toast.type === 'error' ? 'error' : ''}" role="status">
          <span>${state.toast.type === 'error' ? icon('alert') : icon('check')}</span>
          ${esc(state.toast.message)}
        </div>
      ` : ''}
      ${renderConfirmationModal()}
    </div>
  `;

  let target = null;
  if (focusId) {
    target = [...root.querySelectorAll('[data-focus]')].find(el => el.dataset.focus === focusId && el.getClientRects().length > 0);
  }
  if (!target && settingField) {
    target = root.querySelector(`[data-setting-field="${settingField}"]`);
  }
  if (!target && formKey) {
    target = [...root.querySelectorAll(`[data-form="${formKey}"]`)].find(el => el.getClientRects().length > 0);
  }
  if (!target && activeId) {
    target = root.querySelector(`#${activeId}`);
  }
  if (target) {
    target.focus({ preventScroll: true });
    try {
      if (selectionStart !== null && target.setSelectionRange) target.setSelectionRange(selectionStart, selectionEnd);
    } catch {}
  }
  window.scrollTo({ top: scrollY, behavior: 'instant' });
}

function markDirty() {
  state.dirty = true;
  state.formError = '';
  triggerLocalAutosave();
}

function startNewOrder() {
  state.mobileMenuOpen = false;
  try {
    const raw = localStorage.getItem(AUTOSAVE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (hasFormContent(parsed?.form)) {
        state.modal = {
          type: 'autosave-prompt',
          autosaveData: parsed
        };
        render();
        return;
      }
    }
  } catch {}

  state.screen = 'form';
  state.editingId = null;
  state.activeDraftId = null;
  state.form = newForm();
  state.formError = '';
  state.dirty = false;
  state.localAutosaved = false;
  state.mobileFormTab = 'items';
  state.totalEditOpen = false;
  state.itemSearch = '';
  state.selectedItemId = '';
  state.itemPickerOpen = false;
  state.quantity = 1;
  state.modal = null;
  render();
}

function startEditOrder(id) {
  const o = orderById(id);
  if (!o) return;
  state.mobileMenuOpen = false;
  state.screen = 'form';
  state.editingId = id;
  state.activeDraftId = null;
  state.form = formFromOrder(o);
  state.formError = '';
  state.dirty = false;
  state.localAutosaved = false;
  state.mobileFormTab = 'items';
  state.totalEditOpen = false;
  state.itemSearch = '';
  state.selectedItemId = '';
  state.itemPickerOpen = false;
  state.quantity = 1;
  state.modal = null;
  render();
}

function startCancel() {
  state.mobileMenuOpen = false;
  if (state.editingId) {
    if (state.dirty) {
      state.modal = { type: 'leave-form' };
      render();
    } else {
      state.screen = 'orders';
      state.form = null;
      state.editingId = null;
      state.modal = null;
      render();
    }
    return;
  }

  const hasContent = hasFormContent(state.form);
  if (!hasContent) {
    clearLocalAutosave();
    state.screen = state.activeDraftId ? 'drafts' : 'orders';
    state.form = null;
    state.activeDraftId = null;
    state.editingId = null;
    state.dirty = false;
    state.modal = null;
    render();
    return;
  }

  state.modal = {
    type: 'cancel-three-choice',
    isDraft: Boolean(state.activeDraftId)
  };
  render();
}

function validateForm() {
  const errors = [];
  if (!String(state.form?.customerName || '').trim()) errors.push('customer name');
  if (!String(state.form?.bdNumber || '').trim()) errors.push('BD number');
  if (!(state.form?.items || []).length) errors.push('at least one item');
  if (errors.length) return `Please add ${errors.join(', ')}.`;

  if (!Number.isFinite(Number(state.form.advance)) || Number(state.form.advance) < 0) {
    return 'Advance must be zero or a positive amount.';
  }
  if (state.form.deliveryDate && state.form.deliveryDate.length !== 10) {
    return 'Please enter a valid delivery date.';
  }
  const discText = String(state.form.discountInput || '').trim();
  if (discText && (!Number.isFinite(Number(discText.replace(/%\s*$/, '').replace(/,/g, ''))) || Number(discText.replace(/%\s*$/, '').replace(/,/g, '')) < 0)) {
    return 'Discount must be zero or a positive number.';
  }

  if (state.editingId) {
    const existing = orderById(state.editingId);
    if (existing) {
      const alreadyReceived = getTotalReceived(existing);
      const total = currentTotal();
      const discount = currentDiscount();
      const netTotal = Math.round((total - discount.amount) * 100) / 100;
      if (alreadyReceived > netTotal + 0.001) {
        return 'The money already received is more than the total. Please check the amounts.';
      }
    }
  }

  return '';
}

function serializeForm(orderNumber, existing = null, customerName = null) {
  const total = currentTotal(), discount = currentDiscount(), advance = Number(state.form.advance) || 0;
  const bd = String(state.form.bdNumber || '').trim();
  const savedCustomer = knownCustomer(bd);
  const name = customerName || savedCustomer?.name || String(state.form.customerName || '').trim();
  const rawCreated = existing?.createdAt || Date.now();
  const status = existing?.status || 'Pending';
  const deliveredDate = existing?.deliveredDate || '';
  const payments = Array.isArray(existing?.payments) ? existing.payments : [];

  const laterReceived = payments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
  const due = Math.max(0, Math.round((total - discount.amount - advance - laterReceived) * 100) / 100);

  return {
    id: existing?.id || uid(),
    category: 'Officer',
    orderNumber,
    customerBDNumber: bd,
    customerName: name,
    phone: String(state.form.phone || '').trim(),
    orderDate: state.form.orderDate || todayISO(),
    deliveryDate: state.form.deliveryDate || '',
    deliveredDate,
    status,
    ribbon: state.form.ribbon === '' ? '' : Number(state.form.ribbon),
    discountValue: discount.value,
    discountType: discount.type,
    discountAmount: discount.amount,
    advance,
    total,
    due,
    payments,
    measurements: {
      shirt: { ...blankMeasurements().shirt, ...state.form.shirt },
      pant: { ...blankMeasurements().pant, ...state.form.pant }
    },
    items: (state.form.items || []).map(i => ({ id: i.id || uid(), name: i.name, quantity: Number(i.quantity) || 1, price: Number(i.price) || 0 })),
    createdAt: rawCreated,
    createdDate: existing?.createdDate || existing?.orderDate || state.form.orderDate || todayISO(),
    updatedAt: Date.now()
  };
}

function addCustomerLocal(bd, name, phone) {
  const key = normBD(bd);
  let customer = state.customers.find(c => normBD(c.bdNumber) === key);
  if (!customer) {
    customer = { id: encodeURIComponent(key), category: 'Officer', bdNumber: String(bd).trim(), name, phone: phone || '', createdAt: Date.now() };
    state.customers.push(customer);
  } else {
    if (phone && !customer.phone) customer.phone = phone;
  }
  return customer;
}

async function saveOrder() {
  const error = validateForm();
  if (error) {
    state.formError = error;
    render();
    return;
  }
  if (isFirebaseConfigured && !state.backendReady) {
    notify('Waiting for the Firebase database connection.', 'error');
    return;
  }
  const existing = state.editingId ? orderById(state.editingId) : null;
  const lookup = knownCustomer(state.form.bdNumber);
  if (lookup) state.form.customerName = lookup.name;
  const name = lookup?.name || String(state.form.customerName || '').trim();
  if (!name) {
    state.formError = 'Please add the customer name.';
    render();
    return;
  }

  try {
    if (isFirebaseConfigured) {
      const orderNo = existing ? existing.orderNumber : null;
      const saved = await firebase.saveOrder({ existing, orderNo, form: state.form, name });
      if (state.activeDraftId) {
        const draftToDeleteId = state.activeDraftId;
        state.activeDraftId = null;
        firebase.deleteDoc(firebase.doc(firebase.db, 'officerDrafts', draftToDeleteId)).catch(console.error);
      }
      clearLocalAutosave();
      state.form = null;
      state.screen = 'orders';
      state.editingId = null;
      state.dirty = false;
      notify(existing ? `Order #${saved.orderNumber} updated.` : `Order #${saved.orderNumber} saved.`);
    } else {
      const customer = addCustomerLocal(state.form.bdNumber, name, String(state.form.phone || '').trim());
      const order = serializeForm(existing ? existing.orderNumber : localSequence, existing, customer.name);
      if (existing) {
        const idx = state.orders.findIndex(o => o.id === existing.id);
        if (idx >= 0) state.orders[idx] = order;
        notify(`Order #${order.orderNumber} updated.`);
      } else {
        state.orders.push(order);
        localSequence += 1;
        notify(`Order #${order.orderNumber} saved.`);
      }
      if (state.activeDraftId) {
        const draftToDeleteId = state.activeDraftId;
        state.activeDraftId = null;
        state.drafts = state.drafts.filter(d => d.id !== draftToDeleteId);
        saveDraftsLocal();
      }
      clearLocalAutosave();
      state.orders.sort((a, b) => a.orderNumber - b.orderNumber);
      saveLocalState();
      state.form = null;
      state.screen = 'orders';
      state.editingId = null;
      state.dirty = false;
    }
    state.formError = '';
    render();
  } catch (e) {
    console.error(e);
    notify(e?.message ? `Could not save order: ${e.message}` : 'Could not save order.', 'error');
  }
}

// PRD Section 5.3: Save first before opening print preview from the form
async function saveAndPrint(paperType) {
  const error = validateForm();
  if (error) {
    state.formError = error;
    notify(error, 'error');
    render();
    return;
  }
  if (isFirebaseConfigured && !state.backendReady) {
    notify('Waiting for the Firebase database connection.', 'error');
    return;
  }
  const existing = state.editingId ? orderById(state.editingId) : null;
  const lookup = knownCustomer(state.form.bdNumber);
  if (lookup) state.form.customerName = lookup.name;
  const name = lookup?.name || String(state.form.customerName || '').trim();
  if (!name) {
    state.formError = 'Please add the customer name.';
    render();
    return;
  }

  try {
    let savedOrder = null;
    if (isFirebaseConfigured) {
      const orderNo = existing ? existing.orderNumber : null;
      savedOrder = await firebase.saveOrder({ existing, orderNo, form: state.form, name });
      if (state.activeDraftId) {
        const draftToDeleteId = state.activeDraftId;
        state.activeDraftId = null;
        firebase.deleteDoc(firebase.doc(firebase.db, 'officerDrafts', draftToDeleteId)).catch(console.error);
      }
      clearLocalAutosave();
    } else {
      const customer = addCustomerLocal(state.form.bdNumber, name, String(state.form.phone || '').trim());
      const orderNumber = existing ? existing.orderNumber : localSequence;
      savedOrder = serializeForm(orderNumber, existing, customer.name);
      if (existing) {
        const idx = state.orders.findIndex(o => o.id === existing.id);
        if (idx >= 0) state.orders[idx] = savedOrder;
      } else {
        state.orders.push(savedOrder);
        localSequence += 1;
      }
      if (state.activeDraftId) {
        const draftToDeleteId = state.activeDraftId;
        state.activeDraftId = null;
        state.drafts = state.drafts.filter(d => d.id !== draftToDeleteId);
        saveDraftsLocal();
      }
      clearLocalAutosave();
      state.orders.sort((a, b) => a.orderNumber - b.orderNumber);
      saveLocalState();
    }
    state.form = null;
    state.editingId = null;
    state.dirty = false;
    notify(`Order #${savedOrder.orderNumber} saved.`);
    openPrint(paperType, savedOrder.id, 'orders');
  } catch (e) {
    console.error(e);
    notify(e?.message ? `Could not save order: ${e.message}` : 'Could not save order.', 'error');
  }
}

async function updateOrderStatus(orderId, newStatus) {
  const order = orderById(orderId);
  if (!order || order.status === newStatus) return;

  const today = todayISO();
  const deliveredDate = newStatus === 'Delivered' ? today : '';

  try {
    if (isFirebaseConfigured && state.backendReady) {
      const fs = firebase, db = firebase.db;
      await fs.updateDoc(fs.doc(db, 'officerOrders', orderId), {
        status: newStatus,
        deliveredDate: deliveredDate || null,
        updatedAt: fs.serverTimestamp()
      });
    } else {
      order.status = newStatus;
      order.deliveredDate = deliveredDate;
      order.updatedAt = Date.now();
      saveLocalState();
    }
    notify(`Order #${order.orderNumber} is now ${newStatus}`);
    render();
  } catch (e) {
    console.error('Failed to update status', e);
    notify('Could not update status. Try again.', 'error');
  }
}

async function recordPayment(orderId) {
  const order = orderById(orderId);
  if (!order) return;
  const due = getOrderDue(order);
  if (due <= 0) return;

  const newPayment = {
    id: uid(),
    orderId,
    amount: due,
    date: todayISO(),
    createdAt: Date.now()
  };

  try {
    if (isFirebaseConfigured && state.backendReady) {
      const fs = firebase, db = firebase.db;
      const currentPayments = Array.isArray(order.payments) ? order.payments : [];
      await fs.updateDoc(fs.doc(db, 'officerOrders', orderId), {
        payments: [...currentPayments, newPayment],
        due: 0,
        updatedAt: fs.serverTimestamp()
      });
    } else {
      if (!Array.isArray(order.payments)) order.payments = [];
      order.payments.push(newPayment);
      order.due = 0;
      order.updatedAt = Date.now();
      saveLocalState();
    }
    state.modal = null;
    notify(`Order #${order.orderNumber} fully paid (${formatMoney(due)} received)`);
    render();
  } catch (e) {
    console.error('Failed to record payment', e);
    notify('Could not record payment. Try again.', 'error');
  }
}

async function deleteOrder(id) {
  const o = orderById(id);
  if (!o) return;
  try {
    if (isFirebaseConfigured) {
      if (!state.backendReady) throw new Error('Firebase is not connected yet.');
      await firebase.deleteOrder(id, o.orderNumber);
    } else {
      state.orders = state.orders.filter(x => x.id !== id).sort((a, b) => a.orderNumber - b.orderNumber);
      state.orders.forEach((item, index) => { item.orderNumber = index + 1; });
      localSequence = state.orders.length + 1;
      saveLocalState();
    }
    if (state.screen === 'details' && state.detailId === id) state.screen = 'orders';
    state.modal = null;
    state.detailId = null;
    notify(`Order #${o.orderNumber} deleted.`);
    render();
  } catch (e) {
    console.error(e);
    notify(e?.message ? `Could not delete order: ${e.message}` : 'Could not delete order.', 'error');
  }
}

async function saveSettings() {
  if (isFirebaseConfigured && !state.backendReady) {
    notify('Waiting for the Firebase database connection.', 'error');
    return;
  }
  try {
    if (isFirebaseConfigured) await firebase.saveSettings(state.settings);
    else saveLocalState();
  } catch (e) {
    console.error(e);
    notify('Could not save settings.', 'error');
  }
}

function updateMeasurement(field, value) {
  const [kind, ...rest] = field.split('.');
  const label = rest.join('.');
  if (!state.form[kind]) state.form[kind] = {};
  state.form[kind][label] = value;
}

function handleInput(e) {
  const t = e.target;
  if (t.dataset.settingQuick) {
    state.settingsQuickAdd = { ...(state.settingsQuickAdd || {}), [t.dataset.settingQuick]: t.value };
    return;
  }
  if (t.dataset.settingField === 'upcomingDeliveryDays') {
    const val = Math.max(1, Math.min(60, Math.floor(Number(t.value) || 3)));
    state.settings.upcomingDeliveryDays = val;
    saveSettings();
    render();
    return;
  }
  if (t.dataset.settingField === 'shopName') {
    state.settings.shopName = t.value;
    saveSettings();
    render();
    return;
  }
  if (t.dataset.settingField === 'terms') {
    state.settings.terms = t.value;
    saveSettings();
    render();
    return;
  }
  if (t.dataset.form && state.form) {
    const key = t.dataset.form;
    let value = t.value;
    if (key.startsWith('shirt.') || key.startsWith('pant.')) updateMeasurement(key, value);
    else if (key === 'bdNumber') {
      state.form.bdNumber = value;
      state.customerSuggestionField = 'bdNumber';
      state.customerSuggestionsOpen = Boolean(value.trim());
      const c = knownCustomer(value);
      if (c && !state.form.customerName) {
        state.form.customerName = c.name;
        if (c.phone && !state.form.phone) state.form.phone = c.phone;
      }
    } else if (key === 'customerName') {
      state.form.customerName = value;
      state.customerSuggestionField = 'customerName';
      state.customerSuggestionsOpen = Boolean(value.trim());
    } else if (key === 'totalOverride') {
      state.form.totalOverride = value === '' ? null : Math.max(0, Number(value) || 0);
    } else if (key === 'advance') {
      state.form.advance = value === '' ? '' : Math.max(0, Number(value) || 0);
    } else if (key === 'discountInput') {
      state.form.discountInput = value;
    } else if (key === 'ribbon') {
      state.form.ribbon = value;
    } else {
      state.form[key] = value;
    }
    markDirty();
    render();
    return;
  }
  if (t.dataset.modalField && state.modal) {
    state.modal[t.dataset.modalField] = t.value;
    state.modal.error = '';
    return;
  }
  if (t.dataset.focus === 'customer-search') {
    state.customerSearch = t.value;
    render();
    return;
  }
  if (t.dataset.focus === 'customer-history-search') {
    state.customerHistorySearch = t.value;
    render();
    return;
  }
  if (t.dataset.focus === 'orders-search') {
    state.search = t.value;
    state.mobileSearchOpen = true;
    render();
    return;
  }
  if (t.dataset.focus === 'delivery-search') {
    state.deliverySearch = t.value;
    render();
    return;
  }
  if (t.dataset.focus === 'item-search') {
    state.itemSearch = t.value;
    state.selectedItemId = '';
    state.itemPickerOpen = true;
    render();
    return;
  }
  if (t.dataset.focus === 'item-quantity') {
    state.quantity = t.value;
    render();
    return;
  }
  if (t.dataset.settingItem && state.settingsItemModal) {
    state.settingsItemModal.item = {
      ...(state.settingsItemModal.item || {}),
      [t.dataset.settingItem]: t.dataset.settingItem === 'price' ? (t.value === '' ? '' : Number(t.value)) : t.value
    };
    return;
  }
}

function handleChange(e) {
  const t = e.target;
  if (t.dataset.change === 'sort') {
    state.sort = t.value;
    render();
    return;
  }
  if (t.dataset.action === 'change-customer-sort') {
    state.customerSort = t.value;
    render();
    return;
  }
  if (t.dataset.action === 'change-order-status') {
    const orderId = t.dataset.id;
    const newStatus = t.value;
    updateOrderStatus(orderId, newStatus);
    return;
  }
  if (t.dataset.settingField === 'invoicePaperSize') {
    state.settings.invoicePaperSize = t.value === 'A5' ? 'A5' : 'A4';
    saveSettings();
    render();
    return;
  }
  if (t.dataset.settingField === 'cuttingSlipPaperSize') {
    state.settings.cuttingSlipPaperSize = t.value === 'A5' ? 'A5' : 'A4';
    saveSettings();
    render();
    return;
  }
  if (t.dataset.change === 'upload-logo') {
    const file = t.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        notify('Logo image must be smaller than 2MB.', 'error');
        return;
      }
      const reader = new FileReader();
      reader.onload = (evt) => {
        state.settings.shopLogo = String(evt.target?.result || '');
        saveSettings();
        notify('Shop logo updated.');
        render();
      };
      reader.readAsDataURL(file);
    }
    return;
  }
  if (t.dataset.change === 'discount-type') {
    state.settings.defaultDiscountType = t.value;
    saveSettings();
    render();
    return;
  }
  if (t.dataset.form === 'ribbon' && state.form) {
    state.form.ribbon = t.value;
    markDirty();
    render();
    return;
  }
}

function openItemModal(mode, item = null) {
  state.settingsItemModal = { mode, item: item ? deepClone(item) : { id: uid(), name: '', price: '', needsPriceCheck: false, originalPrice: null } };
  render();
}

async function saveItemModal() {
  const m = state.settingsItemModal;
  if (!m) return;
  const name = String(m.item?.name || '').trim(), price = Number(m.item?.price);
  if (!name) {
    notify('Please enter the item name.', 'error');
    return;
  }
  if (!Number.isFinite(price) || price < 0) {
    notify('Please enter a valid price.', 'error');
    return;
  }
  const existing = state.settings.items.find(i => i.id === m.item.id);
  if (m.mode === 'edit' && existing) {
    const priceChanged = Number(existing.price) !== price;
    state.settings.items = state.settings.items.map(i => i.id === existing.id ? { ...i, name, price, needsPriceCheck: priceChanged ? false : !!i.needsPriceCheck } : i);
  } else {
    state.settings.items.push({ id: m.item.id || uid(), name, price, needsPriceCheck: false });
  }
  state.settingsItemModal = null;
  await saveSettings();
  notify(m.mode === 'edit' ? 'Item updated.' : 'Item added.');
  render();
}

function handleClick(e) {
  if (state.customerSuggestionsOpen && !e.target.closest('.customer-field-wrap') && !e.target.closest('.customer-suggestions')) {
    state.customerSuggestionsOpen = false;
    if (!e.target.closest('[data-action]')) {
      render();
      return;
    }
  }

  const target = e.target.closest('[data-action]');
  if (!target) return;
  if (target.matches('a[href="#"]')) e.preventDefault();

  const action = target.dataset.action, id = target.dataset.id;

  if (action === 'choose-item') {
    e.preventDefault();
    document.activeElement?.blur();
  }
  if (action === 'toggle-mobile-menu') {
    state.mobileMenuOpen = !state.mobileMenuOpen;
    render();
    return;
  }
  if (action === 'toggle-mobile-search') {
    state.mobileSearchOpen = !state.mobileSearchOpen;
    render();
    if (state.mobileSearchOpen) document.querySelector('[data-focus="orders-search"]')?.focus();
    return;
  }
  if (action === 'mobile-form-tab') {
    state.mobileFormTab = ['items', 'customer', 'measure', 'money'].includes(target.dataset.tab) ? target.dataset.tab : 'items';
    state.itemPickerOpen = false;
    render();
    return;
  }
  if (action === 'enable-total-edit') {
    if (state.editingId) {
      state.totalEditOpen = true;
      state.mobileFormTab = 'money';
      render();
      [...document.querySelectorAll('[data-focus="form-totalOverride"]')].find(el => el.getClientRects().length > 0)?.focus();
    }
    return;
  }
  if (action === 'navigate') {
    if (state.screen === 'form' && state.dirty) {
      startCancel();
      return;
    }
    state.screen = target.dataset.screen;
    state.form = null;
    state.editingId = null;
    state.activeDraftId = null;
    state.modal = null;
    state.mobileMenuOpen = false;
    render();
    return;
  }
  if (action === 'go-delivery') {
    state.screen = 'delivery';
    state.mobileMenuOpen = false;
    render();
    return;
  }
  if (action === 'set-tab') {
    state.activeTab = target.dataset.tab;
    render();
    return;
  }
  if (action === 'toggle-card-filter') {
    const filter = target.dataset.filter;
    state.cardFilter = state.cardFilter === filter ? null : filter;
    render();
    return;
  }
  if (action === 'clear-card-filter') {
    state.cardFilter = null;
    render();
    return;
  }
  if (action === 'reset-filters') {
    state.search = '';
    state.activeTab = 'All';
    state.cardFilter = null;
    render();
    return;
  }
  if (action === 'clear-delivery-search') {
    state.deliverySearch = '';
    render();
    return;
  }
  if (action === 'deliver-order') {
    updateOrderStatus(id, 'Delivered');
    notify(`Order #${orderById(id)?.orderNumber || ''} delivered`);
    return;
  }
  if (action === 'prompt-pay') {
    const o = orderById(id);
    if (!o) return;
    state.modal = {
      type: 'pay-confirm',
      orderId: id
    };
    render();
    return;
  }
  if (action === 'confirm-pay') {
    recordPayment(id);
    return;
  }
  if (action === 'cancel-modal') {
    state.modal = null;
    render();
    return;
  }

  // Print Handlers
  if (action === 'print-slip') {
    openPrint('slip', id, 'orders');
    return;
  }
  if (action === 'print-invoice') {
    openPrint('invoice', id, 'orders');
    return;
  }
  if (action === 'details-print-slip') {
    openPrint('slip', id, 'details');
    return;
  }
  if (action === 'details-print-invoice') {
    openPrint('invoice', id, 'details');
    return;
  }
  if (action === 'form-print-slip') {
    saveAndPrint('slip');
    return;
  }
  if (action === 'form-print-invoice') {
    saveAndPrint('invoice');
    return;
  }
  if (action === 'back-from-print') {
    state.screen = state.printReturnScreen || 'orders';
    if (state.screen === 'details' && state.printOrderId) {
      state.detailId = state.printOrderId;
    }
    render();
    return;
  }
  if (action === 'switch-print-paper') {
    state.screen = state.screen === 'print-slip' ? 'print-invoice' : 'print-slip';
    render();
    window.scrollTo({ top: 0, behavior: 'instant' });
    return;
  }
  if (action === 'trigger-print') {
    window.print();
    return;
  }

  // Settings Handlers
  if (action === 'remove-logo') {
    state.settings.shopLogo = '';
    saveSettings();
    notify('Shop logo removed.');
    render();
    return;
  }
  if (action === 'set-discount-type') {
    state.settings.defaultDiscountType = target.dataset.type === 'taka' ? 'taka' : 'percentage';
    saveSettings();
    render();
    return;
  }
  if (action === 'add-item-inline') {
    const q = state.settingsQuickAdd || {};
    const name = String(q.name || '').trim();
    const price = Number(q.price);
    if (!name) {
      notify('Please enter the item name.', 'error');
      return;
    }
    if (q.price === '' || !Number.isFinite(price) || price < 0) {
      notify('Please enter a valid price.', 'error');
      return;
    }
    state.settings.items.push({ id: uid(), name, price, needsPriceCheck: false });
    state.settingsQuickAdd = { name: '', price: '' };
    saveSettings();
    notify('Item added.');
    render();
    return;
  }
  if (action === 'new-order') {
    startNewOrder();
    return;
  }
  if (action === 'clear-search') {
    state.search = '';
    state.mobileSearchOpen = false;
    render();
    return;
  }
  if (action === 'open-details') {
    state.detailsReturnScreen = state.screen;
    state.screen = 'details';
    state.detailId = id;
    state.modal = null;
    render();
    return;
  }
  if (action === 'back-to-orders') {
    state.screen = state.detailsReturnScreen || 'orders';
    state.detailId = null;
    state.detailsReturnScreen = null;
    state.mobileMenuOpen = false;
    render();
    return;
  }
  if (action === 'clear-customer-search') {
    state.customerSearch = '';
    render();
    return;
  }
  if (action === 'clear-customer-history-search') {
    state.customerHistorySearch = '';
    render();
    return;
  }
  if (action === 'add-customer') {
    state.modal = {
      type: 'add-customer',
      bdNumber: '',
      name: '',
      phone: '',
      error: ''
    };
    render();
    return;
  }
  if (action === 'save-add-customer') {
    const bd = String(state.modal?.bdNumber || '').trim();
    const name = String(state.modal?.name || '').trim();
    const phone = String(state.modal?.phone || '').trim();

    if (!bd) {
      state.modal.error = 'Please enter a BD number.';
      render();
      return;
    }
    if (!name) {
      state.modal.error = 'Please enter customer name.';
      render();
      return;
    }

    const key = normBD(bd);
    const existing = state.customers.find(c => normBD(c.bdNumber) === key);
    if (existing) {
      state.modal.error = `This BD number already belongs to ${existing.name}.`;
      render();
      return;
    }

    const newCust = {
      id: encodeURIComponent(key),
      category: 'Officer',
      bdNumber: bd,
      name,
      phone,
      createdAt: Date.now()
    };

    if (isFirebaseConfigured && state.backendReady) {
      const fs = firebase, db = firebase.db;
      fs.setDoc(fs.doc(db, 'officerCustomers', newCust.id), newCust).catch(console.error);
    }
    state.customers.push(newCust);
    saveLocalState();
    state.modal = null;
    notify(`Customer ${bd} saved.`);
    render();
    return;
  }
  if (action === 'edit-customer') {
    const bd = target.dataset.bd || id;
    const c = knownCustomer(bd);
    if (!c) {
      notify('Customer not found.', 'error');
      return;
    }
    state.modal = {
      type: 'edit-customer',
      bdNumber: c.bdNumber,
      name: c.name,
      phone: c.phone || '',
      error: ''
    };
    render();
    return;
  }
  if (action === 'save-edit-customer') {
    const bd = String(state.modal?.bdNumber || '').trim();
    const name = String(state.modal?.name || '').trim();
    const phone = String(state.modal?.phone || '').trim();

    if (!name) {
      state.modal.error = 'Please enter customer name.';
      render();
      return;
    }

    const key = normBD(bd);
    const cust = state.customers.find(c => normBD(c.bdNumber) === key);
    if (cust) {
      cust.name = name;
      cust.phone = phone;
    }

    // PRD Section 5.2: Update Customer Name and phone across all existing orders for that Officer
    state.orders.forEach(o => {
      if (normBD(o.customerBDNumber) === key) {
        o.customerName = name;
        if (phone) o.phone = phone;
      }
    });

    state.drafts.forEach(d => {
      if (normBD(d.bdNumber) === key) {
        d.customerName = name;
        if (phone) d.phone = phone;
      }
    });

    if (isFirebaseConfigured && state.backendReady) {
      firebaseSaveCustomerEdit(bd, name, phone).catch(console.error);
    }

    saveLocalState();
    saveDraftsLocal();
    state.modal = null;
    notify(`Customer ${bd} updated.`);
    render();
    return;
  }
  if (action === 'delete-customer') {
    const bd = target.dataset.bd || id;
    const c = knownCustomer(bd);
    if (!c) return;

    const stats = getCustomerStats(bd);
    if (stats.ordersCount > 0) {
      state.modal = {
        type: 'customer-has-orders-alert',
        bdNumber: c.bdNumber,
        customerName: c.name,
        ordersCount: stats.ordersCount
      };
    } else {
      state.modal = {
        type: 'confirm-delete-customer',
        bdNumber: c.bdNumber,
        customerName: c.name
      };
    }
    render();
    return;
  }
  if (action === 'confirm-delete-customer-action') {
    const bd = state.modal?.bdNumber || target.dataset.bd;
    if (!bd) return;

    const key = normBD(bd);
    state.customers = state.customers.filter(c => normBD(c.bdNumber) !== key);

    if (isFirebaseConfigured && state.backendReady) {
      firebaseDeleteCustomer(bd).catch(console.error);
    }

    saveLocalState();
    state.modal = null;
    if (state.screen === 'person-history') {
      state.screen = 'customers';
      state.personHistoryBD = null;
    }
    notify(`Customer ${bd} deleted.`);
    render();
    return;
  }
  if (action === 'open-person-history') {
    const bd = target.dataset.bd || id;
    state.personHistoryReturnScreen = state.screen === 'customer-history' ? 'customer-history' : 'customers';
    state.screen = 'person-history';
    state.personHistoryBD = bd;
    state.mobileMenuOpen = false;
    render();
    window.scrollTo({ top: 0, behavior: 'instant' });
    return;
  }
  if (action === 'back-from-person-history') {
    state.screen = state.personHistoryReturnScreen || 'customers';
    state.personHistoryBD = null;
    state.mobileMenuOpen = false;
    render();
    window.scrollTo({ top: 0, behavior: 'instant' });
    return;
  }
  if (action === 'new-order-for-customer') {
    const bd = target.dataset.bd || id;
    const c = knownCustomer(bd);
    startNewOrder();
    if (c) {
      state.form.bdNumber = c.bdNumber;
      state.form.customerName = c.name;
      state.form.phone = c.phone || '';
      markDirty();
    }
    render();
    return;
  }
  if (action === 'pick-customer-suggestion') {
    const bd = target.dataset.bd;
    const c = knownCustomer(bd);
    if (c && state.form) {
      state.form.bdNumber = c.bdNumber;
      state.form.customerName = c.name;
      if (c.phone) state.form.phone = c.phone;
      state.customerSuggestionsOpen = false;
      markDirty();
      render();
    }
    return;
  }
  if (action === 'edit-order') {
    startEditOrder(id);
    return;
  }
  if (action === 'delete-first') {
    state.modal = { type: 'delete-first', id };
    render();
    return;
  }
  if (action === 'continue-delete') {
    if (state.modal?.type === 'delete-first') state.modal = { type: 'delete-second', id: state.modal.id };
    render();
    return;
  }
  if (action === 'cancel-delete') {
    state.modal = null;
    render();
    return;
  }
  if (action === 'confirm-delete') {
    const targetId = state.modal?.id;
    deleteOrder(targetId);
    return;
  }
  if (action === 'cancel-form') {
    startCancel();
    return;
  }
  if (action === 'open-draft') {
    openDraft(id);
    return;
  }
  if (action === 'save-as-draft') {
    saveAsDraft();
    return;
  }
  if (action === 'update-draft') {
    updateDraft();
    return;
  }
  if (action === 'prompt-delete-draft') {
    state.modal = { type: 'delete-draft', id };
    render();
    return;
  }
  if (action === 'confirm-delete-draft') {
    const draftId = id || state.modal?.id;
    deleteDraft(draftId);
    return;
  }
  if (action === 'cancel-save-draft') {
    if (state.modal?.isDraft) updateDraft();
    else saveAsDraft();
    return;
  }
  if (action === 'cancel-discard') {
    clearLocalAutosave();
    state.screen = state.activeDraftId ? 'drafts' : 'orders';
    state.form = null;
    state.activeDraftId = null;
    state.editingId = null;
    state.dirty = false;
    state.modal = null;
    state.formError = '';
    render();
    return;
  }
  if (action === 'cancel-keep-editing') {
    state.modal = null;
    render();
    return;
  }
  if (action === 'autosave-continue') {
    const data = state.modal?.autosaveData;
    state.modal = null;
    state.screen = 'form';
    state.editingId = null;
    state.activeDraftId = data?.activeDraftId || null;
    state.form = data?.form || newForm();
    state.dirty = true;
    state.localAutosaved = true;
    state.mobileFormTab = 'items';
    state.formError = '';
    render();
    return;
  }
  if (action === 'autosave-start-fresh') {
    clearLocalAutosave();
    state.modal = null;
    state.screen = 'form';
    state.editingId = null;
    state.activeDraftId = null;
    state.form = newForm();
    state.dirty = false;
    state.localAutosaved = false;
    state.mobileFormTab = 'items';
    state.formError = '';
    render();
    return;
  }
  if (action === 'stay-form') {
    state.modal = null;
    render();
    return;
  }
  if (action === 'leave-form') {
    clearLocalAutosave();
    state.modal = null;
    state.screen = 'orders';
    state.form = null;
    state.editingId = null;
    state.activeDraftId = null;
    state.formError = '';
    state.dirty = false;
    render();
    return;
  }
  if (action === 'close-modal-bg' && e.target === target) {
    state.modal = null;
    render();
    return;
  }
  if (action === 'close-item-modal-bg' && e.target === target) {
    state.settingsItemModal = null;
    render();
    return;
  }
  if (action === 'add-order-item') {
    const exact = state.settings.items.find(i => i.id === state.selectedItemId) || state.settings.items.find(i => i.name.toLowerCase() === state.itemSearch.trim().toLowerCase());
    if (!exact) {
      notify('Choose an item from the list first.', 'error');
      state.itemPickerOpen = true;
      render();
      return;
    }
    const quantity = Math.floor(Number(state.quantity) || 1);
    if (quantity < 1) {
      notify('Quantity must be at least 1.', 'error');
      return;
    }
    state.form.items.push({ id: uid(), name: exact.name, quantity, price: Number(exact.price) || 0 });
    state.itemSearch = '';
    state.selectedItemId = '';
    state.itemPickerOpen = false;
    state.quantity = 1;
    markDirty();
    render();
    return;
  }
  if (action === 'choose-item') {
    const item = state.settings.items.find(i => i.id === id);
    if (item) {
      state.selectedItemId = id;
      state.itemSearch = item.name;
      state.itemPickerOpen = false;
      render();
    }
    return;
  }
  if (action === 'remove-order-item') {
    state.form.items = state.form.items.filter(i => i.id !== id);
    markDirty();
    render();
    return;
  }
  if (action === 'change-item-quantity') {
    const line = state.form?.items?.find(i => i.id === id);
    if (line) {
      line.quantity = Math.max(1, Math.floor(Number(line.quantity) || 1) + Number(target.dataset.delta || 0));
      markDirty();
      render();
    }
    return;
  }
  if (action === 'save-order') {
    saveOrder();
    return;
  }
  if (action === 'add-item') {
    openItemModal('add');
    return;
  }
  if (action === 'edit-item') {
    const item = state.settings.items.find(i => i.id === id);
    if (item) openItemModal('edit', item);
    return;
  }
  if (action === 'close-item-modal') {
    state.settingsItemModal = null;
    render();
    return;
  }
  if (action === 'save-item') {
    saveItemModal();
    return;
  }
  if (action === 'remove-item') {
    state.modal = { type: 'remove-item', id };
    render();
    return;
  }
  if (action === 'confirm-remove-item') {
    const itemId = state.modal?.id;
    state.settings.items = state.settings.items.filter(i => i.id !== itemId);
    state.modal = null;
    saveSettings();
    notify('Item removed.');
    render();
    return;
  }
  if (action === 'add-ribbon') {
    const input = document.getElementById('ribbon-new-value');
    const v = Number(input?.value);
    if (!input || input.value.trim() === '' || !Number.isFinite(v)) {
      notify('Enter a ribbon number.', 'error');
      return;
    }
    if (state.settings.ribbonValues.some(x => Number(x) === v)) {
      notify('That ribbon value is already listed.', 'error');
      return;
    }
    state.settings.ribbonValues = [...state.settings.ribbonValues, v].sort((a, b) => a - b);
    saveSettings();
    render();
    return;
  }
  if (action === 'remove-ribbon') {
    const v = Number(target.dataset.value);
    state.settings.ribbonValues = state.settings.ribbonValues.filter(x => Number(x) !== v);
    saveSettings();
    render();
    return;
  }
}

function handleKeydown(e) {
  const t = e.target.closest('[data-action="open-details"]');
  if (t && (e.key === 'Enter' || e.key === ' ')) {
    e.preventDefault();
    state.screen = 'details';
    state.detailId = t.dataset.id;
    render();
  }
  if (e.key === 'Escape') {
    if (state.settingsItemModal) {
      state.settingsItemModal = null;
      render();
    } else if (state.modal) {
      state.modal = null;
      render();
    } else if (['print-slip', 'print-invoice'].includes(state.screen)) {
      state.screen = state.printReturnScreen || 'orders';
      render();
    } else if (state.screen === 'form') {
      startCancel();
    } else if (['details', 'delivery'].includes(state.screen)) {
      state.screen = 'orders';
      state.detailId = null;
      render();
    }
  }
}

document.addEventListener('click', handleClick);
document.addEventListener('input', handleInput);
document.addEventListener('change', handleChange);
document.addEventListener('keydown', handleKeydown);
document.addEventListener('focusin', e => {
  if (e.target.dataset.focus === 'item-search' && state.screen === 'form' && !state.itemPickerOpen) {
    state.itemPickerOpen = true;
    render();
  }
});
document.addEventListener('focusout', e => {
  if (e.target.dataset.focus === 'item-search') {
    setTimeout(() => {
      if (state.itemPickerOpen && !document.activeElement?.closest('.item-suggestions')) {
        state.itemPickerOpen = false;
        render();
      }
    }, 120);
  }
});

async function initFirebase() {
  const config = window.TAILOR_FIREBASE_CONFIG;
  const [appMod, fs] = await Promise.all([
    import('https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js'),
    import('https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js')
  ]);
  const app = appMod.initializeApp(config), db = fs.getFirestore(app);
  firebase = { ...fs, app, db };
  const settingsRef = fs.doc(db, 'settings', 'officerCore');
  const counterRef = fs.doc(db, 'counters', 'officerOrders');
  let seedingSettings = false, seedingCounter = false;
  const ready = { orders: false, customers: false, settings: false };
  const checkReady = () => {
    state.backendReady = ready.orders && ready.customers && ready.settings;
    state.loaded = state.backendReady;
    render();
  };

  fs.onSnapshot(fs.collection(db, 'officerOrders'), snap => {
    state.orders = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    state.orders.sort((a, b) => Number(a.orderNumber || 0) - Number(b.orderNumber || 0));
    ready.orders = true;
    state.remoteError = '';
    checkReady();
  }, err => {
    console.error(err);
    state.remoteError = err.code === 'permission-denied' ? 'Firestore permission denied. Apply testing rules.' : err.message || 'Could not read orders.';
    state.loaded = true;
    render();
  });

  fs.onSnapshot(fs.collection(db, 'officerCustomers'), snap => {
    state.customers = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    ready.customers = true;
    state.remoteError = '';
    checkReady();
  }, err => {
    console.error(err);
    state.remoteError = err.code === 'permission-denied' ? 'Firestore permission denied.' : err.message || 'Could not read customers.';
    state.loaded = true;
    render();
  });

  fs.onSnapshot(fs.collection(db, 'officerDrafts'), snap => {
    state.drafts = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    state.drafts.sort((a, b) => Number(b.updatedAt || b.createdAt || 0) - Number(a.updatedAt || a.createdAt || 0));
    render();
  }, err => {
    console.warn('officerDrafts listener info:', err);
  });

  fs.onSnapshot(settingsRef, snap => {
    if (snap.exists()) {
      const d = snap.data();
      state.settings = {
        ...defaultSettings(),
        ...d,
        items: Array.isArray(d.items) ? d.items : deepClone(STARTER_ITEMS),
        ribbonValues: Array.isArray(d.ribbonValues) ? d.ribbonValues : [...RIBBON_DEFAULTS],
        upcomingDeliveryDays: Number(d.upcomingDeliveryDays) || 3,
        shopName: d.shopName || 'Darzi Tailor Shop',
        shopLogo: d.shopLogo || '',
        terms: d.terms || defaultSettings().terms,
        invoicePaperSize: d.invoicePaperSize || 'A4',
        cuttingSlipPaperSize: d.cuttingSlipPaperSize || 'A4'
      };
      ready.settings = true;
      state.remoteError = '';
      checkReady();
    } else if (!seedingSettings) {
      seedingSettings = true;
      fs.setDoc(settingsRef, { ...defaultSettings(), updatedAt: fs.serverTimestamp() })
        .catch(err => { console.error(err); state.remoteError = err.message; render(); })
        .finally(() => { seedingSettings = false; });
    }
  }, err => {
    console.error(err);
    state.remoteError = err.code === 'permission-denied' ? 'Firestore permission denied.' : err.message || 'Could not read settings.';
    state.loaded = true;
    render();
  });

  fs.getDoc(counterRef).then(snap => {
    if (!snap.exists() && !seedingCounter) {
      seedingCounter = true;
      return fs.setDoc(counterRef, { nextOrderNumber: 532, updatedAt: fs.serverTimestamp() }).finally(() => { seedingCounter = false; });
    }
  }).catch(err => console.error('Could not initialize order counter', err));

  return { db, ...fs };
}

async function firebaseSaveOrder({ existing, form, name }) {
  const fs = firebase, db = firebase.db;
  const bd = String(form.bdNumber || '').trim(), customerDocId = encodeURIComponent(normBD(bd));
  const customerRef = fs.doc(db, 'officerCustomers', customerDocId);
  const counterRef = fs.doc(db, 'counters', 'officerOrders');
  const orderRef = existing ? fs.doc(db, 'officerOrders', existing.id) : fs.doc(fs.collection(db, 'officerOrders'));
  let finalOrder = null;

  await fs.runTransaction(db, async tx => {
    const customerSnap = await tx.get(customerRef);
    let counterSnap = null;
    if (!existing) counterSnap = await tx.get(counterRef);
    const customerData = customerSnap.exists() ? customerSnap.data() : null;
    const finalName = customerData?.name || name;
    const finalPhone = String(form.phone || '').trim();
    const customerPhone = customerData?.phone ? customerData.phone : finalPhone;
    const orderNumber = existing ? existing.orderNumber : Number(counterSnap?.data()?.nextOrderNumber || 532);
    const oldOrder = existing;
    const payload = serializeForm(orderNumber, oldOrder, finalName);
    delete payload.id;
    payload.phone = finalPhone;
    const createdAt = oldOrder?.createdAt || fs.serverTimestamp();
    payload.createdAt = createdAt;
    payload.updatedAt = fs.serverTimestamp();

    tx.set(customerRef, {
      category: 'Officer',
      bdNumber: bd,
      name: finalName,
      phone: customerPhone,
      createdAt: customerData?.createdAt || fs.serverTimestamp(),
      updatedAt: fs.serverTimestamp()
    }, { merge: true });

    tx.set(orderRef, payload);
    if (!existing) {
      tx.set(counterRef, { nextOrderNumber: orderNumber + 1, updatedAt: fs.serverTimestamp() }, { merge: true });
    }
    finalOrder = { ...payload, id: orderRef.id, orderNumber };
  });
  return finalOrder;
}

async function firebaseSaveCustomerEdit(bdNumber, newName, newPhone) {
  if (!isFirebaseConfigured || !state.backendReady) return;
  const fs = firebase, db = firebase.db;
  const docId = encodeURIComponent(normBD(bdNumber));
  await fs.setDoc(fs.doc(db, 'officerCustomers', docId), {
    name: newName,
    phone: newPhone,
    updatedAt: fs.serverTimestamp()
  }, { merge: true });

  const snap = await fs.getDocs(fs.collection(db, 'officerOrders'));
  const norm = normBD(bdNumber);
  const affected = snap.docs.filter(d => normBD(d.data()?.customerBDNumber) === norm);
  let batch = fs.writeBatch(db), count = 0;
  for (const doc of affected) {
    batch.update(doc.ref, { customerName: newName, phone: newPhone, updatedAt: fs.serverTimestamp() });
    count++;
    if (count >= 400) {
      await batch.commit();
      batch = fs.writeBatch(db);
      count = 0;
    }
  }
  if (count) await batch.commit();
}

async function firebaseDeleteCustomer(bdNumber) {
  if (!isFirebaseConfigured || !state.backendReady) return;
  const fs = firebase, db = firebase.db;
  const docId = encodeURIComponent(normBD(bdNumber));
  await fs.deleteDoc(fs.doc(db, 'officerCustomers', docId));
}

async function firebaseDeleteOrder(id, orderNumber) {
  const fs = firebase, db = firebase.db;
  const snap = await fs.getDocs(fs.collection(db, 'officerOrders'));
  const docs = snap.docs.map(d => ({ id: d.id, ref: d.ref, data: d.data() })).sort((a, b) => Number(a.data.orderNumber || 0) - Number(b.data.orderNumber || 0));
  const target = docs.find(d => d.id === id);
  if (!target) throw new Error('This order no longer exists. Refresh and try again.');
  const affected = docs.filter(d => d.id === id || Number(d.data.orderNumber || 0) > Number(orderNumber));
  let batch = fs.writeBatch(db), count = 0;
  for (const entry of affected) {
    if (entry.id === id) batch.delete(entry.ref);
    else batch.update(entry.ref, { orderNumber: Number(entry.data.orderNumber) - 1, updatedAt: fs.serverTimestamp() });
    count++;
    if (count >= 450) {
      await batch.commit();
      batch = fs.writeBatch(db);
      count = 0;
    }
  }
  if (count) await batch.commit();
  await fs.setDoc(fs.doc(db, 'counters', 'officerOrders'), { nextOrderNumber: docs.length, updatedAt: fs.serverTimestamp() }, { merge: true });
}

async function firebaseSaveSettings(settings) {
  await firebase.setDoc(firebase.doc(firebase.db, 'settings', 'officerCore'), {
    items: settings.items,
    defaultDiscountType: settings.defaultDiscountType,
    ribbonValues: settings.ribbonValues,
    upcomingDeliveryDays: settings.upcomingDeliveryDays || 3,
    shopName: settings.shopName || 'Darzi Tailor Shop',
    shopLogo: settings.shopLogo || '',
    terms: settings.terms || defaultSettings().terms,
    invoicePaperSize: settings.invoicePaperSize || 'A4',
    cuttingSlipPaperSize: settings.cuttingSlipPaperSize || 'A4',
    updatedAt: firebase.serverTimestamp()
  }, { merge: true });
}

async function start() {
  if (!isFirebaseConfigured) {
    loadLocalState();
    state.loaded = true;
    state.backendReady = true;
    state.bootReady = true;
    render();
    return;
  }
  render();
  try {
    await initFirebase();
    firebase.saveOrder = firebaseSaveOrder;
    firebase.deleteOrder = firebaseDeleteOrder;
    firebase.saveSettings = firebaseSaveSettings;
  } catch (e) {
    console.error(e);
    state.remoteError = 'Firebase could not initialize. Check web config and network.';
    state.loaded = true;
    render();
  }
}

start();
